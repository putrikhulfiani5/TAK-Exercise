import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.click(findTestObject('Object Repository/page_Checkout/a_Shop'))

WebUI.click(findTestObject('Object Repository/page_Checkout/img_Sale_attachment-shop_catalog size-shop__dbdc79'))

WebUI.click(findTestObject('Object Repository/page_Checkout/button_Add to basket'))

WebUI.click(findTestObject('Object Repository/page_Checkout/a_View Basket'))

WebUI.click(findTestObject('Object Repository/page_Checkout/a_Proceed to Checkout'))

WebUI.click(findTestObject('Object Repository/page_Checkout/input_PayPal Express Checkout_place_order'))

WebUI.verifyElementVisible(findTestObject('page_Checkout/ul_Billing First Name is a required field'))

