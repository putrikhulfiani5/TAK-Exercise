
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */



def static "Utilities.getRandomEmail"() {
    (new Utilities()).getRandomEmail()
}
