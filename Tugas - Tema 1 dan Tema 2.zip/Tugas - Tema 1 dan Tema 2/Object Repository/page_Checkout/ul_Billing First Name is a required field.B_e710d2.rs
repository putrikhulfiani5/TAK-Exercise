<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ul_Billing First Name is a required field.B_e710d2</name>
   <tag></tag>
   <elementGuidId>c5c6d3b4-c6ae-4c24-86b5-44884941a153</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.woocommerce-error</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-35']/div/div/form[3]/ul</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>ul</value>
      <webElementGuid>2c647530-a7bd-4d54-a114-bcc8e8bef733</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>woocommerce-error</value>
      <webElementGuid>6011fef0-60ce-446d-9bcc-433dd6a76729</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
			Billing First Name is a required field.
			Billing Last Name is a required field.
			Billing Email Address is a required field.
			Billing Phone is a required field.
			Billing Address is a required field.
			Billing Town / City is a required field.
			Billing Postcode / ZIP is a required field.
	</value>
      <webElementGuid>8de5a0d9-ece1-48ee-afd2-f81b76f18ed4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-35&quot;)/div[@class=&quot;page-content entry-content&quot;]/div[@class=&quot;woocommerce&quot;]/form[@class=&quot;checkout woocommerce-checkout&quot;]/ul[@class=&quot;woocommerce-error&quot;]</value>
      <webElementGuid>907d41da-7bb9-4cf6-895d-db4bfb8cf924</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-35']/div/div/form[3]/ul</value>
      <webElementGuid>24fad008-6d3f-4730-9b3b-b1e53997b648</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lost your password?'])[1]/following::ul[1]</value>
      <webElementGuid>7018f943-19a9-4fb6-8f70-0c70dbb3110d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form[3]/ul</value>
      <webElementGuid>f3efe40f-5a83-492c-9483-07301bb5376d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//ul[(text() = '
			Billing First Name is a required field.
			Billing Last Name is a required field.
			Billing Email Address is a required field.
			Billing Phone is a required field.
			Billing Address is a required field.
			Billing Town / City is a required field.
			Billing Postcode / ZIP is a required field.
	' or . = '
			Billing First Name is a required field.
			Billing Last Name is a required field.
			Billing Email Address is a required field.
			Billing Phone is a required field.
			Billing Address is a required field.
			Billing Town / City is a required field.
			Billing Postcode / ZIP is a required field.
	')]</value>
      <webElementGuid>473d1c34-199f-432d-8a93-0fe897eaa345</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
