<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ul_Billing First Name is a required field.B_3790a5</name>
   <tag></tag>
   <elementGuidId>c4d44e1b-32a2-40f8-b8bd-65f9a95e0b46</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-35']/div/div/form[2]/ul</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.woocommerce-error</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>ul</value>
      <webElementGuid>7087adf5-42d4-4d04-a052-f0c3a4d0c5db</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>woocommerce-error</value>
      <webElementGuid>4d4cad69-25fe-4c46-a190-2a94a027385d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
			Billing First Name is a required field.
			Billing Last Name is a required field.
			Billing Phone is a required field.
			Billing Address is a required field.
			Billing Town / City is a required field.
			Billing Postcode / ZIP is a required field.
	</value>
      <webElementGuid>7dc14d99-03d6-48ab-bdda-cd597e4bda10</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-35&quot;)/div[@class=&quot;page-content entry-content&quot;]/div[@class=&quot;woocommerce&quot;]/form[@class=&quot;checkout woocommerce-checkout&quot;]/ul[@class=&quot;woocommerce-error&quot;]</value>
      <webElementGuid>18cefb2c-6bbe-4bc5-a540-3c175d79ba7c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-35']/div/div/form[2]/ul</value>
      <webElementGuid>10ae3d7d-6f91-40f2-9422-999e860647b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='₹450.00'])[1]/following::ul[1]</value>
      <webElementGuid>8cccdb0f-bbe1-4a28-adb5-e757fd82e587</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form[2]/ul</value>
      <webElementGuid>41c6f093-b930-4be5-b44f-b5551c7eda11</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//ul[(text() = '
			Billing First Name is a required field.
			Billing Last Name is a required field.
			Billing Phone is a required field.
			Billing Address is a required field.
			Billing Town / City is a required field.
			Billing Postcode / ZIP is a required field.
	' or . = '
			Billing First Name is a required field.
			Billing Last Name is a required field.
			Billing Phone is a required field.
			Billing Address is a required field.
			Billing Town / City is a required field.
			Billing Postcode / ZIP is a required field.
	')]</value>
      <webElementGuid>83ff9603-43bb-4065-96a2-74419042ee24</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
