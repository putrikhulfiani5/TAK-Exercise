<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ul_Billing First Name is a required field</name>
   <tag></tag>
   <elementGuidId>f49c4dd0-99d1-432a-9a4e-40b0b7d95d42</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.woocommerce-error</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-35']/div/div/form[3]/ul</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>ul</value>
      <webElementGuid>ba189076-b09a-4d27-8695-ec32589e4aa5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>woocommerce-error</value>
      <webElementGuid>fe17b273-3179-4003-b9da-f8ced83a5d34</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
			Billing First Name is a required field.
			Billing Last Name is a required field.
			Billing Email Address is a required field.
			Billing Phone is a required field.
			Billing Address is a required field.
			Billing Town / City is a required field.
			Billing Postcode / ZIP is a required field.
	</value>
      <webElementGuid>a7d6bcdf-c93b-4f63-bbe1-1844dd22963a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-35&quot;)/div[@class=&quot;page-content entry-content&quot;]/div[@class=&quot;woocommerce&quot;]/form[@class=&quot;checkout woocommerce-checkout&quot;]/ul[@class=&quot;woocommerce-error&quot;]</value>
      <webElementGuid>6afad743-1df0-4b8b-9788-7327e3fca7e6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-35']/div/div/form[3]/ul</value>
      <webElementGuid>d8e121aa-71b9-48f2-9b16-3626bfdd9eae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lost your password?'])[1]/following::ul[1]</value>
      <webElementGuid>ae57b80d-a2a4-4bbc-9cfe-4aeca78e460e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form[3]/ul</value>
      <webElementGuid>e2fdd4f9-3679-474c-b3af-8b5de7b17958</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//ul[(text() = '
			Billing First Name is a required field.
			Billing Last Name is a required field.
			Billing Email Address is a required field.
			Billing Phone is a required field.
			Billing Address is a required field.
			Billing Town / City is a required field.
			Billing Postcode / ZIP is a required field.
	' or . = '
			Billing First Name is a required field.
			Billing Last Name is a required field.
			Billing Email Address is a required field.
			Billing Phone is a required field.
			Billing Address is a required field.
			Billing Town / City is a required field.
			Billing Postcode / ZIP is a required field.
	')]</value>
      <webElementGuid>3d73c269-430a-4c2f-af39-2101f3b16aa9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
