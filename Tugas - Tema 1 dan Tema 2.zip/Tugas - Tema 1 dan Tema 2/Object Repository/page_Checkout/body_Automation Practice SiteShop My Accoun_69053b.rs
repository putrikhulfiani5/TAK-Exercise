<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>body_Automation Practice SiteShop My Accoun_69053b</name>
   <tag></tag>
   <elementGuidId>4f34e954-a20a-43d9-be40-2a23dad44ddd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>body.page-template-default.page.page-id-35.woocommerce-checkout.woocommerce-page.template-themify-ultra.template-themify-ultra-1-5-0.skin-default.webkit.not-ie.default_width.sidebar-none.no-home.no-touch.header-top-bar.fixed-header.footer-block.default.tagline-off.rss-off.filter-hover-none.filter-featured-only.masonry-enabled.sidemenu-active.builder-parallax-scrolling-active.animation-on.page-loaded.themify_lightbox_loaded.fixed-header-on</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//body</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>body</value>
      <webElementGuid>7d95c5bf-c842-4a70-8b4f-5307e2054326</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>page-template-default page page-id-35 woocommerce-checkout woocommerce-page template-themify-ultra template-themify-ultra-1-5-0 skin-default webkit not-ie default_width sidebar-none no-home no-touch header-top-bar fixed-header footer-block default tagline-off rss-off filter-hover-none filter-featured-only masonry-enabled sidemenu-active builder-parallax-scrolling-active animation-on page-loaded themify_lightbox_loaded fixed-header-on</value>
      <webElementGuid>b6e7fd69-9991-4f1e-a247-80772b588eea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>




			

			
			

			

	            
	            
		            						Automation Practice Site					
									
				

									

													
																									
															
							
						
													
								

	

	

							
							
						
													
								Shop 
My Account 
Test Cases 
AT Site 
Demo Site 
1 item₹450.00								
							
							
						
													
		
							
								 
 
 
 
 
					



(adsbygoogle = window.adsbygoogle || []).push({});

					



(adsbygoogle = window.adsbygoogle || []).push({});

					



(adsbygoogle = window.adsbygoogle || []).push({});

					



(adsbygoogle = window.adsbygoogle || []).push({});

					



(adsbygoogle = window.adsbygoogle || []).push({});

					



(adsbygoogle = window.adsbygoogle || []).push({});

						
							
									
							
									
					
		

								
						
						
					
					
				
				
				
			
			

	        
		
		
	
	

		




		
	
    	
		
							

			
						

			

				
				
	Returning customer? Click here to login



	
	If you have shopped with us before, please enter your details in the boxes below. If you are a new customer, please proceed to the Billing &amp; Shipping section.

	
		Username or email *
		
	
	
		Password *
		
	
	

	
	
				
		
		
			 Remember me		
	
	
		Lost your password?
	

	

	


	Have a coupon? Click here to enter your code



	
		
	

	
		
	

	




	
		
		
			
				
	
		Billing Details

	
	
	
		First Name *
	
		Last Name *
	
		Company Name
	
		Email Address *
	
		Phone *
	
		Country *   India   Country *          Country *                Select a country…Åland IslandsAfghanistanAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntarcticaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelarusBelauBelgiumBelizeBeninBermudaBhutanBoliviaBonaire, Saint Eustatius and SabaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo (Brazzaville)Congo (Kinshasa)Cook IslandsCosta RicaCroatiaCubaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland IslandsFaroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHondurasHong KongHungaryIcelandIndiaIndonesiaIranIraqIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacao S.A.R., ChinaMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesiaMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmarNamibiaNauruNepalNetherlandsNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorth KoreaNorthern Mariana IslandsNorwayOmanPakistanPalestinian TerritoryPanamaPapua New GuineaParaguayPeruPhilippinesPitcairnPolandPortugalPuerto RicoQatarRepublic of IrelandReunionRomaniaRussiaRwandaSão Tomé and PríncipeSaint BarthélemySaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (Dutch part)Saint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia/Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandSyriaTaiwanTajikistanTanzaniaThailandTimor-LesteTogoTokelauTongaTrinidad and TobagoTunisiaTurkeyTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited Kingdom (UK)United States (US)United States (US) Minor Outlying IslandsUnited States (US) Virgin IslandsUruguayUzbekistanVanuatuVaticanVenezuelaVietnamWallis and FutunaWestern SaharaYemenZambiaZimbabwe&lt;input type=&quot;submit&quot; name=&quot;woocommerce_checkout_update_totals&quot; value=&quot;Update country&quot; />
	
		Address *
	
		
	
		Town / City *
	
		State / County *   Telangana   State / County *          State / County *                Select an option…Andhra PradeshArunachal PradeshAssamBiharChhattisgarhGoaGujaratHaryanaHimachal PradeshJammu and KashmirJharkhandKarnatakaKeralaMadhya PradeshMaharashtraManipurMeghalayaMizoramNagalandOrissaPunjabRajasthanSikkimTamil NaduTelanganaTripuraUttarakhandUttar PradeshWest BengalAndaman and Nicobar IslandsChandigarhDadar and Nagar HaveliDaman and DiuDelhiLakshadeepPondicherry (Puducherry)Postcode / ZIP *
	
		
	
	
	
		
			
				 Create an account?
			

		
		
		
			

				Create an account by entering the information below. If you are a returning customer please login at the top of the page.

				
					Account password *
				
				

			

		
		
	
			

			
				
	
	
	
		
			Additional Information

		
		
			Order Notes
		
	
	
			
		

		
	
	Your order

	
	
		
	
		
			Product
			Total
		
	
	
							
						
							Android Quick Start Guide 							 × 1													
						
							₹450.00						
					
						
	

		
			Subtotal
			₹450.00
		

		
		
		
														
						Tax
						₹9.00
					
									
		
		
			Total
			₹459.00 
		

		
	



			
			
	

	
		Direct Bank Transfer 	
			
			Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order won’t be shipped until the funds have cleared in our account.
		
	

	

	
		Check Payments 	
			
			Please send a cheque to Store Name, Store Street, Store Town, Store State / County, Store Postcode.
		
	

	

	
		Cash on Delivery 	
			
			Pay with cash upon delivery.
		
	

	

	
		PayPal Express Checkout 	
			
			Pay using either your PayPal account or credit card. All credit card payments will be processed by PayPal.
		
	
		
		
		
			Since your browser does not support JavaScript, or it is disabled, please ensure you click the &lt;em>Update Totals&lt;/em> button before placing your order. You may be charged more than the amount stated above if you fail to do so.			&lt;br/>&lt;input type=&quot;submit&quot; class=&quot;button alt&quot; name=&quot;woocommerce_checkout_update_totals&quot; value=&quot;Update totals&quot; />
		

		
		
		
		
			


	

	





	

				
				
				
								

			
			

			
		
				
			
	
    
	
	





        			
			

							

					
					

						
						
						
							
															
															
							
							

																	
																			
									
																							
						

																					
									
										
		
							
								



		
							
								  
							
							
							
								  
							
							
							
								  
							
							
							
								  
							
							
							
								  
							
											
							
								

Discover moreSaludCienciasDevelopment Tools

(adsbygoogle = window.adsbygoogle || []).push({});

						
							
								

Discover moreHome Storage &amp; ShelvingSoftwareDevelopment Tools

(adsbygoogle = window.adsbygoogle || []).push({});

						
							
					Subscribe Here(function() {
	if (!window.mc4wp) {
		window.mc4wp = {
			listeners: [],
			forms    : {
				on: function (event, callback) {
					window.mc4wp.listeners.push({
						event   : event,
						callback: callback
					});
				}
			}
		}
	}
})();

	



	
				
					
		

											
									
								
								
									
																					© Automation Practice Site 2026											 																			
								
								
													
						
					
					

					
				
				
			
		
		

		
		[{&quot;@context&quot;:&quot;http:\/\/schema.org&quot;,&quot;@type&quot;:&quot;WebPage&quot;,&quot;mainEntityOfPage&quot;:{&quot;@type&quot;:&quot;WebPage&quot;,&quot;@id&quot;:&quot;https:\/\/practice.automationtesting.in\/checkout\/&quot;},&quot;headline&quot;:&quot;Checkout&quot;,&quot;datePublished&quot;:&quot;2017-01-06T08:17:30+00:00&quot;,&quot;dateModified&quot;:&quot;2017-01-06T08:17:30+00:00&quot;,&quot;description&quot;:&quot;&quot;,&quot;commentCount&quot;:&quot;0&quot;}]		
		

(function() {function addEventListener(element,event,handler) {
	if(element.addEventListener) {
		element.addEventListener(event,handler, false);
	} else if(element.attachEvent){
		element.attachEvent('on'+event,handler);
	}
}function maybePrefixUrlField() {
	if(this.value.trim() !== '' &amp;&amp; this.value.indexOf('http') !== 0) {
		this.value = &quot;http://&quot; + this.value;
	}
}

var urlFields = document.querySelectorAll('.mc4wp-form input[type=&quot;url&quot;]');
if( urlFields &amp;&amp; urlFields.length > 0 ) {
	for( var j=0; j &lt; urlFields.length; j++ ) {
		addEventListener(urlFields[j],'blur',maybePrefixUrlField);
	}
}/* test if browser supports date fields */
var testInput = document.createElement('input');
testInput.setAttribute('type', 'date');
if( testInput.type !== 'date') {

	/* add placeholder &amp; pattern to all date fields */
	var dateFields = document.querySelectorAll('.mc4wp-form input[type=&quot;date&quot;]');
	for(var i=0; i&lt;dateFields.length; i++) {
		if(!dateFields[i].placeholder) {
			dateFields[i].placeholder = 'YYYY-MM-DD';
		}
		if(!dateFields[i].pattern) {
			dateFields[i].pattern = '[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])';
		}
	}
}

})();
/* &lt;![CDATA[ */
var themify_vars = {&quot;version&quot;:&quot;2.8.8&quot;,&quot;url&quot;:&quot;https:\/\/practice.automationtesting.in\/wp-content\/themes\/themify-ultra\/themify&quot;,&quot;TB&quot;:&quot;1&quot;,&quot;map_key&quot;:null};
var tbLocalScript = {&quot;isAnimationActive&quot;:&quot;1&quot;,&quot;isParallaxActive&quot;:&quot;1&quot;,&quot;animationInviewSelectors&quot;:[&quot;.module.wow&quot;,&quot;.themify_builder_content .themify_builder_row.wow&quot;,&quot;.module_row.wow&quot;,&quot;.builder-posts-wrap > .post.wow&quot;,&quot;.fly-in > .post&quot;,&quot;.fly-in .row_inner > .tb-column&quot;,&quot;.fade-in > .post&quot;,&quot;.fade-in .row_inner > .tb-column&quot;,&quot;.slide-up > .post&quot;,&quot;.slide-up .row_inner > .tb-column&quot;],&quot;createAnimationSelectors&quot;:[],&quot;backgroundSlider&quot;:{&quot;autoplay&quot;:5000,&quot;speed&quot;:2000},&quot;animationOffset&quot;:&quot;100&quot;,&quot;videoPoster&quot;:&quot;https:\/\/practice.automationtesting.in\/wp-content\/themes\/themify-ultra\/themify\/themify-builder\/img\/blank.png&quot;,&quot;backgroundVideoLoop&quot;:&quot;yes&quot;,&quot;builder_url&quot;:&quot;https:\/\/practice.automationtesting.in\/wp-content\/themes\/themify-ultra\/themify\/themify-builder&quot;,&quot;framework_url&quot;:&quot;https:\/\/practice.automationtesting.in\/wp-content\/themes\/themify-ultra\/themify&quot;,&quot;version&quot;:&quot;2.8.8&quot;,&quot;fullwidth_support&quot;:&quot;&quot;,&quot;fullwidth_container&quot;:&quot;body&quot;,&quot;loadScrollHighlight&quot;:&quot;1&quot;};
var themifyScript = {&quot;lightbox&quot;:{&quot;lightboxSelector&quot;:&quot;.themify_lightbox&quot;,&quot;lightboxOn&quot;:true,&quot;lightboxContentImages&quot;:false,&quot;lightboxContentImagesSelector&quot;:&quot;.post-content a[href$=jpg],.page-content a[href$=jpg],.post-content a[href$=gif],.page-content a[href$=gif],.post-content a[href$=png],.page-content a[href$=png],.post-content a[href$=JPG],.page-content a[href$=JPG],.post-content a[href$=GIF],.page-content a[href$=GIF],.post-content a[href$=PNG],.page-content a[href$=PNG],.post-content a[href$=jpeg],.page-content a[href$=jpeg],.post-content a[href$=JPEG],.page-content a[href$=JPEG]&quot;,&quot;theme&quot;:&quot;pp_default&quot;,&quot;social_tools&quot;:false,&quot;allow_resize&quot;:true,&quot;show_title&quot;:false,&quot;overlay_gallery&quot;:false,&quot;screenWidthNoLightbox&quot;:600,&quot;deeplinking&quot;:false,&quot;contentImagesAreas&quot;:&quot;.post, .type-page, .type-highlight, .type-slider&quot;,&quot;gallerySelector&quot;:&quot;.gallery-icon > a[href$=jpg],.gallery-icon > a[href$=gif],.gallery-icon > a[href$=png],.gallery-icon > a[href$=JPG],.gallery-icon > a[href$=GIF],.gallery-icon > a[href$=PNG],.gallery-icon > a[href$=jpeg],.gallery-icon > a[href$=JPEG]&quot;,&quot;lightboxGalleryOn&quot;:true},&quot;lightboxContext&quot;:&quot;body&quot;};
var tbScrollHighlight = {&quot;fixedHeaderSelector&quot;:&quot;#headerwrap.fixed-header&quot;,&quot;speed&quot;:&quot;900&quot;,&quot;navigation&quot;:&quot;#main-nav&quot;,&quot;scrollOffset&quot;:&quot;-5&quot;};
/* ]]&gt; */




/* &lt;![CDATA[ */
var _wpcf7 = {&quot;recaptcha&quot;:{&quot;messages&quot;:{&quot;empty&quot;:&quot;Please verify that you are not a robot.&quot;}}};
/* ]]&gt; */



/* &lt;![CDATA[ */
var sb_instagram_js_options = {&quot;sb_instagram_at&quot;:&quot;&quot;};
/* ]]&gt; */



/* &lt;![CDATA[ */
var wc_add_to_cart_params = {&quot;ajax_url&quot;:&quot;\/wp-admin\/admin-ajax.php&quot;,&quot;wc_ajax_url&quot;:&quot;\/checkout\/?wc-ajax=%%endpoint%%&quot;,&quot;i18n_view_cart&quot;:&quot;View Basket&quot;,&quot;cart_url&quot;:&quot;https:\/\/practice.automationtesting.in\/basket\/&quot;,&quot;is_cart&quot;:&quot;&quot;,&quot;cart_redirect_after_add&quot;:&quot;no&quot;};
/* ]]&gt; */









wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );


/* &lt;![CDATA[ */
var pwsL10n = {&quot;unknown&quot;:&quot;Password strength unknown&quot;,&quot;short&quot;:&quot;Very weak&quot;,&quot;bad&quot;:&quot;Weak&quot;,&quot;good&quot;:&quot;Medium&quot;,&quot;strong&quot;:&quot;Strong&quot;,&quot;mismatch&quot;:&quot;Mismatch&quot;};
/* ]]&gt; */


( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[&quot;&quot;].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( &quot;default&quot;, {&quot;translation-revision-date&quot;:&quot;2023-04-19 10:51:23+0000&quot;,&quot;generator&quot;:&quot;GlotPress\/4.0.0-alpha.4&quot;,&quot;domain&quot;:&quot;messages&quot;,&quot;locale_data&quot;:{&quot;messages&quot;:{&quot;&quot;:{&quot;domain&quot;:&quot;messages&quot;,&quot;plural-forms&quot;:&quot;nplurals=2; plural=n != 1;&quot;,&quot;lang&quot;:&quot;en_GB&quot;},&quot;%1$s is deprecated since version %2$s! Use %3$s instead. Please consider writing more inclusive code.&quot;:[&quot;%1$s is deprecated since version %2$s! Use %3$s instead. Please consider writing more inclusive code.&quot;]}},&quot;comment&quot;:{&quot;reference&quot;:&quot;wp-admin\/js\/password-strength-meter.js&quot;}} );



/* &lt;![CDATA[ */
var wc_password_strength_meter_params = {&quot;min_password_strength&quot;:&quot;3&quot;,&quot;i18n_password_error&quot;:&quot;Please enter a stronger password.&quot;,&quot;i18n_password_hint&quot;:&quot;The password should be at least seven characters long. To make it stronger, use upper and lower case letters, numbers and symbols like ! \&quot; ? $ % ^ &amp; ).&quot;};
/* ]]&gt; */




/* &lt;![CDATA[ */
var woocommerce_params = {&quot;ajax_url&quot;:&quot;\/wp-admin\/admin-ajax.php&quot;,&quot;wc_ajax_url&quot;:&quot;\/checkout\/?wc-ajax=%%endpoint%%&quot;};
/* ]]&gt; */



/* &lt;![CDATA[ */
var wc_country_select_params = {&quot;countries&quot;:&quot;{\&quot;AF\&quot;:[],\&quot;AT\&quot;:[],\&quot;AX\&quot;:[],\&quot;BE\&quot;:[],\&quot;BI\&quot;:[],\&quot;CZ\&quot;:[],\&quot;DE\&quot;:[],\&quot;DK\&quot;:[],\&quot;EE\&quot;:[],\&quot;FI\&quot;:[],\&quot;FR\&quot;:[],\&quot;IS\&quot;:[],\&quot;IL\&quot;:[],\&quot;KR\&quot;:[],\&quot;NL\&quot;:[],\&quot;NO\&quot;:[],\&quot;PL\&quot;:[],\&quot;PT\&quot;:[],\&quot;SG\&quot;:[],\&quot;SK\&quot;:[],\&quot;SI\&quot;:[],\&quot;LK\&quot;:[],\&quot;SE\&quot;:[],\&quot;VN\&quot;:[],\&quot;AR\&quot;:{\&quot;C\&quot;:\&quot;Ciudad Aut\u00f3noma de Buenos Aires\&quot;,\&quot;B\&quot;:\&quot;Buenos Aires\&quot;,\&quot;K\&quot;:\&quot;Catamarca\&quot;,\&quot;H\&quot;:\&quot;Chaco\&quot;,\&quot;U\&quot;:\&quot;Chubut\&quot;,\&quot;X\&quot;:\&quot;C\u00f3rdoba\&quot;,\&quot;W\&quot;:\&quot;Corrientes\&quot;,\&quot;E\&quot;:\&quot;Entre R\u00edos\&quot;,\&quot;P\&quot;:\&quot;Formosa\&quot;,\&quot;Y\&quot;:\&quot;Jujuy\&quot;,\&quot;L\&quot;:\&quot;La Pampa\&quot;,\&quot;F\&quot;:\&quot;La Rioja\&quot;,\&quot;M\&quot;:\&quot;Mendoza\&quot;,\&quot;N\&quot;:\&quot;Misiones\&quot;,\&quot;Q\&quot;:\&quot;Neuqu\u00e9n\&quot;,\&quot;R\&quot;:\&quot;R\u00edo Negro\&quot;,\&quot;A\&quot;:\&quot;Salta\&quot;,\&quot;J\&quot;:\&quot;San Juan\&quot;,\&quot;D\&quot;:\&quot;San Luis\&quot;,\&quot;Z\&quot;:\&quot;Santa Cruz\&quot;,\&quot;S\&quot;:\&quot;Santa Fe\&quot;,\&quot;G\&quot;:\&quot;Santiago del Estero\&quot;,\&quot;V\&quot;:\&quot;Tierra del Fuego\&quot;,\&quot;T\&quot;:\&quot;Tucum\u00e1n\&quot;},\&quot;AU\&quot;:{\&quot;ACT\&quot;:\&quot;Australian Capital Territory\&quot;,\&quot;NSW\&quot;:\&quot;New South Wales\&quot;,\&quot;NT\&quot;:\&quot;Northern Territory\&quot;,\&quot;QLD\&quot;:\&quot;Queensland\&quot;,\&quot;SA\&quot;:\&quot;South Australia\&quot;,\&quot;TAS\&quot;:\&quot;Tasmania\&quot;,\&quot;VIC\&quot;:\&quot;Victoria\&quot;,\&quot;WA\&quot;:\&quot;Western Australia\&quot;},\&quot;BD\&quot;:{\&quot;BAG\&quot;:\&quot;Bagerhat\&quot;,\&quot;BAN\&quot;:\&quot;Bandarban\&quot;,\&quot;BAR\&quot;:\&quot;Barguna\&quot;,\&quot;BARI\&quot;:\&quot;Barisal\&quot;,\&quot;BHO\&quot;:\&quot;Bhola\&quot;,\&quot;BOG\&quot;:\&quot;Bogra\&quot;,\&quot;BRA\&quot;:\&quot;Brahmanbaria\&quot;,\&quot;CHA\&quot;:\&quot;Chandpur\&quot;,\&quot;CHI\&quot;:\&quot;Chittagong\&quot;,\&quot;CHU\&quot;:\&quot;Chuadanga\&quot;,\&quot;COM\&quot;:\&quot;Comilla\&quot;,\&quot;COX\&quot;:\&quot;Cox's Bazar\&quot;,\&quot;DHA\&quot;:\&quot;Dhaka\&quot;,\&quot;DIN\&quot;:\&quot;Dinajpur\&quot;,\&quot;FAR\&quot;:\&quot;Faridpur \&quot;,\&quot;FEN\&quot;:\&quot;Feni\&quot;,\&quot;GAI\&quot;:\&quot;Gaibandha\&quot;,\&quot;GAZI\&quot;:\&quot;Gazipur\&quot;,\&quot;GOP\&quot;:\&quot;Gopalganj\&quot;,\&quot;HAB\&quot;:\&quot;Habiganj\&quot;,\&quot;JAM\&quot;:\&quot;Jamalpur\&quot;,\&quot;JES\&quot;:\&quot;Jessore\&quot;,\&quot;JHA\&quot;:\&quot;Jhalokati\&quot;,\&quot;JHE\&quot;:\&quot;Jhenaidah\&quot;,\&quot;JOY\&quot;:\&quot;Joypurhat\&quot;,\&quot;KHA\&quot;:\&quot;Khagrachhari\&quot;,\&quot;KHU\&quot;:\&quot;Khulna\&quot;,\&quot;KIS\&quot;:\&quot;Kishoreganj\&quot;,\&quot;KUR\&quot;:\&quot;Kurigram\&quot;,\&quot;KUS\&quot;:\&quot;Kushtia\&quot;,\&quot;LAK\&quot;:\&quot;Lakshmipur\&quot;,\&quot;LAL\&quot;:\&quot;Lalmonirhat\&quot;,\&quot;MAD\&quot;:\&quot;Madaripur\&quot;,\&quot;MAG\&quot;:\&quot;Magura\&quot;,\&quot;MAN\&quot;:\&quot;Manikganj \&quot;,\&quot;MEH\&quot;:\&quot;Meherpur\&quot;,\&quot;MOU\&quot;:\&quot;Moulvibazar\&quot;,\&quot;MUN\&quot;:\&quot;Munshiganj\&quot;,\&quot;MYM\&quot;:\&quot;Mymensingh\&quot;,\&quot;NAO\&quot;:\&quot;Naogaon\&quot;,\&quot;NAR\&quot;:\&quot;Narail\&quot;,\&quot;NARG\&quot;:\&quot;Narayanganj\&quot;,\&quot;NARD\&quot;:\&quot;Narsingdi\&quot;,\&quot;NAT\&quot;:\&quot;Natore\&quot;,\&quot;NAW\&quot;:\&quot;Nawabganj\&quot;,\&quot;NET\&quot;:\&quot;Netrakona\&quot;,\&quot;NIL\&quot;:\&quot;Nilphamari\&quot;,\&quot;NOA\&quot;:\&quot;Noakhali\&quot;,\&quot;PAB\&quot;:\&quot;Pabna\&quot;,\&quot;PAN\&quot;:\&quot;Panchagarh\&quot;,\&quot;PAT\&quot;:\&quot;Patuakhali\&quot;,\&quot;PIR\&quot;:\&quot;Pirojpur\&quot;,\&quot;RAJB\&quot;:\&quot;Rajbari\&quot;,\&quot;RAJ\&quot;:\&quot;Rajshahi\&quot;,\&quot;RAN\&quot;:\&quot;Rangamati\&quot;,\&quot;RANP\&quot;:\&quot;Rangpur\&quot;,\&quot;SAT\&quot;:\&quot;Satkhira\&quot;,\&quot;SHA\&quot;:\&quot;Shariatpur\&quot;,\&quot;SHE\&quot;:\&quot;Sherpur\&quot;,\&quot;SIR\&quot;:\&quot;Sirajganj\&quot;,\&quot;SUN\&quot;:\&quot;Sunamganj\&quot;,\&quot;SYL\&quot;:\&quot;Sylhet\&quot;,\&quot;TAN\&quot;:\&quot;Tangail\&quot;,\&quot;THA\&quot;:\&quot;Thakurgaon\&quot;},\&quot;BR\&quot;:{\&quot;AC\&quot;:\&quot;Acre\&quot;,\&quot;AL\&quot;:\&quot;Alagoas\&quot;,\&quot;AP\&quot;:\&quot;Amap\u00e1\&quot;,\&quot;AM\&quot;:\&quot;Amazonas\&quot;,\&quot;BA\&quot;:\&quot;Bahia\&quot;,\&quot;CE\&quot;:\&quot;Cear\u00e1\&quot;,\&quot;DF\&quot;:\&quot;Distrito Federal\&quot;,\&quot;ES\&quot;:\&quot;Esp\u00edrito Santo\&quot;,\&quot;GO\&quot;:\&quot;Goi\u00e1s\&quot;,\&quot;MA\&quot;:\&quot;Maranh\u00e3o\&quot;,\&quot;MT\&quot;:\&quot;Mato Grosso\&quot;,\&quot;MS\&quot;:\&quot;Mato Grosso do Sul\&quot;,\&quot;MG\&quot;:\&quot;Minas Gerais\&quot;,\&quot;PA\&quot;:\&quot;Par\u00e1\&quot;,\&quot;PB\&quot;:\&quot;Para\u00edba\&quot;,\&quot;PR\&quot;:\&quot;Paran\u00e1\&quot;,\&quot;PE\&quot;:\&quot;Pernambuco\&quot;,\&quot;PI\&quot;:\&quot;Piau\u00ed\&quot;,\&quot;RJ\&quot;:\&quot;Rio de Janeiro\&quot;,\&quot;RN\&quot;:\&quot;Rio Grande do Norte\&quot;,\&quot;RS\&quot;:\&quot;Rio Grande do Sul\&quot;,\&quot;RO\&quot;:\&quot;Rond\u00f4nia\&quot;,\&quot;RR\&quot;:\&quot;Roraima\&quot;,\&quot;SC\&quot;:\&quot;Santa Catarina\&quot;,\&quot;SP\&quot;:\&quot;S\u00e3o Paulo\&quot;,\&quot;SE\&quot;:\&quot;Sergipe\&quot;,\&quot;TO\&quot;:\&quot;Tocantins\&quot;},\&quot;BG\&quot;:{\&quot;BG-01\&quot;:\&quot;Blagoevgrad\&quot;,\&quot;BG-02\&quot;:\&quot;Burgas\&quot;,\&quot;BG-08\&quot;:\&quot;Dobrich\&quot;,\&quot;BG-07\&quot;:\&quot;Gabrovo\&quot;,\&quot;BG-26\&quot;:\&quot;Haskovo\&quot;,\&quot;BG-09\&quot;:\&quot;Kardzhali\&quot;,\&quot;BG-10\&quot;:\&quot;Kyustendil\&quot;,\&quot;BG-11\&quot;:\&quot;Lovech\&quot;,\&quot;BG-12\&quot;:\&quot;Montana\&quot;,\&quot;BG-13\&quot;:\&quot;Pazardzhik\&quot;,\&quot;BG-14\&quot;:\&quot;Pernik\&quot;,\&quot;BG-15\&quot;:\&quot;Pleven\&quot;,\&quot;BG-16\&quot;:\&quot;Plovdiv\&quot;,\&quot;BG-17\&quot;:\&quot;Razgrad\&quot;,\&quot;BG-18\&quot;:\&quot;Ruse\&quot;,\&quot;BG-27\&quot;:\&quot;Shumen\&quot;,\&quot;BG-19\&quot;:\&quot;Silistra\&quot;,\&quot;BG-20\&quot;:\&quot;Sliven\&quot;,\&quot;BG-21\&quot;:\&quot;Smolyan\&quot;,\&quot;BG-23\&quot;:\&quot;Sofia\&quot;,\&quot;BG-22\&quot;:\&quot;Sofia-Grad\&quot;,\&quot;BG-24\&quot;:\&quot;Stara Zagora\&quot;,\&quot;BG-25\&quot;:\&quot;Targovishte\&quot;,\&quot;BG-03\&quot;:\&quot;Varna\&quot;,\&quot;BG-04\&quot;:\&quot;Veliko Tarnovo\&quot;,\&quot;BG-05\&quot;:\&quot;Vidin\&quot;,\&quot;BG-06\&quot;:\&quot;Vratsa\&quot;,\&quot;BG-28\&quot;:\&quot;Yambol\&quot;},\&quot;CA\&quot;:{\&quot;AB\&quot;:\&quot;Alberta\&quot;,\&quot;BC\&quot;:\&quot;British Columbia\&quot;,\&quot;MB\&quot;:\&quot;Manitoba\&quot;,\&quot;NB\&quot;:\&quot;New Brunswick\&quot;,\&quot;NL\&quot;:\&quot;Newfoundland and Labrador\&quot;,\&quot;NT\&quot;:\&quot;Northwest Territories\&quot;,\&quot;NS\&quot;:\&quot;Nova Scotia\&quot;,\&quot;NU\&quot;:\&quot;Nunavut\&quot;,\&quot;ON\&quot;:\&quot;Ontario\&quot;,\&quot;PE\&quot;:\&quot;Prince Edward Island\&quot;,\&quot;QC\&quot;:\&quot;Quebec\&quot;,\&quot;SK\&quot;:\&quot;Saskatchewan\&quot;,\&quot;YT\&quot;:\&quot;Yukon Territory\&quot;},\&quot;CN\&quot;:{\&quot;CN1\&quot;:\&quot;Yunnan \\\/ \u4e91\u5357\&quot;,\&quot;CN2\&quot;:\&quot;Beijing \\\/ \u5317\u4eac\&quot;,\&quot;CN3\&quot;:\&quot;Tianjin \\\/ \u5929\u6d25\&quot;,\&quot;CN4\&quot;:\&quot;Hebei \\\/ \u6cb3\u5317\&quot;,\&quot;CN5\&quot;:\&quot;Shanxi \\\/ \u5c71\u897f\&quot;,\&quot;CN6\&quot;:\&quot;Inner Mongolia \\\/ \u5167\u8499\u53e4\&quot;,\&quot;CN7\&quot;:\&quot;Liaoning \\\/ \u8fbd\u5b81\&quot;,\&quot;CN8\&quot;:\&quot;Jilin \\\/ \u5409\u6797\&quot;,\&quot;CN9\&quot;:\&quot;Heilongjiang \\\/ \u9ed1\u9f99\u6c5f\&quot;,\&quot;CN10\&quot;:\&quot;Shanghai \\\/ \u4e0a\u6d77\&quot;,\&quot;CN11\&quot;:\&quot;Jiangsu \\\/ \u6c5f\u82cf\&quot;,\&quot;CN12\&quot;:\&quot;Zhejiang \\\/ \u6d59\u6c5f\&quot;,\&quot;CN13\&quot;:\&quot;Anhui \\\/ \u5b89\u5fbd\&quot;,\&quot;CN14\&quot;:\&quot;Fujian \\\/ \u798f\u5efa\&quot;,\&quot;CN15\&quot;:\&quot;Jiangxi \\\/ \u6c5f\u897f\&quot;,\&quot;CN16\&quot;:\&quot;Shandong \\\/ \u5c71\u4e1c\&quot;,\&quot;CN17\&quot;:\&quot;Henan \\\/ \u6cb3\u5357\&quot;,\&quot;CN18\&quot;:\&quot;Hubei \\\/ \u6e56\u5317\&quot;,\&quot;CN19\&quot;:\&quot;Hunan \\\/ \u6e56\u5357\&quot;,\&quot;CN20\&quot;:\&quot;Guangdong \\\/ \u5e7f\u4e1c\&quot;,\&quot;CN21\&quot;:\&quot;Guangxi Zhuang \\\/ \u5e7f\u897f\u58ee\u65cf\&quot;,\&quot;CN22\&quot;:\&quot;Hainan \\\/ \u6d77\u5357\&quot;,\&quot;CN23\&quot;:\&quot;Chongqing \\\/ \u91cd\u5e86\&quot;,\&quot;CN24\&quot;:\&quot;Sichuan \\\/ \u56db\u5ddd\&quot;,\&quot;CN25\&quot;:\&quot;Guizhou \\\/ \u8d35\u5dde\&quot;,\&quot;CN26\&quot;:\&quot;Shaanxi \\\/ \u9655\u897f\&quot;,\&quot;CN27\&quot;:\&quot;Gansu \\\/ \u7518\u8083\&quot;,\&quot;CN28\&quot;:\&quot;Qinghai \\\/ \u9752\u6d77\&quot;,\&quot;CN29\&quot;:\&quot;Ningxia Hui \\\/ \u5b81\u590f\&quot;,\&quot;CN30\&quot;:\&quot;Macau \\\/ \u6fb3\u95e8\&quot;,\&quot;CN31\&quot;:\&quot;Tibet \\\/ \u897f\u85cf\&quot;,\&quot;CN32\&quot;:\&quot;Xinjiang \\\/ \u65b0\u7586\&quot;},\&quot;GR\&quot;:{\&quot;I\&quot;:\&quot;\\u0391\\u03c4\\u03c4\\u03b9\\u03ba\\u03ae\&quot;,\&quot;A\&quot;:\&quot;\\u0391\\u03bd\\u03b1\\u03c4\\u03bf\\u03bb\\u03b9\\u03ba\\u03ae \\u039c\\u03b1\\u03ba\\u03b5\\u03b4\\u03bf\\u03bd\\u03af\\u03b1 \\u03ba\\u03b1\\u03b9 \\u0398\\u03c1\\u03ac\\u03ba\\u03b7\&quot;,\&quot;B\&quot;:\&quot;\\u039a\\u03b5\\u03bd\\u03c4\\u03c1\\u03b9\\u03ba\\u03ae \\u039c\\u03b1\\u03ba\\u03b5\\u03b4\\u03bf\\u03bd\\u03af\\u03b1\&quot;,\&quot;C\&quot;:\&quot;\\u0394\\u03c5\\u03c4\\u03b9\\u03ba\\u03ae \\u039c\\u03b1\\u03ba\\u03b5\\u03b4\\u03bf\\u03bd\\u03af\\u03b1\&quot;,\&quot;D\&quot;:\&quot;\\u0389\\u03c0\\u03b5\\u03b9\\u03c1\\u03bf\\u03c2\&quot;,\&quot;E\&quot;:\&quot;\\u0398\\u03b5\\u03c3\\u03c3\\u03b1\\u03bb\\u03af\\u03b1\&quot;,\&quot;F\&quot;:\&quot;\\u0399\\u03cc\\u03bd\\u03b9\\u03bf\\u03b9 \\u039d\\u03ae\\u03c3\\u03bf\\u03b9\&quot;,\&quot;G\&quot;:\&quot;\\u0394\\u03c5\\u03c4\\u03b9\\u03ba\\u03ae \\u0395\\u03bb\\u03bb\\u03ac\\u03b4\\u03b1\&quot;,\&quot;H\&quot;:\&quot;\\u03a3\\u03c4\\u03b5\\u03c1\\u03b5\\u03ac \\u0395\\u03bb\\u03bb\\u03ac\\u03b4\\u03b1\&quot;,\&quot;J\&quot;:\&quot;\\u03a0\\u03b5\\u03bb\\u03bf\\u03c0\\u03cc\\u03bd\\u03bd\\u03b7\\u03c3\\u03bf\\u03c2\&quot;,\&quot;K\&quot;:\&quot;\\u0392\\u03cc\\u03c1\\u03b5\\u03b9\\u03bf \\u0391\\u03b9\\u03b3\\u03b1\\u03af\\u03bf\&quot;,\&quot;L\&quot;:\&quot;\\u039d\\u03cc\\u03c4\\u03b9\\u03bf \\u0391\\u03b9\\u03b3\\u03b1\\u03af\\u03bf\&quot;,\&quot;M\&quot;:\&quot;\\u039a\\u03c1\\u03ae\\u03c4\\u03b7\&quot;},\&quot;HK\&quot;:{\&quot;HONG KONG\&quot;:\&quot;Hong Kong Island\&quot;,\&quot;KOWLOON\&quot;:\&quot;Kowloon\&quot;,\&quot;NEW TERRITORIES\&quot;:\&quot;New Territories\&quot;},\&quot;HU\&quot;:{\&quot;BK\&quot;:\&quot;B\\u00e1cs-Kiskun\&quot;,\&quot;BE\&quot;:\&quot;B\\u00e9k\\u00e9s\&quot;,\&quot;BA\&quot;:\&quot;Baranya\&quot;,\&quot;BZ\&quot;:\&quot;Borsod-Aba\\u00faj-Zempl\\u00e9n\&quot;,\&quot;BU\&quot;:\&quot;Budapest\&quot;,\&quot;CS\&quot;:\&quot;Csongr\\u00e1d\&quot;,\&quot;FE\&quot;:\&quot;Fej\\u00e9r\&quot;,\&quot;GS\&quot;:\&quot;Gy\\u0151r-Moson-Sopron\&quot;,\&quot;HB\&quot;:\&quot;Hajd\\u00fa-Bihar\&quot;,\&quot;HE\&quot;:\&quot;Heves\&quot;,\&quot;JN\&quot;:\&quot;J\\u00e1sz-Nagykun-Szolnok\&quot;,\&quot;KE\&quot;:\&quot;Kom\\u00e1rom-Esztergom\&quot;,\&quot;NO\&quot;:\&quot;N\\u00f3gr\\u00e1d\&quot;,\&quot;PE\&quot;:\&quot;Pest\&quot;,\&quot;SO\&quot;:\&quot;Somogy\&quot;,\&quot;SZ\&quot;:\&quot;Szabolcs-Szatm\\u00e1r-Bereg\&quot;,\&quot;TO\&quot;:\&quot;Tolna\&quot;,\&quot;VA\&quot;:\&quot;Vas\&quot;,\&quot;VE\&quot;:\&quot;Veszpr\\u00e9m\&quot;,\&quot;ZA\&quot;:\&quot;Zala\&quot;},\&quot;IN\&quot;:{\&quot;AP\&quot;:\&quot;Andhra Pradesh\&quot;,\&quot;AR\&quot;:\&quot;Arunachal Pradesh\&quot;,\&quot;AS\&quot;:\&quot;Assam\&quot;,\&quot;BR\&quot;:\&quot;Bihar\&quot;,\&quot;CT\&quot;:\&quot;Chhattisgarh\&quot;,\&quot;GA\&quot;:\&quot;Goa\&quot;,\&quot;GJ\&quot;:\&quot;Gujarat\&quot;,\&quot;HR\&quot;:\&quot;Haryana\&quot;,\&quot;HP\&quot;:\&quot;Himachal Pradesh\&quot;,\&quot;JK\&quot;:\&quot;Jammu and Kashmir\&quot;,\&quot;JH\&quot;:\&quot;Jharkhand\&quot;,\&quot;KA\&quot;:\&quot;Karnataka\&quot;,\&quot;KL\&quot;:\&quot;Kerala\&quot;,\&quot;MP\&quot;:\&quot;Madhya Pradesh\&quot;,\&quot;MH\&quot;:\&quot;Maharashtra\&quot;,\&quot;MN\&quot;:\&quot;Manipur\&quot;,\&quot;ML\&quot;:\&quot;Meghalaya\&quot;,\&quot;MZ\&quot;:\&quot;Mizoram\&quot;,\&quot;NL\&quot;:\&quot;Nagaland\&quot;,\&quot;OR\&quot;:\&quot;Orissa\&quot;,\&quot;PB\&quot;:\&quot;Punjab\&quot;,\&quot;RJ\&quot;:\&quot;Rajasthan\&quot;,\&quot;SK\&quot;:\&quot;Sikkim\&quot;,\&quot;TN\&quot;:\&quot;Tamil Nadu\&quot;,\&quot;TS\&quot;:\&quot;Telangana\&quot;,\&quot;TR\&quot;:\&quot;Tripura\&quot;,\&quot;UK\&quot;:\&quot;Uttarakhand\&quot;,\&quot;UP\&quot;:\&quot;Uttar Pradesh\&quot;,\&quot;WB\&quot;:\&quot;West Bengal\&quot;,\&quot;AN\&quot;:\&quot;Andaman and Nicobar Islands\&quot;,\&quot;CH\&quot;:\&quot;Chandigarh\&quot;,\&quot;DN\&quot;:\&quot;Dadar and Nagar Haveli\&quot;,\&quot;DD\&quot;:\&quot;Daman and Diu\&quot;,\&quot;DL\&quot;:\&quot;Delhi\&quot;,\&quot;LD\&quot;:\&quot;Lakshadeep\&quot;,\&quot;PY\&quot;:\&quot;Pondicherry (Puducherry)\&quot;},\&quot;ID\&quot;:{\&quot;AC\&quot;:\&quot;Daerah Istimewa Aceh\&quot;,\&quot;SU\&quot;:\&quot;Sumatera Utara\&quot;,\&quot;SB\&quot;:\&quot;Sumatera Barat\&quot;,\&quot;RI\&quot;:\&quot;Riau\&quot;,\&quot;KR\&quot;:\&quot;Kepulauan Riau\&quot;,\&quot;JA\&quot;:\&quot;Jambi\&quot;,\&quot;SS\&quot;:\&quot;Sumatera Selatan\&quot;,\&quot;BB\&quot;:\&quot;Bangka Belitung\&quot;,\&quot;BE\&quot;:\&quot;Bengkulu\&quot;,\&quot;LA\&quot;:\&quot;Lampung\&quot;,\&quot;JK\&quot;:\&quot;DKI Jakarta\&quot;,\&quot;JB\&quot;:\&quot;Jawa Barat\&quot;,\&quot;BT\&quot;:\&quot;Banten\&quot;,\&quot;JT\&quot;:\&quot;Jawa Tengah\&quot;,\&quot;JI\&quot;:\&quot;Jawa Timur\&quot;,\&quot;YO\&quot;:\&quot;Daerah Istimewa Yogyakarta\&quot;,\&quot;BA\&quot;:\&quot;Bali\&quot;,\&quot;NB\&quot;:\&quot;Nusa Tenggara Barat\&quot;,\&quot;NT\&quot;:\&quot;Nusa Tenggara Timur\&quot;,\&quot;KB\&quot;:\&quot;Kalimantan Barat\&quot;,\&quot;KT\&quot;:\&quot;Kalimantan Tengah\&quot;,\&quot;KI\&quot;:\&quot;Kalimantan Timur\&quot;,\&quot;KS\&quot;:\&quot;Kalimantan Selatan\&quot;,\&quot;KU\&quot;:\&quot;Kalimantan Utara\&quot;,\&quot;SA\&quot;:\&quot;Sulawesi Utara\&quot;,\&quot;ST\&quot;:\&quot;Sulawesi Tengah\&quot;,\&quot;SG\&quot;:\&quot;Sulawesi Tenggara\&quot;,\&quot;SR\&quot;:\&quot;Sulawesi Barat\&quot;,\&quot;SN\&quot;:\&quot;Sulawesi Selatan\&quot;,\&quot;GO\&quot;:\&quot;Gorontalo\&quot;,\&quot;MA\&quot;:\&quot;Maluku\&quot;,\&quot;MU\&quot;:\&quot;Maluku Utara\&quot;,\&quot;PA\&quot;:\&quot;Papua\&quot;,\&quot;PB\&quot;:\&quot;Papua Barat\&quot;},\&quot;IR\&quot;:{\&quot;KHZ\&quot;:\&quot;Khuzestan  (\\u062e\\u0648\\u0632\\u0633\\u062a\\u0627\\u0646)\&quot;,\&quot;THR\&quot;:\&quot;Tehran  (\\u062a\\u0647\\u0631\\u0627\\u0646)\&quot;,\&quot;ILM\&quot;:\&quot;Ilaam (\\u0627\\u06cc\\u0644\\u0627\\u0645)\&quot;,\&quot;BHR\&quot;:\&quot;Bushehr (\\u0628\\u0648\\u0634\\u0647\\u0631)\&quot;,\&quot;ADL\&quot;:\&quot;Ardabil (\\u0627\\u0631\\u062f\\u0628\\u06cc\\u0644)\&quot;,\&quot;ESF\&quot;:\&quot;Isfahan (\\u0627\\u0635\\u0641\\u0647\\u0627\\u0646)\&quot;,\&quot;YZD\&quot;:\&quot;Yazd (\\u06cc\\u0632\\u062f)\&quot;,\&quot;KRH\&quot;:\&quot;Kermanshah (\\u06a9\\u0631\\u0645\\u0627\\u0646\\u0634\\u0627\\u0647)\&quot;,\&quot;KRN\&quot;:\&quot;Kerman (\\u06a9\\u0631\\u0645\\u0627\\u0646)\&quot;,\&quot;HDN\&quot;:\&quot;Hamadan (\\u0647\\u0645\\u062f\\u0627\\u0646)\&quot;,\&quot;GZN\&quot;:\&quot;Qazvin (\\u0642\\u0632\\u0648\\u06cc\\u0646)\&quot;,\&quot;ZJN\&quot;:\&quot;Zanjan (\\u0632\\u0646\\u062c\\u0627\\u0646)\&quot;,\&quot;LRS\&quot;:\&quot;Luristan (\\u0644\\u0631\\u0633\\u062a\\u0627\\u0646)\&quot;,\&quot;ABZ\&quot;:\&quot;Alborz (\\u0627\\u0644\\u0628\\u0631\\u0632)\&quot;,\&quot;EAZ\&quot;:\&quot;East Azarbaijan (\\u0622\\u0630\\u0631\\u0628\\u0627\\u06cc\\u062c\\u0627\\u0646 \\u0634\\u0631\\u0642\\u06cc)\&quot;,\&quot;WAZ\&quot;:\&quot;West Azarbaijan (\\u0622\\u0630\\u0631\\u0628\\u0627\\u06cc\\u062c\\u0627\\u0646 \\u063a\\u0631\\u0628\\u06cc)\&quot;,\&quot;CHB\&quot;:\&quot;Chaharmahal and Bakhtiari (\\u0686\\u0647\\u0627\\u0631\\u0645\\u062d\\u0627\\u0644 \\u0648 \\u0628\\u062e\\u062a\\u06cc\\u0627\\u0631\\u06cc)\&quot;,\&quot;SKH\&quot;:\&quot;South Khorasan (\\u062e\\u0631\\u0627\\u0633\\u0627\\u0646 \\u062c\\u0646\\u0648\\u0628\\u06cc)\&quot;,\&quot;RKH\&quot;:\&quot;Razavi Khorasan (\\u062e\\u0631\\u0627\\u0633\\u0627\\u0646 \\u0631\\u0636\\u0648\\u06cc)\&quot;,\&quot;NKH\&quot;:\&quot;North Khorasan (\\u062e\\u0631\\u0627\\u0633\\u0627\\u0646 \\u062c\\u0646\\u0648\\u0628\\u06cc)\&quot;,\&quot;SMN\&quot;:\&quot;Semnan (\\u0633\\u0645\\u0646\\u0627\\u0646)\&quot;,\&quot;FRS\&quot;:\&quot;Fars (\\u0641\\u0627\\u0631\\u0633)\&quot;,\&quot;QHM\&quot;:\&quot;Qom (\\u0642\\u0645)\&quot;,\&quot;KRD\&quot;:\&quot;Kurdistan (\\u06a9\\u0631\\u062f\\u0633\\u062a\\u0627\\u0646)\&quot;,\&quot;KBD\&quot;:\&quot;Kohgiluyeh and BoyerAhmad (\\u06a9\\u0647\\u06af\\u06cc\\u0644\\u0648\\u06cc\\u06cc\\u0647 \\u0648 \\u0628\\u0648\\u06cc\\u0631\\u0627\\u062d\\u0645\\u062f)\&quot;,\&quot;GLS\&quot;:\&quot;Golestan (\\u06af\\u0644\\u0633\\u062a\\u0627\\u0646)\&quot;,\&quot;GIL\&quot;:\&quot;Gilan (\\u06af\\u06cc\\u0644\\u0627\\u0646)\&quot;,\&quot;MZN\&quot;:\&quot;Mazandaran (\\u0645\\u0627\\u0632\\u0646\\u062f\\u0631\\u0627\\u0646)\&quot;,\&quot;MKZ\&quot;:\&quot;Markazi (\\u0645\\u0631\\u06a9\\u0632\\u06cc)\&quot;,\&quot;HRZ\&quot;:\&quot;Hormozgan (\\u0647\\u0631\\u0645\\u0632\\u06af\\u0627\\u0646)\&quot;,\&quot;SBN\&quot;:\&quot;Sistan and Baluchestan (\\u0633\\u06cc\\u0633\\u062a\\u0627\\u0646 \\u0648 \\u0628\\u0644\\u0648\\u0686\\u0633\\u062a\\u0627\\u0646)\&quot;},\&quot;IT\&quot;:{\&quot;AG\&quot;:\&quot;Agrigento\&quot;,\&quot;AL\&quot;:\&quot;Alessandria\&quot;,\&quot;AN\&quot;:\&quot;Ancona\&quot;,\&quot;AO\&quot;:\&quot;Aosta\&quot;,\&quot;AR\&quot;:\&quot;Arezzo\&quot;,\&quot;AP\&quot;:\&quot;Ascoli Piceno\&quot;,\&quot;AT\&quot;:\&quot;Asti\&quot;,\&quot;AV\&quot;:\&quot;Avellino\&quot;,\&quot;BA\&quot;:\&quot;Bari\&quot;,\&quot;BT\&quot;:\&quot;Barletta-Andria-Trani\&quot;,\&quot;BL\&quot;:\&quot;Belluno\&quot;,\&quot;BN\&quot;:\&quot;Benevento\&quot;,\&quot;BG\&quot;:\&quot;Bergamo\&quot;,\&quot;BI\&quot;:\&quot;Biella\&quot;,\&quot;BO\&quot;:\&quot;Bologna\&quot;,\&quot;BZ\&quot;:\&quot;Bolzano\&quot;,\&quot;BS\&quot;:\&quot;Brescia\&quot;,\&quot;BR\&quot;:\&quot;Brindisi\&quot;,\&quot;CA\&quot;:\&quot;Cagliari\&quot;,\&quot;CL\&quot;:\&quot;Caltanissetta\&quot;,\&quot;CB\&quot;:\&quot;Campobasso\&quot;,\&quot;CI\&quot;:\&quot;Carbonia-Iglesias\&quot;,\&quot;CE\&quot;:\&quot;Caserta\&quot;,\&quot;CT\&quot;:\&quot;Catania\&quot;,\&quot;CZ\&quot;:\&quot;Catanzaro\&quot;,\&quot;CH\&quot;:\&quot;Chieti\&quot;,\&quot;CO\&quot;:\&quot;Como\&quot;,\&quot;CS\&quot;:\&quot;Cosenza\&quot;,\&quot;CR\&quot;:\&quot;Cremona\&quot;,\&quot;KR\&quot;:\&quot;Crotone\&quot;,\&quot;CN\&quot;:\&quot;Cuneo\&quot;,\&quot;EN\&quot;:\&quot;Enna\&quot;,\&quot;FM\&quot;:\&quot;Fermo\&quot;,\&quot;FE\&quot;:\&quot;Ferrara\&quot;,\&quot;FI\&quot;:\&quot;Firenze\&quot;,\&quot;FG\&quot;:\&quot;Foggia\&quot;,\&quot;FC\&quot;:\&quot;Forl\\u00ec-Cesena\&quot;,\&quot;FR\&quot;:\&quot;Frosinone\&quot;,\&quot;GE\&quot;:\&quot;Genova\&quot;,\&quot;GO\&quot;:\&quot;Gorizia\&quot;,\&quot;GR\&quot;:\&quot;Grosseto\&quot;,\&quot;IM\&quot;:\&quot;Imperia\&quot;,\&quot;IS\&quot;:\&quot;Isernia\&quot;,\&quot;SP\&quot;:\&quot;La Spezia\&quot;,\&quot;AQ\&quot;:\&quot;L&amp;apos;Aquila\&quot;,\&quot;LT\&quot;:\&quot;Latina\&quot;,\&quot;LE\&quot;:\&quot;Lecce\&quot;,\&quot;LC\&quot;:\&quot;Lecco\&quot;,\&quot;LI\&quot;:\&quot;Livorno\&quot;,\&quot;LO\&quot;:\&quot;Lodi\&quot;,\&quot;LU\&quot;:\&quot;Lucca\&quot;,\&quot;MC\&quot;:\&quot;Macerata\&quot;,\&quot;MN\&quot;:\&quot;Mantova\&quot;,\&quot;MS\&quot;:\&quot;Massa-Carrara\&quot;,\&quot;MT\&quot;:\&quot;Matera\&quot;,\&quot;ME\&quot;:\&quot;Messina\&quot;,\&quot;MI\&quot;:\&quot;Milano\&quot;,\&quot;MO\&quot;:\&quot;Modena\&quot;,\&quot;MB\&quot;:\&quot;Monza e della Brianza\&quot;,\&quot;NA\&quot;:\&quot;Napoli\&quot;,\&quot;NO\&quot;:\&quot;Novara\&quot;,\&quot;NU\&quot;:\&quot;Nuoro\&quot;,\&quot;OT\&quot;:\&quot;Olbia-Tempio\&quot;,\&quot;OR\&quot;:\&quot;Oristano\&quot;,\&quot;PD\&quot;:\&quot;Padova\&quot;,\&quot;PA\&quot;:\&quot;Palermo\&quot;,\&quot;PR\&quot;:\&quot;Parma\&quot;,\&quot;PV\&quot;:\&quot;Pavia\&quot;,\&quot;PG\&quot;:\&quot;Perugia\&quot;,\&quot;PU\&quot;:\&quot;Pesaro e Urbino\&quot;,\&quot;PE\&quot;:\&quot;Pescara\&quot;,\&quot;PC\&quot;:\&quot;Piacenza\&quot;,\&quot;PI\&quot;:\&quot;Pisa\&quot;,\&quot;PT\&quot;:\&quot;Pistoia\&quot;,\&quot;PN\&quot;:\&quot;Pordenone\&quot;,\&quot;PZ\&quot;:\&quot;Potenza\&quot;,\&quot;PO\&quot;:\&quot;Prato\&quot;,\&quot;RG\&quot;:\&quot;Ragusa\&quot;,\&quot;RA\&quot;:\&quot;Ravenna\&quot;,\&quot;RC\&quot;:\&quot;Reggio Calabria\&quot;,\&quot;RE\&quot;:\&quot;Reggio Emilia\&quot;,\&quot;RI\&quot;:\&quot;Rieti\&quot;,\&quot;RN\&quot;:\&quot;Rimini\&quot;,\&quot;RM\&quot;:\&quot;Roma\&quot;,\&quot;RO\&quot;:\&quot;Rovigo\&quot;,\&quot;SA\&quot;:\&quot;Salerno\&quot;,\&quot;VS\&quot;:\&quot;Medio Campidano\&quot;,\&quot;SS\&quot;:\&quot;Sassari\&quot;,\&quot;SV\&quot;:\&quot;Savona\&quot;,\&quot;SI\&quot;:\&quot;Siena\&quot;,\&quot;SR\&quot;:\&quot;Siracusa\&quot;,\&quot;SO\&quot;:\&quot;Sondrio\&quot;,\&quot;TA\&quot;:\&quot;Taranto\&quot;,\&quot;TE\&quot;:\&quot;Teramo\&quot;,\&quot;TR\&quot;:\&quot;Terni\&quot;,\&quot;TO\&quot;:\&quot;Torino\&quot;,\&quot;OG\&quot;:\&quot;Ogliastra\&quot;,\&quot;TP\&quot;:\&quot;Trapani\&quot;,\&quot;TN\&quot;:\&quot;Trento\&quot;,\&quot;TV\&quot;:\&quot;Treviso\&quot;,\&quot;TS\&quot;:\&quot;Trieste\&quot;,\&quot;UD\&quot;:\&quot;Udine\&quot;,\&quot;VA\&quot;:\&quot;Varese\&quot;,\&quot;VE\&quot;:\&quot;Venezia\&quot;,\&quot;VB\&quot;:\&quot;Verbano-Cusio-Ossola\&quot;,\&quot;VC\&quot;:\&quot;Vercelli\&quot;,\&quot;VR\&quot;:\&quot;Verona\&quot;,\&quot;VV\&quot;:\&quot;Vibo Valentia\&quot;,\&quot;VI\&quot;:\&quot;Vicenza\&quot;,\&quot;VT\&quot;:\&quot;Viterbo\&quot;},\&quot;JP\&quot;:{\&quot;JP01\&quot;:\&quot;Hokkaido\&quot;,\&quot;JP02\&quot;:\&quot;Aomori\&quot;,\&quot;JP03\&quot;:\&quot;Iwate\&quot;,\&quot;JP04\&quot;:\&quot;Miyagi\&quot;,\&quot;JP05\&quot;:\&quot;Akita\&quot;,\&quot;JP06\&quot;:\&quot;Yamagata\&quot;,\&quot;JP07\&quot;:\&quot;Fukushima\&quot;,\&quot;JP08\&quot;:\&quot;Ibaraki\&quot;,\&quot;JP09\&quot;:\&quot;Tochigi\&quot;,\&quot;JP10\&quot;:\&quot;Gunma\&quot;,\&quot;JP11\&quot;:\&quot;Saitama\&quot;,\&quot;JP12\&quot;:\&quot;Chiba\&quot;,\&quot;JP13\&quot;:\&quot;Tokyo\&quot;,\&quot;JP14\&quot;:\&quot;Kanagawa\&quot;,\&quot;JP15\&quot;:\&quot;Niigata\&quot;,\&quot;JP16\&quot;:\&quot;Toyama\&quot;,\&quot;JP17\&quot;:\&quot;Ishikawa\&quot;,\&quot;JP18\&quot;:\&quot;Fukui\&quot;,\&quot;JP19\&quot;:\&quot;Yamanashi\&quot;,\&quot;JP20\&quot;:\&quot;Nagano\&quot;,\&quot;JP21\&quot;:\&quot;Gifu\&quot;,\&quot;JP22\&quot;:\&quot;Shizuoka\&quot;,\&quot;JP23\&quot;:\&quot;Aichi\&quot;,\&quot;JP24\&quot;:\&quot;Mie\&quot;,\&quot;JP25\&quot;:\&quot;Shiga\&quot;,\&quot;JP26\&quot;:\&quot;Kyoto\&quot;,\&quot;JP27\&quot;:\&quot;Osaka\&quot;,\&quot;JP28\&quot;:\&quot;Hyogo\&quot;,\&quot;JP29\&quot;:\&quot;Nara\&quot;,\&quot;JP30\&quot;:\&quot;Wakayama\&quot;,\&quot;JP31\&quot;:\&quot;Tottori\&quot;,\&quot;JP32\&quot;:\&quot;Shimane\&quot;,\&quot;JP33\&quot;:\&quot;Okayama\&quot;,\&quot;JP34\&quot;:\&quot;Hiroshima\&quot;,\&quot;JP35\&quot;:\&quot;Yamaguchi\&quot;,\&quot;JP36\&quot;:\&quot;Tokushima\&quot;,\&quot;JP37\&quot;:\&quot;Kagawa\&quot;,\&quot;JP38\&quot;:\&quot;Ehime\&quot;,\&quot;JP39\&quot;:\&quot;Kochi\&quot;,\&quot;JP40\&quot;:\&quot;Fukuoka\&quot;,\&quot;JP41\&quot;:\&quot;Saga\&quot;,\&quot;JP42\&quot;:\&quot;Nagasaki\&quot;,\&quot;JP43\&quot;:\&quot;Kumamoto\&quot;,\&quot;JP44\&quot;:\&quot;Oita\&quot;,\&quot;JP45\&quot;:\&quot;Miyazaki\&quot;,\&quot;JP46\&quot;:\&quot;Kagoshima\&quot;,\&quot;JP47\&quot;:\&quot;Okinawa\&quot;},\&quot;MY\&quot;:{\&quot;JHR\&quot;:\&quot;Johor\&quot;,\&quot;KDH\&quot;:\&quot;Kedah\&quot;,\&quot;KTN\&quot;:\&quot;Kelantan\&quot;,\&quot;LBN\&quot;:\&quot;Labuan\&quot;,\&quot;MLK\&quot;:\&quot;Malacca (Melaka)\&quot;,\&quot;NSN\&quot;:\&quot;Negeri Sembilan\&quot;,\&quot;PHG\&quot;:\&quot;Pahang\&quot;,\&quot;PNG\&quot;:\&quot;Penang (Pulau Pinang)\&quot;,\&quot;PRK\&quot;:\&quot;Perak\&quot;,\&quot;PLS\&quot;:\&quot;Perlis\&quot;,\&quot;SBH\&quot;:\&quot;Sabah\&quot;,\&quot;SWK\&quot;:\&quot;Sarawak\&quot;,\&quot;SGR\&quot;:\&quot;Selangor\&quot;,\&quot;TRG\&quot;:\&quot;Terengganu\&quot;,\&quot;PJY\&quot;:\&quot;Putrajaya\&quot;,\&quot;KUL\&quot;:\&quot;Kuala Lumpur\&quot;},\&quot;MX\&quot;:{\&quot;Distrito Federal\&quot;:\&quot;Distrito Federal\&quot;,\&quot;Jalisco\&quot;:\&quot;Jalisco\&quot;,\&quot;Nuevo Leon\&quot;:\&quot;Nuevo Le\\u00f3n\&quot;,\&quot;Aguascalientes\&quot;:\&quot;Aguascalientes\&quot;,\&quot;Baja California\&quot;:\&quot;Baja California\&quot;,\&quot;Baja California Sur\&quot;:\&quot;Baja California Sur\&quot;,\&quot;Campeche\&quot;:\&quot;Campeche\&quot;,\&quot;Chiapas\&quot;:\&quot;Chiapas\&quot;,\&quot;Chihuahua\&quot;:\&quot;Chihuahua\&quot;,\&quot;Coahuila\&quot;:\&quot;Coahuila\&quot;,\&quot;Colima\&quot;:\&quot;Colima\&quot;,\&quot;Durango\&quot;:\&quot;Durango\&quot;,\&quot;Guanajuato\&quot;:\&quot;Guanajuato\&quot;,\&quot;Guerrero\&quot;:\&quot;Guerrero\&quot;,\&quot;Hidalgo\&quot;:\&quot;Hidalgo\&quot;,\&quot;Estado de Mexico\&quot;:\&quot;Edo. de M\\u00e9xico\&quot;,\&quot;Michoacan\&quot;:\&quot;Michoac\\u00e1n\&quot;,\&quot;Morelos\&quot;:\&quot;Morelos\&quot;,\&quot;Nayarit\&quot;:\&quot;Nayarit\&quot;,\&quot;Oaxaca\&quot;:\&quot;Oaxaca\&quot;,\&quot;Puebla\&quot;:\&quot;Puebla\&quot;,\&quot;Queretaro\&quot;:\&quot;Quer\\u00e9taro\&quot;,\&quot;Quintana Roo\&quot;:\&quot;Quintana Roo\&quot;,\&quot;San Luis Potosi\&quot;:\&quot;San Luis Potos\\u00ed\&quot;,\&quot;Sinaloa\&quot;:\&quot;Sinaloa\&quot;,\&quot;Sonora\&quot;:\&quot;Sonora\&quot;,\&quot;Tabasco\&quot;:\&quot;Tabasco\&quot;,\&quot;Tamaulipas\&quot;:\&quot;Tamaulipas\&quot;,\&quot;Tlaxcala\&quot;:\&quot;Tlaxcala\&quot;,\&quot;Veracruz\&quot;:\&quot;Veracruz\&quot;,\&quot;Yucatan\&quot;:\&quot;Yucat\\u00e1n\&quot;,\&quot;Zacatecas\&quot;:\&quot;Zacatecas\&quot;},\&quot;NP\&quot;:{\&quot;BAG\&quot;:\&quot;Bagmati\&quot;,\&quot;BHE\&quot;:\&quot;Bheri\&quot;,\&quot;DHA\&quot;:\&quot;Dhawalagiri\&quot;,\&quot;GAN\&quot;:\&quot;Gandaki\&quot;,\&quot;JAN\&quot;:\&quot;Janakpur\&quot;,\&quot;KAR\&quot;:\&quot;Karnali\&quot;,\&quot;KOS\&quot;:\&quot;Koshi\&quot;,\&quot;LUM\&quot;:\&quot;Lumbini\&quot;,\&quot;MAH\&quot;:\&quot;Mahakali\&quot;,\&quot;MEC\&quot;:\&quot;Mechi\&quot;,\&quot;NAR\&quot;:\&quot;Narayani\&quot;,\&quot;RAP\&quot;:\&quot;Rapti\&quot;,\&quot;SAG\&quot;:\&quot;Sagarmatha\&quot;,\&quot;SET\&quot;:\&quot;Seti\&quot;},\&quot;NZ\&quot;:{\&quot;NL\&quot;:\&quot;Northland\&quot;,\&quot;AK\&quot;:\&quot;Auckland\&quot;,\&quot;WA\&quot;:\&quot;Waikato\&quot;,\&quot;BP\&quot;:\&quot;Bay of Plenty\&quot;,\&quot;TK\&quot;:\&quot;Taranaki\&quot;,\&quot;GI\&quot;:\&quot;Gisborne\&quot;,\&quot;HB\&quot;:\&quot;Hawke\u2019s Bay\&quot;,\&quot;MW\&quot;:\&quot;Manawatu-Wanganui\&quot;,\&quot;WE\&quot;:\&quot;Wellington\&quot;,\&quot;NS\&quot;:\&quot;Nelson\&quot;,\&quot;MB\&quot;:\&quot;Marlborough\&quot;,\&quot;TM\&quot;:\&quot;Tasman\&quot;,\&quot;WC\&quot;:\&quot;West Coast\&quot;,\&quot;CT\&quot;:\&quot;Canterbury\&quot;,\&quot;OT\&quot;:\&quot;Otago\&quot;,\&quot;SL\&quot;:\&quot;Southland\&quot;},\&quot;PE\&quot;:{\&quot;CAL\&quot;:\&quot;El Callao\&quot;,\&quot;LMA\&quot;:\&quot;Municipalidad Metropolitana de Lima\&quot;,\&quot;AMA\&quot;:\&quot;Amazonas\&quot;,\&quot;ANC\&quot;:\&quot;Ancash\&quot;,\&quot;APU\&quot;:\&quot;Apur\u00edmac\&quot;,\&quot;ARE\&quot;:\&quot;Arequipa\&quot;,\&quot;AYA\&quot;:\&quot;Ayacucho\&quot;,\&quot;CAJ\&quot;:\&quot;Cajamarca\&quot;,\&quot;CUS\&quot;:\&quot;Cusco\&quot;,\&quot;HUV\&quot;:\&quot;Huancavelica\&quot;,\&quot;HUC\&quot;:\&quot;Hu\u00e1nuco\&quot;,\&quot;ICA\&quot;:\&quot;Ica\&quot;,\&quot;JUN\&quot;:\&quot;Jun\u00edn\&quot;,\&quot;LAL\&quot;:\&quot;La Libertad\&quot;,\&quot;LAM\&quot;:\&quot;Lambayeque\&quot;,\&quot;LIM\&quot;:\&quot;Lima\&quot;,\&quot;LOR\&quot;:\&quot;Loreto\&quot;,\&quot;MDD\&quot;:\&quot;Madre de Dios\&quot;,\&quot;MOQ\&quot;:\&quot;Moquegua\&quot;,\&quot;PAS\&quot;:\&quot;Pasco\&quot;,\&quot;PIU\&quot;:\&quot;Piura\&quot;,\&quot;PUN\&quot;:\&quot;Puno\&quot;,\&quot;SAM\&quot;:\&quot;San Mart\u00edn\&quot;,\&quot;TAC\&quot;:\&quot;Tacna\&quot;,\&quot;TUM\&quot;:\&quot;Tumbes\&quot;,\&quot;UCA\&quot;:\&quot;Ucayali\&quot;},\&quot;PH\&quot;:{\&quot;ABR\&quot;:\&quot;Abra\&quot;,\&quot;AGN\&quot;:\&quot;Agusan del Norte\&quot;,\&quot;AGS\&quot;:\&quot;Agusan del Sur\&quot;,\&quot;AKL\&quot;:\&quot;Aklan\&quot;,\&quot;ALB\&quot;:\&quot;Albay\&quot;,\&quot;ANT\&quot;:\&quot;Antique\&quot;,\&quot;APA\&quot;:\&quot;Apayao\&quot;,\&quot;AUR\&quot;:\&quot;Aurora\&quot;,\&quot;BAS\&quot;:\&quot;Basilan\&quot;,\&quot;BAN\&quot;:\&quot;Bataan\&quot;,\&quot;BTN\&quot;:\&quot;Batanes\&quot;,\&quot;BTG\&quot;:\&quot;Batangas\&quot;,\&quot;BEN\&quot;:\&quot;Benguet\&quot;,\&quot;BIL\&quot;:\&quot;Biliran\&quot;,\&quot;BOH\&quot;:\&quot;Bohol\&quot;,\&quot;BUK\&quot;:\&quot;Bukidnon\&quot;,\&quot;BUL\&quot;:\&quot;Bulacan\&quot;,\&quot;CAG\&quot;:\&quot;Cagayan\&quot;,\&quot;CAN\&quot;:\&quot;Camarines Norte\&quot;,\&quot;CAS\&quot;:\&quot;Camarines Sur\&quot;,\&quot;CAM\&quot;:\&quot;Camiguin\&quot;,\&quot;CAP\&quot;:\&quot;Capiz\&quot;,\&quot;CAT\&quot;:\&quot;Catanduanes\&quot;,\&quot;CAV\&quot;:\&quot;Cavite\&quot;,\&quot;CEB\&quot;:\&quot;Cebu\&quot;,\&quot;COM\&quot;:\&quot;Compostela Valley\&quot;,\&quot;NCO\&quot;:\&quot;Cotabato\&quot;,\&quot;DAV\&quot;:\&quot;Davao del Norte\&quot;,\&quot;DAS\&quot;:\&quot;Davao del Sur\&quot;,\&quot;DAC\&quot;:\&quot;Davao Occidental\&quot;,\&quot;DAO\&quot;:\&quot;Davao Oriental\&quot;,\&quot;DIN\&quot;:\&quot;Dinagat Islands\&quot;,\&quot;EAS\&quot;:\&quot;Eastern Samar\&quot;,\&quot;GUI\&quot;:\&quot;Guimaras\&quot;,\&quot;IFU\&quot;:\&quot;Ifugao\&quot;,\&quot;ILN\&quot;:\&quot;Ilocos Norte\&quot;,\&quot;ILS\&quot;:\&quot;Ilocos Sur\&quot;,\&quot;ILI\&quot;:\&quot;Iloilo\&quot;,\&quot;ISA\&quot;:\&quot;Isabela\&quot;,\&quot;KAL\&quot;:\&quot;Kalinga\&quot;,\&quot;LUN\&quot;:\&quot;La Union\&quot;,\&quot;LAG\&quot;:\&quot;Laguna\&quot;,\&quot;LAN\&quot;:\&quot;Lanao del Norte\&quot;,\&quot;LAS\&quot;:\&quot;Lanao del Sur\&quot;,\&quot;LEY\&quot;:\&quot;Leyte\&quot;,\&quot;MAG\&quot;:\&quot;Maguindanao\&quot;,\&quot;MAD\&quot;:\&quot;Marinduque\&quot;,\&quot;MAS\&quot;:\&quot;Masbate\&quot;,\&quot;MSC\&quot;:\&quot;Misamis Occidental\&quot;,\&quot;MSR\&quot;:\&quot;Misamis Oriental\&quot;,\&quot;MOU\&quot;:\&quot;Mountain Province\&quot;,\&quot;NEC\&quot;:\&quot;Negros Occidental\&quot;,\&quot;NER\&quot;:\&quot;Negros Oriental\&quot;,\&quot;NSA\&quot;:\&quot;Northern Samar\&quot;,\&quot;NUE\&quot;:\&quot;Nueva Ecija\&quot;,\&quot;NUV\&quot;:\&quot;Nueva Vizcaya\&quot;,\&quot;MDC\&quot;:\&quot;Occidental Mindoro\&quot;,\&quot;MDR\&quot;:\&quot;Oriental Mindoro\&quot;,\&quot;PLW\&quot;:\&quot;Palawan\&quot;,\&quot;PAM\&quot;:\&quot;Pampanga\&quot;,\&quot;PAN\&quot;:\&quot;Pangasinan\&quot;,\&quot;QUE\&quot;:\&quot;Quezon\&quot;,\&quot;QUI\&quot;:\&quot;Quirino\&quot;,\&quot;RIZ\&quot;:\&quot;Rizal\&quot;,\&quot;ROM\&quot;:\&quot;Romblon\&quot;,\&quot;WSA\&quot;:\&quot;Samar\&quot;,\&quot;SAR\&quot;:\&quot;Sarangani\&quot;,\&quot;SIQ\&quot;:\&quot;Siquijor\&quot;,\&quot;SOR\&quot;:\&quot;Sorsogon\&quot;,\&quot;SCO\&quot;:\&quot;South Cotabato\&quot;,\&quot;SLE\&quot;:\&quot;Southern Leyte\&quot;,\&quot;SUK\&quot;:\&quot;Sultan Kudarat\&quot;,\&quot;SLU\&quot;:\&quot;Sulu\&quot;,\&quot;SUN\&quot;:\&quot;Surigao del Norte\&quot;,\&quot;SUR\&quot;:\&quot;Surigao del Sur\&quot;,\&quot;TAR\&quot;:\&quot;Tarlac\&quot;,\&quot;TAW\&quot;:\&quot;Tawi-Tawi\&quot;,\&quot;ZMB\&quot;:\&quot;Zambales\&quot;,\&quot;ZAN\&quot;:\&quot;Zamboanga del Norte\&quot;,\&quot;ZAS\&quot;:\&quot;Zamboanga del Sur\&quot;,\&quot;ZSI\&quot;:\&quot;Zamboanga Sibugay\&quot;,\&quot;00\&quot;:\&quot;Metro Manila\&quot;},\&quot;ZA\&quot;:{\&quot;EC\&quot;:\&quot;Eastern Cape\&quot;,\&quot;FS\&quot;:\&quot;Free State\&quot;,\&quot;GP\&quot;:\&quot;Gauteng\&quot;,\&quot;KZN\&quot;:\&quot;KwaZulu-Natal\&quot;,\&quot;LP\&quot;:\&quot;Limpopo\&quot;,\&quot;MP\&quot;:\&quot;Mpumalanga\&quot;,\&quot;NC\&quot;:\&quot;Northern Cape\&quot;,\&quot;NW\&quot;:\&quot;North West\&quot;,\&quot;WC\&quot;:\&quot;Western Cape\&quot;},\&quot;ES\&quot;:{\&quot;C\&quot;:\&quot;A Coru\u00f1a\&quot;,\&quot;VI\&quot;:\&quot;Araba\\\/\u00c1lava\&quot;,\&quot;AB\&quot;:\&quot;Albacete\&quot;,\&quot;A\&quot;:\&quot;Alicante\&quot;,\&quot;AL\&quot;:\&quot;Almer\u00eda\&quot;,\&quot;O\&quot;:\&quot;Asturias\&quot;,\&quot;AV\&quot;:\&quot;\u00c1vila\&quot;,\&quot;BA\&quot;:\&quot;Badajoz\&quot;,\&quot;PM\&quot;:\&quot;Baleares\&quot;,\&quot;B\&quot;:\&quot;Barcelona\&quot;,\&quot;BU\&quot;:\&quot;Burgos\&quot;,\&quot;CC\&quot;:\&quot;C\u00e1ceres\&quot;,\&quot;CA\&quot;:\&quot;C\u00e1diz\&quot;,\&quot;S\&quot;:\&quot;Cantabria\&quot;,\&quot;CS\&quot;:\&quot;Castell\u00f3n\&quot;,\&quot;CE\&quot;:\&quot;Ceuta\&quot;,\&quot;CR\&quot;:\&quot;Ciudad Real\&quot;,\&quot;CO\&quot;:\&quot;C\u00f3rdoba\&quot;,\&quot;CU\&quot;:\&quot;Cuenca\&quot;,\&quot;GI\&quot;:\&quot;Girona\&quot;,\&quot;GR\&quot;:\&quot;Granada\&quot;,\&quot;GU\&quot;:\&quot;Guadalajara\&quot;,\&quot;SS\&quot;:\&quot;Gipuzkoa\&quot;,\&quot;H\&quot;:\&quot;Huelva\&quot;,\&quot;HU\&quot;:\&quot;Huesca\&quot;,\&quot;J\&quot;:\&quot;Ja\u00e9n\&quot;,\&quot;LO\&quot;:\&quot;La Rioja\&quot;,\&quot;GC\&quot;:\&quot;Las Palmas\&quot;,\&quot;LE\&quot;:\&quot;Le\u00f3n\&quot;,\&quot;L\&quot;:\&quot;Lleida\&quot;,\&quot;LU\&quot;:\&quot;Lugo\&quot;,\&quot;M\&quot;:\&quot;Madrid\&quot;,\&quot;MA\&quot;:\&quot;M\u00e1laga\&quot;,\&quot;ML\&quot;:\&quot;Melilla\&quot;,\&quot;MU\&quot;:\&quot;Murcia\&quot;,\&quot;NA\&quot;:\&quot;Navarra\&quot;,\&quot;OR\&quot;:\&quot;Ourense\&quot;,\&quot;P\&quot;:\&quot;Palencia\&quot;,\&quot;PO\&quot;:\&quot;Pontevedra\&quot;,\&quot;SA\&quot;:\&quot;Salamanca\&quot;,\&quot;TF\&quot;:\&quot;Santa Cruz de Tenerife\&quot;,\&quot;SG\&quot;:\&quot;Segovia\&quot;,\&quot;SE\&quot;:\&quot;Sevilla\&quot;,\&quot;SO\&quot;:\&quot;Soria\&quot;,\&quot;T\&quot;:\&quot;Tarragona\&quot;,\&quot;TE\&quot;:\&quot;Teruel\&quot;,\&quot;TO\&quot;:\&quot;Toledo\&quot;,\&quot;V\&quot;:\&quot;Valencia\&quot;,\&quot;VA\&quot;:\&quot;Valladolid\&quot;,\&quot;BI\&quot;:\&quot;Bizkaia\&quot;,\&quot;ZA\&quot;:\&quot;Zamora\&quot;,\&quot;Z\&quot;:\&quot;Zaragoza\&quot;},\&quot;TH\&quot;:{\&quot;TH-37\&quot;:\&quot;Amnat Charoen (\u0e2d\u0e33\u0e19\u0e32\u0e08\u0e40\u0e08\u0e23\u0e34\u0e0d)\&quot;,\&quot;TH-15\&quot;:\&quot;Ang Thong (\u0e2d\u0e48\u0e32\u0e07\u0e17\u0e2d\u0e07)\&quot;,\&quot;TH-14\&quot;:\&quot;Ayutthaya (\u0e1e\u0e23\u0e30\u0e19\u0e04\u0e23\u0e28\u0e23\u0e35\u0e2d\u0e22\u0e38\u0e18\u0e22\u0e32)\&quot;,\&quot;TH-10\&quot;:\&quot;Bangkok (\u0e01\u0e23\u0e38\u0e07\u0e40\u0e17\u0e1e\u0e21\u0e2b\u0e32\u0e19\u0e04\u0e23)\&quot;,\&quot;TH-38\&quot;:\&quot;Bueng Kan (\u0e1a\u0e36\u0e07\u0e01\u0e32\u0e2c)\&quot;,\&quot;TH-31\&quot;:\&quot;Buri Ram (\u0e1a\u0e38\u0e23\u0e35\u0e23\u0e31\u0e21\u0e22\u0e4c)\&quot;,\&quot;TH-24\&quot;:\&quot;Chachoengsao (\u0e09\u0e30\u0e40\u0e0a\u0e34\u0e07\u0e40\u0e17\u0e23\u0e32)\&quot;,\&quot;TH-18\&quot;:\&quot;Chai Nat (\u0e0a\u0e31\u0e22\u0e19\u0e32\u0e17)\&quot;,\&quot;TH-36\&quot;:\&quot;Chaiyaphum (\u0e0a\u0e31\u0e22\u0e20\u0e39\u0e21\u0e34)\&quot;,\&quot;TH-22\&quot;:\&quot;Chanthaburi (\u0e08\u0e31\u0e19\u0e17\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-50\&quot;:\&quot;Chiang Mai (\u0e40\u0e0a\u0e35\u0e22\u0e07\u0e43\u0e2b\u0e21\u0e48)\&quot;,\&quot;TH-57\&quot;:\&quot;Chiang Rai (\u0e40\u0e0a\u0e35\u0e22\u0e07\u0e23\u0e32\u0e22)\&quot;,\&quot;TH-20\&quot;:\&quot;Chonburi (\u0e0a\u0e25\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-86\&quot;:\&quot;Chumphon (\u0e0a\u0e38\u0e21\u0e1e\u0e23)\&quot;,\&quot;TH-46\&quot;:\&quot;Kalasin (\u0e01\u0e32\u0e2c\u0e2a\u0e34\u0e19\u0e18\u0e38\u0e4c)\&quot;,\&quot;TH-62\&quot;:\&quot;Kamphaeng Phet (\u0e01\u0e33\u0e41\u0e1e\u0e07\u0e40\u0e1e\u0e0a\u0e23)\&quot;,\&quot;TH-71\&quot;:\&quot;Kanchanaburi (\u0e01\u0e32\u0e0d\u0e08\u0e19\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-40\&quot;:\&quot;Khon Kaen (\u0e02\u0e2d\u0e19\u0e41\u0e01\u0e48\u0e19)\&quot;,\&quot;TH-81\&quot;:\&quot;Krabi (\u0e01\u0e23\u0e30\u0e1a\u0e35\u0e48)\&quot;,\&quot;TH-52\&quot;:\&quot;Lampang (\u0e25\u0e33\u0e1b\u0e32\u0e07)\&quot;,\&quot;TH-51\&quot;:\&quot;Lamphun (\u0e25\u0e33\u0e1e\u0e39\u0e19)\&quot;,\&quot;TH-42\&quot;:\&quot;Loei (\u0e40\u0e25\u0e22)\&quot;,\&quot;TH-16\&quot;:\&quot;Lopburi (\u0e25\u0e1e\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-58\&quot;:\&quot;Mae Hong Son (\u0e41\u0e21\u0e48\u0e2e\u0e48\u0e2d\u0e07\u0e2a\u0e2d\u0e19)\&quot;,\&quot;TH-44\&quot;:\&quot;Maha Sarakham (\u0e21\u0e2b\u0e32\u0e2a\u0e32\u0e23\u0e04\u0e32\u0e21)\&quot;,\&quot;TH-49\&quot;:\&quot;Mukdahan (\u0e21\u0e38\u0e01\u0e14\u0e32\u0e2b\u0e32\u0e23)\&quot;,\&quot;TH-26\&quot;:\&quot;Nakhon Nayok (\u0e19\u0e04\u0e23\u0e19\u0e32\u0e22\u0e01)\&quot;,\&quot;TH-73\&quot;:\&quot;Nakhon Pathom (\u0e19\u0e04\u0e23\u0e1b\u0e10\u0e21)\&quot;,\&quot;TH-48\&quot;:\&quot;Nakhon Phanom (\u0e19\u0e04\u0e23\u0e1e\u0e19\u0e21)\&quot;,\&quot;TH-30\&quot;:\&quot;Nakhon Ratchasima (\u0e19\u0e04\u0e23\u0e23\u0e32\u0e0a\u0e2a\u0e35\u0e21\u0e32)\&quot;,\&quot;TH-60\&quot;:\&quot;Nakhon Sawan (\u0e19\u0e04\u0e23\u0e2a\u0e27\u0e23\u0e23\u0e04\u0e4c)\&quot;,\&quot;TH-80\&quot;:\&quot;Nakhon Si Thammarat (\u0e19\u0e04\u0e23\u0e28\u0e23\u0e35\u0e18\u0e23\u0e23\u0e21\u0e23\u0e32\u0e0a)\&quot;,\&quot;TH-55\&quot;:\&quot;Nan (\u0e19\u0e48\u0e32\u0e19)\&quot;,\&quot;TH-96\&quot;:\&quot;Narathiwat (\u0e19\u0e23\u0e32\u0e18\u0e34\u0e27\u0e32\u0e2a)\&quot;,\&quot;TH-39\&quot;:\&quot;Nong Bua Lam Phu (\u0e2b\u0e19\u0e2d\u0e07\u0e1a\u0e31\u0e27\u0e25\u0e33\u0e20\u0e39)\&quot;,\&quot;TH-43\&quot;:\&quot;Nong Khai (\u0e2b\u0e19\u0e2d\u0e07\u0e04\u0e32\u0e22)\&quot;,\&quot;TH-12\&quot;:\&quot;Nonthaburi (\u0e19\u0e19\u0e17\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-13\&quot;:\&quot;Pathum Thani (\u0e1b\u0e17\u0e38\u0e21\u0e18\u0e32\u0e19\u0e35)\&quot;,\&quot;TH-94\&quot;:\&quot;Pattani (\u0e1b\u0e31\u0e15\u0e15\u0e32\u0e19\u0e35)\&quot;,\&quot;TH-82\&quot;:\&quot;Phang Nga (\u0e1e\u0e31\u0e07\u0e07\u0e32)\&quot;,\&quot;TH-93\&quot;:\&quot;Phatthalung (\u0e1e\u0e31\u0e17\u0e25\u0e38\u0e07)\&quot;,\&quot;TH-56\&quot;:\&quot;Phayao (\u0e1e\u0e30\u0e40\u0e22\u0e32)\&quot;,\&quot;TH-67\&quot;:\&quot;Phetchabun (\u0e40\u0e1e\u0e0a\u0e23\u0e1a\u0e39\u0e23\u0e13\u0e4c)\&quot;,\&quot;TH-76\&quot;:\&quot;Phetchaburi (\u0e40\u0e1e\u0e0a\u0e23\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-66\&quot;:\&quot;Phichit (\u0e1e\u0e34\u0e08\u0e34\u0e15\u0e23)\&quot;,\&quot;TH-65\&quot;:\&quot;Phitsanulok (\u0e1e\u0e34\u0e29\u0e13\u0e38\u0e42\u0e25\u0e01)\&quot;,\&quot;TH-54\&quot;:\&quot;Phrae (\u0e41\u0e1e\u0e23\u0e48)\&quot;,\&quot;TH-83\&quot;:\&quot;Phuket (\u0e20\u0e39\u0e40\u0e01\u0e47\u0e15)\&quot;,\&quot;TH-25\&quot;:\&quot;Prachin Buri (\u0e1b\u0e23\u0e32\u0e08\u0e35\u0e19\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-77\&quot;:\&quot;Prachuap Khiri Khan (\u0e1b\u0e23\u0e30\u0e08\u0e27\u0e1a\u0e04\u0e35\u0e23\u0e35\u0e02\u0e31\u0e19\u0e18\u0e4c)\&quot;,\&quot;TH-85\&quot;:\&quot;Ranong (\u0e23\u0e30\u0e19\u0e2d\u0e07)\&quot;,\&quot;TH-70\&quot;:\&quot;Ratchaburi (\u0e23\u0e32\u0e0a\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-21\&quot;:\&quot;Rayong (\u0e23\u0e30\u0e22\u0e2d\u0e07)\&quot;,\&quot;TH-45\&quot;:\&quot;Roi Et (\u0e23\u0e49\u0e2d\u0e22\u0e40\u0e2d\u0e47\u0e14)\&quot;,\&quot;TH-27\&quot;:\&quot;Sa Kaeo (\u0e2a\u0e23\u0e30\u0e41\u0e01\u0e49\u0e27)\&quot;,\&quot;TH-47\&quot;:\&quot;Sakon Nakhon (\u0e2a\u0e01\u0e25\u0e19\u0e04\u0e23)\&quot;,\&quot;TH-11\&quot;:\&quot;Samut Prakan (\u0e2a\u0e21\u0e38\u0e17\u0e23\u0e1b\u0e23\u0e32\u0e01\u0e32\u0e23)\&quot;,\&quot;TH-74\&quot;:\&quot;Samut Sakhon (\u0e2a\u0e21\u0e38\u0e17\u0e23\u0e2a\u0e32\u0e04\u0e23)\&quot;,\&quot;TH-75\&quot;:\&quot;Samut Songkhram (\u0e2a\u0e21\u0e38\u0e17\u0e23\u0e2a\u0e07\u0e04\u0e23\u0e32\u0e21)\&quot;,\&quot;TH-19\&quot;:\&quot;Saraburi (\u0e2a\u0e23\u0e30\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-91\&quot;:\&quot;Satun (\u0e2a\u0e15\u0e39\u0e25)\&quot;,\&quot;TH-17\&quot;:\&quot;Sing Buri (\u0e2a\u0e34\u0e07\u0e2b\u0e4c\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-33\&quot;:\&quot;Sisaket (\u0e28\u0e23\u0e35\u0e2a\u0e30\u0e40\u0e01\u0e29)\&quot;,\&quot;TH-90\&quot;:\&quot;Songkhla (\u0e2a\u0e07\u0e02\u0e25\u0e32)\&quot;,\&quot;TH-64\&quot;:\&quot;Sukhothai (\u0e2a\u0e38\u0e42\u0e02\u0e17\u0e31\u0e22)\&quot;,\&quot;TH-72\&quot;:\&quot;Suphan Buri (\u0e2a\u0e38\u0e1e\u0e23\u0e23\u0e13\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-84\&quot;:\&quot;Surat Thani (\u0e2a\u0e38\u0e23\u0e32\u0e29\u0e0e\u0e23\u0e4c\u0e18\u0e32\u0e19\u0e35)\&quot;,\&quot;TH-32\&quot;:\&quot;Surin (\u0e2a\u0e38\u0e23\u0e34\u0e19\u0e17\u0e23\u0e4c)\&quot;,\&quot;TH-63\&quot;:\&quot;Tak (\u0e15\u0e32\u0e01)\&quot;,\&quot;TH-92\&quot;:\&quot;Trang (\u0e15\u0e23\u0e31\u0e07)\&quot;,\&quot;TH-23\&quot;:\&quot;Trat (\u0e15\u0e23\u0e32\u0e14)\&quot;,\&quot;TH-34\&quot;:\&quot;Ubon Ratchathani (\u0e2d\u0e38\u0e1a\u0e25\u0e23\u0e32\u0e0a\u0e18\u0e32\u0e19\u0e35)\&quot;,\&quot;TH-41\&quot;:\&quot;Udon Thani (\u0e2d\u0e38\u0e14\u0e23\u0e18\u0e32\u0e19\u0e35)\&quot;,\&quot;TH-61\&quot;:\&quot;Uthai Thani (\u0e2d\u0e38\u0e17\u0e31\u0e22\u0e18\u0e32\u0e19\u0e35)\&quot;,\&quot;TH-53\&quot;:\&quot;Uttaradit (\u0e2d\u0e38\u0e15\u0e23\u0e14\u0e34\u0e15\u0e16\u0e4c)\&quot;,\&quot;TH-95\&quot;:\&quot;Yala (\u0e22\u0e30\u0e25\u0e32)\&quot;,\&quot;TH-35\&quot;:\&quot;Yasothon (\u0e22\u0e42\u0e2a\u0e18\u0e23)\&quot;},\&quot;TR\&quot;:{\&quot;TR01\&quot;:\&quot;Adana\&quot;,\&quot;TR02\&quot;:\&quot;Ad\u0131yaman\&quot;,\&quot;TR03\&quot;:\&quot;Afyon\&quot;,\&quot;TR04\&quot;:\&quot;A\u011fr\u0131\&quot;,\&quot;TR05\&quot;:\&quot;Amasya\&quot;,\&quot;TR06\&quot;:\&quot;Ankara\&quot;,\&quot;TR07\&quot;:\&quot;Antalya\&quot;,\&quot;TR08\&quot;:\&quot;Artvin\&quot;,\&quot;TR09\&quot;:\&quot;Ayd\u0131n\&quot;,\&quot;TR10\&quot;:\&quot;Bal\u0131kesir\&quot;,\&quot;TR11\&quot;:\&quot;Bilecik\&quot;,\&quot;TR12\&quot;:\&quot;Bing\u00f6l\&quot;,\&quot;TR13\&quot;:\&quot;Bitlis\&quot;,\&quot;TR14\&quot;:\&quot;Bolu\&quot;,\&quot;TR15\&quot;:\&quot;Burdur\&quot;,\&quot;TR16\&quot;:\&quot;Bursa\&quot;,\&quot;TR17\&quot;:\&quot;\u00c7anakkale\&quot;,\&quot;TR18\&quot;:\&quot;\u00c7ank\u0131r\u0131\&quot;,\&quot;TR19\&quot;:\&quot;\u00c7orum\&quot;,\&quot;TR20\&quot;:\&quot;Denizli\&quot;,\&quot;TR21\&quot;:\&quot;Diyarbak\u0131r\&quot;,\&quot;TR22\&quot;:\&quot;Edirne\&quot;,\&quot;TR23\&quot;:\&quot;Elaz\u0131\u011f\&quot;,\&quot;TR24\&quot;:\&quot;Erzincan\&quot;,\&quot;TR25\&quot;:\&quot;Erzurum\&quot;,\&quot;TR26\&quot;:\&quot;Eski\u015fehir\&quot;,\&quot;TR27\&quot;:\&quot;Gaziantep\&quot;,\&quot;TR28\&quot;:\&quot;Giresun\&quot;,\&quot;TR29\&quot;:\&quot;G\u00fcm\u00fc\u015fhane\&quot;,\&quot;TR30\&quot;:\&quot;Hakkari\&quot;,\&quot;TR31\&quot;:\&quot;Hatay\&quot;,\&quot;TR32\&quot;:\&quot;Isparta\&quot;,\&quot;TR33\&quot;:\&quot;\u0130\u00e7el\&quot;,\&quot;TR34\&quot;:\&quot;\u0130stanbul\&quot;,\&quot;TR35\&quot;:\&quot;\u0130zmir\&quot;,\&quot;TR36\&quot;:\&quot;Kars\&quot;,\&quot;TR37\&quot;:\&quot;Kastamonu\&quot;,\&quot;TR38\&quot;:\&quot;Kayseri\&quot;,\&quot;TR39\&quot;:\&quot;K\u0131rklareli\&quot;,\&quot;TR40\&quot;:\&quot;K\u0131r\u015fehir\&quot;,\&quot;TR41\&quot;:\&quot;Kocaeli\&quot;,\&quot;TR42\&quot;:\&quot;Konya\&quot;,\&quot;TR43\&quot;:\&quot;K\u00fctahya\&quot;,\&quot;TR44\&quot;:\&quot;Malatya\&quot;,\&quot;TR45\&quot;:\&quot;Manisa\&quot;,\&quot;TR46\&quot;:\&quot;Kahramanmara\u015f\&quot;,\&quot;TR47\&quot;:\&quot;Mardin\&quot;,\&quot;TR48\&quot;:\&quot;Mu\u011fla\&quot;,\&quot;TR49\&quot;:\&quot;Mu\u015f\&quot;,\&quot;TR50\&quot;:\&quot;Nev\u015fehir\&quot;,\&quot;TR51\&quot;:\&quot;Ni\u011fde\&quot;,\&quot;TR52\&quot;:\&quot;Ordu\&quot;,\&quot;TR53\&quot;:\&quot;Rize\&quot;,\&quot;TR54\&quot;:\&quot;Sakarya\&quot;,\&quot;TR55\&quot;:\&quot;Samsun\&quot;,\&quot;TR56\&quot;:\&quot;Siirt\&quot;,\&quot;TR57\&quot;:\&quot;Sinop\&quot;,\&quot;TR58\&quot;:\&quot;Sivas\&quot;,\&quot;TR59\&quot;:\&quot;Tekirda\u011f\&quot;,\&quot;TR60\&quot;:\&quot;Tokat\&quot;,\&quot;TR61\&quot;:\&quot;Trabzon\&quot;,\&quot;TR62\&quot;:\&quot;Tunceli\&quot;,\&quot;TR63\&quot;:\&quot;\u015eanl\u0131urfa\&quot;,\&quot;TR64\&quot;:\&quot;U\u015fak\&quot;,\&quot;TR65\&quot;:\&quot;Van\&quot;,\&quot;TR66\&quot;:\&quot;Yozgat\&quot;,\&quot;TR67\&quot;:\&quot;Zonguldak\&quot;,\&quot;TR68\&quot;:\&quot;Aksaray\&quot;,\&quot;TR69\&quot;:\&quot;Bayburt\&quot;,\&quot;TR70\&quot;:\&quot;Karaman\&quot;,\&quot;TR71\&quot;:\&quot;K\u0131r\u0131kkale\&quot;,\&quot;TR72\&quot;:\&quot;Batman\&quot;,\&quot;TR73\&quot;:\&quot;\u015e\u0131rnak\&quot;,\&quot;TR74\&quot;:\&quot;Bart\u0131n\&quot;,\&quot;TR75\&quot;:\&quot;Ardahan\&quot;,\&quot;TR76\&quot;:\&quot;I\u011fd\u0131r\&quot;,\&quot;TR77\&quot;:\&quot;Yalova\&quot;,\&quot;TR78\&quot;:\&quot;Karab\u00fck\&quot;,\&quot;TR79\&quot;:\&quot;Kilis\&quot;,\&quot;TR80\&quot;:\&quot;Osmaniye\&quot;,\&quot;TR81\&quot;:\&quot;D\u00fczce\&quot;},\&quot;US\&quot;:{\&quot;AL\&quot;:\&quot;Alabama\&quot;,\&quot;AK\&quot;:\&quot;Alaska\&quot;,\&quot;AZ\&quot;:\&quot;Arizona\&quot;,\&quot;AR\&quot;:\&quot;Arkansas\&quot;,\&quot;CA\&quot;:\&quot;California\&quot;,\&quot;CO\&quot;:\&quot;Colorado\&quot;,\&quot;CT\&quot;:\&quot;Connecticut\&quot;,\&quot;DE\&quot;:\&quot;Delaware\&quot;,\&quot;DC\&quot;:\&quot;District Of Columbia\&quot;,\&quot;FL\&quot;:\&quot;Florida\&quot;,\&quot;GA\&quot;:\&quot;Georgia\&quot;,\&quot;HI\&quot;:\&quot;Hawaii\&quot;,\&quot;ID\&quot;:\&quot;Idaho\&quot;,\&quot;IL\&quot;:\&quot;Illinois\&quot;,\&quot;IN\&quot;:\&quot;Indiana\&quot;,\&quot;IA\&quot;:\&quot;Iowa\&quot;,\&quot;KS\&quot;:\&quot;Kansas\&quot;,\&quot;KY\&quot;:\&quot;Kentucky\&quot;,\&quot;LA\&quot;:\&quot;Louisiana\&quot;,\&quot;ME\&quot;:\&quot;Maine\&quot;,\&quot;MD\&quot;:\&quot;Maryland\&quot;,\&quot;MA\&quot;:\&quot;Massachusetts\&quot;,\&quot;MI\&quot;:\&quot;Michigan\&quot;,\&quot;MN\&quot;:\&quot;Minnesota\&quot;,\&quot;MS\&quot;:\&quot;Mississippi\&quot;,\&quot;MO\&quot;:\&quot;Missouri\&quot;,\&quot;MT\&quot;:\&quot;Montana\&quot;,\&quot;NE\&quot;:\&quot;Nebraska\&quot;,\&quot;NV\&quot;:\&quot;Nevada\&quot;,\&quot;NH\&quot;:\&quot;New Hampshire\&quot;,\&quot;NJ\&quot;:\&quot;New Jersey\&quot;,\&quot;NM\&quot;:\&quot;New Mexico\&quot;,\&quot;NY\&quot;:\&quot;New York\&quot;,\&quot;NC\&quot;:\&quot;North Carolina\&quot;,\&quot;ND\&quot;:\&quot;North Dakota\&quot;,\&quot;OH\&quot;:\&quot;Ohio\&quot;,\&quot;OK\&quot;:\&quot;Oklahoma\&quot;,\&quot;OR\&quot;:\&quot;Oregon\&quot;,\&quot;PA\&quot;:\&quot;Pennsylvania\&quot;,\&quot;RI\&quot;:\&quot;Rhode Island\&quot;,\&quot;SC\&quot;:\&quot;South Carolina\&quot;,\&quot;SD\&quot;:\&quot;South Dakota\&quot;,\&quot;TN\&quot;:\&quot;Tennessee\&quot;,\&quot;TX\&quot;:\&quot;Texas\&quot;,\&quot;UT\&quot;:\&quot;Utah\&quot;,\&quot;VT\&quot;:\&quot;Vermont\&quot;,\&quot;VA\&quot;:\&quot;Virginia\&quot;,\&quot;WA\&quot;:\&quot;Washington\&quot;,\&quot;WV\&quot;:\&quot;West Virginia\&quot;,\&quot;WI\&quot;:\&quot;Wisconsin\&quot;,\&quot;WY\&quot;:\&quot;Wyoming\&quot;,\&quot;AA\&quot;:\&quot;Armed Forces (AA)\&quot;,\&quot;AE\&quot;:\&quot;Armed Forces (AE)\&quot;,\&quot;AP\&quot;:\&quot;Armed Forces (AP)\&quot;}}&quot;,&quot;i18n_select_state_text&quot;:&quot;Select an option\u2026&quot;,&quot;i18n_matches_1&quot;:&quot;One result is available, press enter to select it.&quot;,&quot;i18n_matches_n&quot;:&quot;%qty% results are available, use up and down arrow keys to navigate.&quot;,&quot;i18n_no_matches&quot;:&quot;No matches found&quot;,&quot;i18n_ajax_error&quot;:&quot;Loading failed&quot;,&quot;i18n_input_too_short_1&quot;:&quot;Please enter 1 or more characters&quot;,&quot;i18n_input_too_short_n&quot;:&quot;Please enter %qty% or more characters&quot;,&quot;i18n_input_too_long_1&quot;:&quot;Please delete 1 character&quot;,&quot;i18n_input_too_long_n&quot;:&quot;Please delete %qty% characters&quot;,&quot;i18n_selection_too_long_1&quot;:&quot;You can only select 1 item&quot;,&quot;i18n_selection_too_long_n&quot;:&quot;You can only select %qty% items&quot;,&quot;i18n_load_more&quot;:&quot;Loading more results\u2026&quot;,&quot;i18n_searching&quot;:&quot;Searching\u2026&quot;};
/* ]]&gt; */



/* &lt;![CDATA[ */
var wc_address_i18n_params = {&quot;locale&quot;:&quot;{\&quot;AE\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false,\&quot;hidden\&quot;:true}},\&quot;AF\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;AT\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;AU\&quot;:{\&quot;city\&quot;:{\&quot;label\&quot;:\&quot;Suburb\&quot;},\&quot;postcode\&quot;:{\&quot;label\&quot;:\&quot;Postcode\&quot;},\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;State\&quot;}},\&quot;AX\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;BD\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false},\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;District\&quot;}},\&quot;BE\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false,\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;BI\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;BO\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false,\&quot;hidden\&quot;:true}},\&quot;BS\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false,\&quot;hidden\&quot;:true}},\&quot;CA\&quot;:{\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;CH\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Canton\&quot;,\&quot;required\&quot;:false}},\&quot;CL\&quot;:{\&quot;city\&quot;:{\&quot;required\&quot;:true},\&quot;postcode\&quot;:{\&quot;required\&quot;:false},\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Region\&quot;}},\&quot;CN\&quot;:{\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;CO\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false}},\&quot;CZ\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;DE\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;DK\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;EE\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;FI\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;FR\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;HK\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false},\&quot;city\&quot;:{\&quot;label\&quot;:\&quot;Town \\\/ District\&quot;},\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Region\&quot;}},\&quot;HU\&quot;:{\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;County\&quot;}},\&quot;ID\&quot;:{\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;IE\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false,\&quot;label\&quot;:\&quot;Postcode\&quot;}},\&quot;IS\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;IL\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;IT\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:true,\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;JP\&quot;:{\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Prefecture\&quot;}},\&quot;KR\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;NL\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false,\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;NZ\&quot;:{\&quot;postcode\&quot;:{\&quot;label\&quot;:\&quot;Postcode\&quot;},\&quot;state\&quot;:{\&quot;required\&quot;:false,\&quot;label\&quot;:\&quot;Region\&quot;}},\&quot;NO\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;NP\&quot;:{\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;State \\\/ Zone\&quot;},\&quot;postcode\&quot;:{\&quot;required\&quot;:false}},\&quot;PL\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;PT\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;RO\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;SG\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;SK\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;SI\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;ES\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;LI\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Municipality\&quot;,\&quot;required\&quot;:false}},\&quot;LK\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;SE\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;TR\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;US\&quot;:{\&quot;postcode\&quot;:{\&quot;label\&quot;:\&quot;ZIP\&quot;},\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;State\&quot;}},\&quot;GB\&quot;:{\&quot;postcode\&quot;:{\&quot;label\&quot;:\&quot;Postcode\&quot;},\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;County\&quot;,\&quot;required\&quot;:false}},\&quot;VN\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false},\&quot;postcode\&quot;:{\&quot;required\&quot;:false,\&quot;hidden\&quot;:false},\&quot;address_2\&quot;:{\&quot;required\&quot;:false,\&quot;hidden\&quot;:true}},\&quot;WS\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false,\&quot;hidden\&quot;:true}},\&quot;ZA\&quot;:{\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;ZW\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false,\&quot;hidden\&quot;:true}},\&quot;default\&quot;:{\&quot;first_name\&quot;:{\&quot;label\&quot;:\&quot;First Name\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-first\&quot;],\&quot;autocomplete\&quot;:\&quot;given-name\&quot;},\&quot;last_name\&quot;:{\&quot;label\&quot;:\&quot;Last Name\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-last\&quot;],\&quot;clear\&quot;:true,\&quot;autocomplete\&quot;:\&quot;family-name\&quot;},\&quot;company\&quot;:{\&quot;label\&quot;:\&quot;Company Name\&quot;,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;],\&quot;autocomplete\&quot;:\&quot;organization\&quot;},\&quot;country\&quot;:{\&quot;type\&quot;:\&quot;country\&quot;,\&quot;label\&quot;:\&quot;Country\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;,\&quot;update_totals_on_change\&quot;],\&quot;autocomplete\&quot;:\&quot;country\&quot;},\&quot;address_1\&quot;:{\&quot;label\&quot;:\&quot;Address\&quot;,\&quot;placeholder\&quot;:\&quot;Street address\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;],\&quot;autocomplete\&quot;:\&quot;address-line1\&quot;},\&quot;address_2\&quot;:{\&quot;placeholder\&quot;:\&quot;Apartment, suite, unit etc. (optional)\&quot;,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;],\&quot;required\&quot;:false,\&quot;autocomplete\&quot;:\&quot;address-line2\&quot;},\&quot;city\&quot;:{\&quot;label\&quot;:\&quot;Town \\\/ City\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;],\&quot;autocomplete\&quot;:\&quot;address-level2\&quot;},\&quot;state\&quot;:{\&quot;type\&quot;:\&quot;state\&quot;,\&quot;label\&quot;:\&quot;State \\\/ County\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-first\&quot;,\&quot;address-field\&quot;],\&quot;validate\&quot;:[\&quot;state\&quot;],\&quot;autocomplete\&quot;:\&quot;address-level1\&quot;},\&quot;postcode\&quot;:{\&quot;label\&quot;:\&quot;Postcode \\\/ ZIP\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-last\&quot;,\&quot;address-field\&quot;],\&quot;clear\&quot;:true,\&quot;validate\&quot;:[\&quot;postcode\&quot;],\&quot;autocomplete\&quot;:\&quot;postal-code\&quot;}},\&quot;IN\&quot;:{\&quot;first_name\&quot;:{\&quot;label\&quot;:\&quot;First Name\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-first\&quot;],\&quot;autocomplete\&quot;:\&quot;given-name\&quot;},\&quot;last_name\&quot;:{\&quot;label\&quot;:\&quot;Last Name\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-last\&quot;],\&quot;clear\&quot;:true,\&quot;autocomplete\&quot;:\&quot;family-name\&quot;},\&quot;company\&quot;:{\&quot;label\&quot;:\&quot;Company Name\&quot;,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;],\&quot;autocomplete\&quot;:\&quot;organization\&quot;},\&quot;country\&quot;:{\&quot;type\&quot;:\&quot;country\&quot;,\&quot;label\&quot;:\&quot;Country\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;,\&quot;update_totals_on_change\&quot;],\&quot;autocomplete\&quot;:\&quot;country\&quot;},\&quot;address_1\&quot;:{\&quot;label\&quot;:\&quot;Address\&quot;,\&quot;placeholder\&quot;:\&quot;Street address\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;],\&quot;autocomplete\&quot;:\&quot;address-line1\&quot;},\&quot;address_2\&quot;:{\&quot;placeholder\&quot;:\&quot;Apartment, suite, unit etc. (optional)\&quot;,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;],\&quot;required\&quot;:false,\&quot;autocomplete\&quot;:\&quot;address-line2\&quot;},\&quot;city\&quot;:{\&quot;label\&quot;:\&quot;Town \\\/ City\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;],\&quot;autocomplete\&quot;:\&quot;address-level2\&quot;},\&quot;state\&quot;:{\&quot;type\&quot;:\&quot;state\&quot;,\&quot;label\&quot;:\&quot;State \\\/ County\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-first\&quot;,\&quot;address-field\&quot;],\&quot;validate\&quot;:[\&quot;state\&quot;],\&quot;autocomplete\&quot;:\&quot;address-level1\&quot;},\&quot;postcode\&quot;:{\&quot;label\&quot;:\&quot;Postcode \\\/ ZIP\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-last\&quot;,\&quot;address-field\&quot;],\&quot;clear\&quot;:true,\&quot;validate\&quot;:[\&quot;postcode\&quot;],\&quot;autocomplete\&quot;:\&quot;postal-code\&quot;}}}&quot;,&quot;locale_fields&quot;:&quot;{\&quot;address_1\&quot;:\&quot;#billing_address_1_field, #shipping_address_1_field\&quot;,\&quot;address_2\&quot;:\&quot;#billing_address_2_field, #shipping_address_2_field\&quot;,\&quot;state\&quot;:\&quot;#billing_state_field, #shipping_state_field, #calc_shipping_state_field\&quot;,\&quot;postcode\&quot;:\&quot;#billing_postcode_field, #shipping_postcode_field, #calc_shipping_postcode_field\&quot;,\&quot;city\&quot;:\&quot;#billing_city_field, #shipping_city_field, #calc_shipping_city_field\&quot;}&quot;,&quot;i18n_required_text&quot;:&quot;required&quot;};
/* ]]&gt; */



/* &lt;![CDATA[ */
var wc_checkout_params = {&quot;ajax_url&quot;:&quot;\/wp-admin\/admin-ajax.php&quot;,&quot;wc_ajax_url&quot;:&quot;\/checkout\/?wc-ajax=%%endpoint%%&quot;,&quot;update_order_review_nonce&quot;:&quot;54fc2529e7&quot;,&quot;apply_coupon_nonce&quot;:&quot;4cab8888ca&quot;,&quot;remove_coupon_nonce&quot;:&quot;057942b4fe&quot;,&quot;option_guest_checkout&quot;:&quot;yes&quot;,&quot;checkout_url&quot;:&quot;\/checkout\/?wc-ajax=checkout&quot;,&quot;is_checkout&quot;:&quot;1&quot;,&quot;debug_mode&quot;:&quot;&quot;,&quot;i18n_checkout_error&quot;:&quot;Error processing checkout. Please try again.&quot;};
/* ]]&gt; */




/* &lt;![CDATA[ */
var wc_cart_fragments_params = {&quot;ajax_url&quot;:&quot;\/wp-admin\/admin-ajax.php&quot;,&quot;wc_ajax_url&quot;:&quot;\/checkout\/?wc-ajax=%%endpoint%%&quot;,&quot;fragment_name&quot;:&quot;wc_fragments&quot;};
/* ]]&gt; */







/* &lt;![CDATA[ */
var themifyScript = {&quot;lightbox&quot;:{&quot;lightboxSelector&quot;:&quot;.themify_lightbox&quot;,&quot;lightboxOn&quot;:true,&quot;lightboxContentImages&quot;:false,&quot;lightboxContentImagesSelector&quot;:&quot;.post-content a[href$=jpg],.page-content a[href$=jpg],.post-content a[href$=gif],.page-content a[href$=gif],.post-content a[href$=png],.page-content a[href$=png],.post-content a[href$=JPG],.page-content a[href$=JPG],.post-content a[href$=GIF],.page-content a[href$=GIF],.post-content a[href$=PNG],.page-content a[href$=PNG],.post-content a[href$=jpeg],.page-content a[href$=jpeg],.post-content a[href$=JPEG],.page-content a[href$=JPEG]&quot;,&quot;theme&quot;:&quot;pp_default&quot;,&quot;social_tools&quot;:false,&quot;allow_resize&quot;:true,&quot;show_title&quot;:false,&quot;overlay_gallery&quot;:false,&quot;screenWidthNoLightbox&quot;:600,&quot;deeplinking&quot;:false,&quot;contentImagesAreas&quot;:&quot;.post, .type-page, .type-highlight, .type-slider&quot;,&quot;gallerySelector&quot;:&quot;.gallery-icon > a[href$=jpg],.gallery-icon > a[href$=gif],.gallery-icon > a[href$=png],.gallery-icon > a[href$=JPG],.gallery-icon > a[href$=GIF],.gallery-icon > a[href$=PNG],.gallery-icon > a[href$=jpeg],.gallery-icon > a[href$=JPEG]&quot;,&quot;lightboxGalleryOn&quot;:true},&quot;lightboxContext&quot;:&quot;#pagewrap&quot;,&quot;fixedHeader&quot;:&quot;fixed-header&quot;,&quot;ajax_nonce&quot;:&quot;9edb8546c3&quot;,&quot;ajax_url&quot;:&quot;https:\/\/practice.automationtesting.in\/wp-admin\/admin-ajax.php&quot;,&quot;smallScreen&quot;:&quot;760&quot;,&quot;resizeRefresh&quot;:&quot;250&quot;,&quot;parallaxHeader&quot;:&quot;1&quot;,&quot;loadingImg&quot;:&quot;https:\/\/practice.automationtesting.in\/wp-content\/themes\/themify-ultra\/images\/loading.gif&quot;,&quot;maxPages&quot;:&quot;0&quot;,&quot;autoInfinite&quot;:&quot;auto&quot;,&quot;scrollToNewOnLoad&quot;:&quot;scroll&quot;,&quot;resetFilterOnLoad&quot;:&quot;reset&quot;,&quot;fullPageScroll&quot;:&quot;&quot;,&quot;scrollHighlight&quot;:{&quot;scroll&quot;:&quot;internal&quot;}};
/* ]]&gt; */




/* &lt;![CDATA[ */
var mc4wp_forms_config = [];
/* ]]&gt; */





jQuery(function($) { 

	jQuery( function( $ ) {
		var ppec_mark_fields      = '#woocommerce_ppec_paypal_title, #woocommerce_ppec_paypal_description';
		var ppec_live_fields      = '#woocommerce_ppec_paypal_api_username, #woocommerce_ppec_paypal_api_password, #woocommerce_ppec_paypal_api_signature, #woocommerce_ppec_paypal_api_certificate, #woocommerce_ppec_paypal_api_subject';
		var ppec_sandbox_fields   = '#woocommerce_ppec_paypal_sandbox_api_username, #woocommerce_ppec_paypal_sandbox_api_password, #woocommerce_ppec_paypal_sandbox_api_signature, #woocommerce_ppec_paypal_sandbox_api_certificate, #woocommerce_ppec_paypal_sandbox_api_subject';

		var enable_toggle         = $( 'a.ppec-toggle-settings' ).length > 0;
		var enable_sandbox_toggle = $( 'a.ppec-toggle-sandbox-settings' ).length > 0;

		$( '#woocommerce_ppec_paypal_environment' ).change(function(){
			$( ppec_sandbox_fields + ',' + ppec_live_fields ).closest( 'tr' ).hide();

			if ( 'live' === $( this ).val() ) {
				$( '#woocommerce_ppec_paypal_api_credentials, #woocommerce_ppec_paypal_api_credentials + p' ).show();
				$( '#woocommerce_ppec_paypal_sandbox_api_credentials, #woocommerce_ppec_paypal_sandbox_api_credentials + p' ).hide();

				if ( ! enable_toggle ) {
					$( ppec_live_fields ).closest( 'tr' ).show();
				}
			} else {
				$( '#woocommerce_ppec_paypal_api_credentials, #woocommerce_ppec_paypal_api_credentials + p' ).hide();
				$( '#woocommerce_ppec_paypal_sandbox_api_credentials, #woocommerce_ppec_paypal_sandbox_api_credentials + p' ).show();

				if ( ! enable_sandbox_toggle ) {
					$( ppec_sandbox_fields ).closest( 'tr' ).show();
				}
			}
		}).change();

		$( '#woocommerce_ppec_paypal_mark_enabled' ).change(function(){
			if ( $( this ).is( ':checked' ) ) {
				$( ppec_mark_fields ).closest( 'tr' ).show();
			} else {
				$( ppec_mark_fields ).closest( 'tr' ).hide();
			}
		}).change();

		$( '#woocommerce_ppec_paypal_paymentaction' ).change(function(){
			if ( 'sale' === $( this ).val() ) {
				$( '#woocommerce_ppec_paypal_instant_payments' ).closest( 'tr' ).show();
			} else {
				$( '#woocommerce_ppec_paypal_instant_payments' ).closest( 'tr' ).hide();
			}
		}).change();

		if ( enable_toggle ) {
			$( document ).on( 'click', '.ppec-toggle-settings', function() {
				$( ppec_live_fields ).closest( 'tr' ).toggle();
			} );
		}
		if ( enable_sandbox_toggle ) {
			$( document ).on( 'click', '.ppec-toggle-sandbox-settings', function() {
				$( ppec_sandbox_fields ).closest( 'tr' ).toggle();
			} );
		}
	});

 });

		
			if ('object' === typeof tbLocalScript) {
				tbLocalScript.transitionSelectors = &quot;.js.csstransitions .module.wow, .js.csstransitions .themify_builder_content .themify_builder_row.wow, .js.csstransitions .module_row.wow, .js.csstransitions .builder-posts-wrap > .post.wow, .js.csstransitions .fly-in > .post, .js.csstransitions .fly-in .row_inner > .tb-column, .js.csstransitions .fade-in > .post, .js.csstransitions .fade-in .row_inner > .tb-column, .js.csstransitions .slide-up > .post, .js.csstransitions .slide-up .row_inner > .tb-column&quot;;
			}
		
			
id(&quot;billing_last_name&quot;)Software</value>
      <webElementGuid>3ed3b429-2d19-45ec-8fe9-ceeebdc15ba4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js csstransitions&quot;]/body[@class=&quot;page-template-default page page-id-35 woocommerce-checkout woocommerce-page template-themify-ultra template-themify-ultra-1-5-0 skin-default webkit not-ie default_width sidebar-none no-home no-touch header-top-bar fixed-header footer-block default tagline-off rss-off filter-hover-none filter-featured-only masonry-enabled sidemenu-active builder-parallax-scrolling-active animation-on page-loaded themify_lightbox_loaded fixed-header-on&quot;]</value>
      <webElementGuid>fcbb7cde-a289-48a0-8a16-c66b72e29fb3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//body</value>
      <webElementGuid>dc2b07d2-714c-46d1-b6bd-3ce5923e0f03</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//body[(text() = concat(&quot;




			

			
			

			

	            
	            
		            						Automation Practice Site					
									
				

									

													
																									
															
							
						
													
								

	

	

							
							
						
													
								Shop 
My Account 
Test Cases 
AT Site 
Demo Site 
1 item₹450.00								
							
							
						
													
		
							
								 
 
 
 
 
					



(adsbygoogle = window.adsbygoogle || []).push({});

					



(adsbygoogle = window.adsbygoogle || []).push({});

					



(adsbygoogle = window.adsbygoogle || []).push({});

					



(adsbygoogle = window.adsbygoogle || []).push({});

					



(adsbygoogle = window.adsbygoogle || []).push({});

					



(adsbygoogle = window.adsbygoogle || []).push({});

						
							
									
							
									
					
		

								
						
						
					
					
				
				
				
			
			

	        
		
		
	
	

		




		
	
    	
		
							

			
						

			

				
				
	Returning customer? Click here to login



	
	If you have shopped with us before, please enter your details in the boxes below. If you are a new customer, please proceed to the Billing &amp; Shipping section.

	
		Username or email *
		
	
	
		Password *
		
	
	

	
	
				
		
		
			 Remember me		
	
	
		Lost your password?
	

	

	


	Have a coupon? Click here to enter your code



	
		
	

	
		
	

	




	
		
		
			
				
	
		Billing Details

	
	
	
		First Name *
	
		Last Name *
	
		Company Name
	
		Email Address *
	
		Phone *
	
		Country *   India   Country *          Country *                Select a country…Åland IslandsAfghanistanAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntarcticaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelarusBelauBelgiumBelizeBeninBermudaBhutanBoliviaBonaire, Saint Eustatius and SabaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo (Brazzaville)Congo (Kinshasa)Cook IslandsCosta RicaCroatiaCubaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland IslandsFaroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHondurasHong KongHungaryIcelandIndiaIndonesiaIranIraqIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacao S.A.R., ChinaMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesiaMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmarNamibiaNauruNepalNetherlandsNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorth KoreaNorthern Mariana IslandsNorwayOmanPakistanPalestinian TerritoryPanamaPapua New GuineaParaguayPeruPhilippinesPitcairnPolandPortugalPuerto RicoQatarRepublic of IrelandReunionRomaniaRussiaRwandaSão Tomé and PríncipeSaint BarthélemySaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (Dutch part)Saint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia/Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandSyriaTaiwanTajikistanTanzaniaThailandTimor-LesteTogoTokelauTongaTrinidad and TobagoTunisiaTurkeyTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited Kingdom (UK)United States (US)United States (US) Minor Outlying IslandsUnited States (US) Virgin IslandsUruguayUzbekistanVanuatuVaticanVenezuelaVietnamWallis and FutunaWestern SaharaYemenZambiaZimbabwe&lt;input type=&quot;submit&quot; name=&quot;woocommerce_checkout_update_totals&quot; value=&quot;Update country&quot; />
	
		Address *
	
		
	
		Town / City *
	
		State / County *   Telangana   State / County *          State / County *                Select an option…Andhra PradeshArunachal PradeshAssamBiharChhattisgarhGoaGujaratHaryanaHimachal PradeshJammu and KashmirJharkhandKarnatakaKeralaMadhya PradeshMaharashtraManipurMeghalayaMizoramNagalandOrissaPunjabRajasthanSikkimTamil NaduTelanganaTripuraUttarakhandUttar PradeshWest BengalAndaman and Nicobar IslandsChandigarhDadar and Nagar HaveliDaman and DiuDelhiLakshadeepPondicherry (Puducherry)Postcode / ZIP *
	
		
	
	
	
		
			
				 Create an account?
			

		
		
		
			

				Create an account by entering the information below. If you are a returning customer please login at the top of the page.

				
					Account password *
				
				

			

		
		
	
			

			
				
	
	
	
		
			Additional Information

		
		
			Order Notes
		
	
	
			
		

		
	
	Your order

	
	
		
	
		
			Product
			Total
		
	
	
							
						
							Android Quick Start Guide 							 × 1													
						
							₹450.00						
					
						
	

		
			Subtotal
			₹450.00
		

		
		
		
														
						Tax
						₹9.00
					
									
		
		
			Total
			₹459.00 
		

		
	



			
			
	

	
		Direct Bank Transfer 	
			
			Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order won’t be shipped until the funds have cleared in our account.
		
	

	

	
		Check Payments 	
			
			Please send a cheque to Store Name, Store Street, Store Town, Store State / County, Store Postcode.
		
	

	

	
		Cash on Delivery 	
			
			Pay with cash upon delivery.
		
	

	

	
		PayPal Express Checkout 	
			
			Pay using either your PayPal account or credit card. All credit card payments will be processed by PayPal.
		
	
		
		
		
			Since your browser does not support JavaScript, or it is disabled, please ensure you click the &lt;em>Update Totals&lt;/em> button before placing your order. You may be charged more than the amount stated above if you fail to do so.			&lt;br/>&lt;input type=&quot;submit&quot; class=&quot;button alt&quot; name=&quot;woocommerce_checkout_update_totals&quot; value=&quot;Update totals&quot; />
		

		
		
		
		
			


	

	





	

				
				
				
								

			
			

			
		
				
			
	
    
	
	





        			
			

							

					
					

						
						
						
							
															
															
							
							

																	
																			
									
																							
						

																					
									
										
		
							
								



		
							
								  
							
							
							
								  
							
							
							
								  
							
							
							
								  
							
							
							
								  
							
											
							
								

Discover moreSaludCienciasDevelopment Tools

(adsbygoogle = window.adsbygoogle || []).push({});

						
							
								

Discover moreHome Storage &amp; ShelvingSoftwareDevelopment Tools

(adsbygoogle = window.adsbygoogle || []).push({});

						
							
					Subscribe Here(function() {
	if (!window.mc4wp) {
		window.mc4wp = {
			listeners: [],
			forms    : {
				on: function (event, callback) {
					window.mc4wp.listeners.push({
						event   : event,
						callback: callback
					});
				}
			}
		}
	}
})();

	



	
				
					
		

											
									
								
								
									
																					© Automation Practice Site 2026											 																			
								
								
													
						
					
					

					
				
				
			
		
		

		
		[{&quot;@context&quot;:&quot;http:\/\/schema.org&quot;,&quot;@type&quot;:&quot;WebPage&quot;,&quot;mainEntityOfPage&quot;:{&quot;@type&quot;:&quot;WebPage&quot;,&quot;@id&quot;:&quot;https:\/\/practice.automationtesting.in\/checkout\/&quot;},&quot;headline&quot;:&quot;Checkout&quot;,&quot;datePublished&quot;:&quot;2017-01-06T08:17:30+00:00&quot;,&quot;dateModified&quot;:&quot;2017-01-06T08:17:30+00:00&quot;,&quot;description&quot;:&quot;&quot;,&quot;commentCount&quot;:&quot;0&quot;}]		
		

(function() {function addEventListener(element,event,handler) {
	if(element.addEventListener) {
		element.addEventListener(event,handler, false);
	} else if(element.attachEvent){
		element.attachEvent(&quot; , &quot;'&quot; , &quot;on&quot; , &quot;'&quot; , &quot;+event,handler);
	}
}function maybePrefixUrlField() {
	if(this.value.trim() !== &quot; , &quot;'&quot; , &quot;&quot; , &quot;'&quot; , &quot; &amp;&amp; this.value.indexOf(&quot; , &quot;'&quot; , &quot;http&quot; , &quot;'&quot; , &quot;) !== 0) {
		this.value = &quot;http://&quot; + this.value;
	}
}

var urlFields = document.querySelectorAll(&quot; , &quot;'&quot; , &quot;.mc4wp-form input[type=&quot;url&quot;]&quot; , &quot;'&quot; , &quot;);
if( urlFields &amp;&amp; urlFields.length > 0 ) {
	for( var j=0; j &lt; urlFields.length; j++ ) {
		addEventListener(urlFields[j],&quot; , &quot;'&quot; , &quot;blur&quot; , &quot;'&quot; , &quot;,maybePrefixUrlField);
	}
}/* test if browser supports date fields */
var testInput = document.createElement(&quot; , &quot;'&quot; , &quot;input&quot; , &quot;'&quot; , &quot;);
testInput.setAttribute(&quot; , &quot;'&quot; , &quot;type&quot; , &quot;'&quot; , &quot;, &quot; , &quot;'&quot; , &quot;date&quot; , &quot;'&quot; , &quot;);
if( testInput.type !== &quot; , &quot;'&quot; , &quot;date&quot; , &quot;'&quot; , &quot;) {

	/* add placeholder &amp; pattern to all date fields */
	var dateFields = document.querySelectorAll(&quot; , &quot;'&quot; , &quot;.mc4wp-form input[type=&quot;date&quot;]&quot; , &quot;'&quot; , &quot;);
	for(var i=0; i&lt;dateFields.length; i++) {
		if(!dateFields[i].placeholder) {
			dateFields[i].placeholder = &quot; , &quot;'&quot; , &quot;YYYY-MM-DD&quot; , &quot;'&quot; , &quot;;
		}
		if(!dateFields[i].pattern) {
			dateFields[i].pattern = &quot; , &quot;'&quot; , &quot;[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])&quot; , &quot;'&quot; , &quot;;
		}
	}
}

})();
/* &lt;![CDATA[ */
var themify_vars = {&quot;version&quot;:&quot;2.8.8&quot;,&quot;url&quot;:&quot;https:\/\/practice.automationtesting.in\/wp-content\/themes\/themify-ultra\/themify&quot;,&quot;TB&quot;:&quot;1&quot;,&quot;map_key&quot;:null};
var tbLocalScript = {&quot;isAnimationActive&quot;:&quot;1&quot;,&quot;isParallaxActive&quot;:&quot;1&quot;,&quot;animationInviewSelectors&quot;:[&quot;.module.wow&quot;,&quot;.themify_builder_content .themify_builder_row.wow&quot;,&quot;.module_row.wow&quot;,&quot;.builder-posts-wrap > .post.wow&quot;,&quot;.fly-in > .post&quot;,&quot;.fly-in .row_inner > .tb-column&quot;,&quot;.fade-in > .post&quot;,&quot;.fade-in .row_inner > .tb-column&quot;,&quot;.slide-up > .post&quot;,&quot;.slide-up .row_inner > .tb-column&quot;],&quot;createAnimationSelectors&quot;:[],&quot;backgroundSlider&quot;:{&quot;autoplay&quot;:5000,&quot;speed&quot;:2000},&quot;animationOffset&quot;:&quot;100&quot;,&quot;videoPoster&quot;:&quot;https:\/\/practice.automationtesting.in\/wp-content\/themes\/themify-ultra\/themify\/themify-builder\/img\/blank.png&quot;,&quot;backgroundVideoLoop&quot;:&quot;yes&quot;,&quot;builder_url&quot;:&quot;https:\/\/practice.automationtesting.in\/wp-content\/themes\/themify-ultra\/themify\/themify-builder&quot;,&quot;framework_url&quot;:&quot;https:\/\/practice.automationtesting.in\/wp-content\/themes\/themify-ultra\/themify&quot;,&quot;version&quot;:&quot;2.8.8&quot;,&quot;fullwidth_support&quot;:&quot;&quot;,&quot;fullwidth_container&quot;:&quot;body&quot;,&quot;loadScrollHighlight&quot;:&quot;1&quot;};
var themifyScript = {&quot;lightbox&quot;:{&quot;lightboxSelector&quot;:&quot;.themify_lightbox&quot;,&quot;lightboxOn&quot;:true,&quot;lightboxContentImages&quot;:false,&quot;lightboxContentImagesSelector&quot;:&quot;.post-content a[href$=jpg],.page-content a[href$=jpg],.post-content a[href$=gif],.page-content a[href$=gif],.post-content a[href$=png],.page-content a[href$=png],.post-content a[href$=JPG],.page-content a[href$=JPG],.post-content a[href$=GIF],.page-content a[href$=GIF],.post-content a[href$=PNG],.page-content a[href$=PNG],.post-content a[href$=jpeg],.page-content a[href$=jpeg],.post-content a[href$=JPEG],.page-content a[href$=JPEG]&quot;,&quot;theme&quot;:&quot;pp_default&quot;,&quot;social_tools&quot;:false,&quot;allow_resize&quot;:true,&quot;show_title&quot;:false,&quot;overlay_gallery&quot;:false,&quot;screenWidthNoLightbox&quot;:600,&quot;deeplinking&quot;:false,&quot;contentImagesAreas&quot;:&quot;.post, .type-page, .type-highlight, .type-slider&quot;,&quot;gallerySelector&quot;:&quot;.gallery-icon > a[href$=jpg],.gallery-icon > a[href$=gif],.gallery-icon > a[href$=png],.gallery-icon > a[href$=JPG],.gallery-icon > a[href$=GIF],.gallery-icon > a[href$=PNG],.gallery-icon > a[href$=jpeg],.gallery-icon > a[href$=JPEG]&quot;,&quot;lightboxGalleryOn&quot;:true},&quot;lightboxContext&quot;:&quot;body&quot;};
var tbScrollHighlight = {&quot;fixedHeaderSelector&quot;:&quot;#headerwrap.fixed-header&quot;,&quot;speed&quot;:&quot;900&quot;,&quot;navigation&quot;:&quot;#main-nav&quot;,&quot;scrollOffset&quot;:&quot;-5&quot;};
/* ]]&gt; */




/* &lt;![CDATA[ */
var _wpcf7 = {&quot;recaptcha&quot;:{&quot;messages&quot;:{&quot;empty&quot;:&quot;Please verify that you are not a robot.&quot;}}};
/* ]]&gt; */



/* &lt;![CDATA[ */
var sb_instagram_js_options = {&quot;sb_instagram_at&quot;:&quot;&quot;};
/* ]]&gt; */



/* &lt;![CDATA[ */
var wc_add_to_cart_params = {&quot;ajax_url&quot;:&quot;\/wp-admin\/admin-ajax.php&quot;,&quot;wc_ajax_url&quot;:&quot;\/checkout\/?wc-ajax=%%endpoint%%&quot;,&quot;i18n_view_cart&quot;:&quot;View Basket&quot;,&quot;cart_url&quot;:&quot;https:\/\/practice.automationtesting.in\/basket\/&quot;,&quot;is_cart&quot;:&quot;&quot;,&quot;cart_redirect_after_add&quot;:&quot;no&quot;};
/* ]]&gt; */









wp.i18n.setLocaleData( { &quot; , &quot;'&quot; , &quot;text direction\u0004ltr&quot; , &quot;'&quot; , &quot;: [ &quot; , &quot;'&quot; , &quot;ltr&quot; , &quot;'&quot; , &quot; ] } );


/* &lt;![CDATA[ */
var pwsL10n = {&quot;unknown&quot;:&quot;Password strength unknown&quot;,&quot;short&quot;:&quot;Very weak&quot;,&quot;bad&quot;:&quot;Weak&quot;,&quot;good&quot;:&quot;Medium&quot;,&quot;strong&quot;:&quot;Strong&quot;,&quot;mismatch&quot;:&quot;Mismatch&quot;};
/* ]]&gt; */


( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[&quot;&quot;].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( &quot;default&quot;, {&quot;translation-revision-date&quot;:&quot;2023-04-19 10:51:23+0000&quot;,&quot;generator&quot;:&quot;GlotPress\/4.0.0-alpha.4&quot;,&quot;domain&quot;:&quot;messages&quot;,&quot;locale_data&quot;:{&quot;messages&quot;:{&quot;&quot;:{&quot;domain&quot;:&quot;messages&quot;,&quot;plural-forms&quot;:&quot;nplurals=2; plural=n != 1;&quot;,&quot;lang&quot;:&quot;en_GB&quot;},&quot;%1$s is deprecated since version %2$s! Use %3$s instead. Please consider writing more inclusive code.&quot;:[&quot;%1$s is deprecated since version %2$s! Use %3$s instead. Please consider writing more inclusive code.&quot;]}},&quot;comment&quot;:{&quot;reference&quot;:&quot;wp-admin\/js\/password-strength-meter.js&quot;}} );



/* &lt;![CDATA[ */
var wc_password_strength_meter_params = {&quot;min_password_strength&quot;:&quot;3&quot;,&quot;i18n_password_error&quot;:&quot;Please enter a stronger password.&quot;,&quot;i18n_password_hint&quot;:&quot;The password should be at least seven characters long. To make it stronger, use upper and lower case letters, numbers and symbols like ! \&quot; ? $ % ^ &amp; ).&quot;};
/* ]]&gt; */




/* &lt;![CDATA[ */
var woocommerce_params = {&quot;ajax_url&quot;:&quot;\/wp-admin\/admin-ajax.php&quot;,&quot;wc_ajax_url&quot;:&quot;\/checkout\/?wc-ajax=%%endpoint%%&quot;};
/* ]]&gt; */



/* &lt;![CDATA[ */
var wc_country_select_params = {&quot;countries&quot;:&quot;{\&quot;AF\&quot;:[],\&quot;AT\&quot;:[],\&quot;AX\&quot;:[],\&quot;BE\&quot;:[],\&quot;BI\&quot;:[],\&quot;CZ\&quot;:[],\&quot;DE\&quot;:[],\&quot;DK\&quot;:[],\&quot;EE\&quot;:[],\&quot;FI\&quot;:[],\&quot;FR\&quot;:[],\&quot;IS\&quot;:[],\&quot;IL\&quot;:[],\&quot;KR\&quot;:[],\&quot;NL\&quot;:[],\&quot;NO\&quot;:[],\&quot;PL\&quot;:[],\&quot;PT\&quot;:[],\&quot;SG\&quot;:[],\&quot;SK\&quot;:[],\&quot;SI\&quot;:[],\&quot;LK\&quot;:[],\&quot;SE\&quot;:[],\&quot;VN\&quot;:[],\&quot;AR\&quot;:{\&quot;C\&quot;:\&quot;Ciudad Aut\u00f3noma de Buenos Aires\&quot;,\&quot;B\&quot;:\&quot;Buenos Aires\&quot;,\&quot;K\&quot;:\&quot;Catamarca\&quot;,\&quot;H\&quot;:\&quot;Chaco\&quot;,\&quot;U\&quot;:\&quot;Chubut\&quot;,\&quot;X\&quot;:\&quot;C\u00f3rdoba\&quot;,\&quot;W\&quot;:\&quot;Corrientes\&quot;,\&quot;E\&quot;:\&quot;Entre R\u00edos\&quot;,\&quot;P\&quot;:\&quot;Formosa\&quot;,\&quot;Y\&quot;:\&quot;Jujuy\&quot;,\&quot;L\&quot;:\&quot;La Pampa\&quot;,\&quot;F\&quot;:\&quot;La Rioja\&quot;,\&quot;M\&quot;:\&quot;Mendoza\&quot;,\&quot;N\&quot;:\&quot;Misiones\&quot;,\&quot;Q\&quot;:\&quot;Neuqu\u00e9n\&quot;,\&quot;R\&quot;:\&quot;R\u00edo Negro\&quot;,\&quot;A\&quot;:\&quot;Salta\&quot;,\&quot;J\&quot;:\&quot;San Juan\&quot;,\&quot;D\&quot;:\&quot;San Luis\&quot;,\&quot;Z\&quot;:\&quot;Santa Cruz\&quot;,\&quot;S\&quot;:\&quot;Santa Fe\&quot;,\&quot;G\&quot;:\&quot;Santiago del Estero\&quot;,\&quot;V\&quot;:\&quot;Tierra del Fuego\&quot;,\&quot;T\&quot;:\&quot;Tucum\u00e1n\&quot;},\&quot;AU\&quot;:{\&quot;ACT\&quot;:\&quot;Australian Capital Territory\&quot;,\&quot;NSW\&quot;:\&quot;New South Wales\&quot;,\&quot;NT\&quot;:\&quot;Northern Territory\&quot;,\&quot;QLD\&quot;:\&quot;Queensland\&quot;,\&quot;SA\&quot;:\&quot;South Australia\&quot;,\&quot;TAS\&quot;:\&quot;Tasmania\&quot;,\&quot;VIC\&quot;:\&quot;Victoria\&quot;,\&quot;WA\&quot;:\&quot;Western Australia\&quot;},\&quot;BD\&quot;:{\&quot;BAG\&quot;:\&quot;Bagerhat\&quot;,\&quot;BAN\&quot;:\&quot;Bandarban\&quot;,\&quot;BAR\&quot;:\&quot;Barguna\&quot;,\&quot;BARI\&quot;:\&quot;Barisal\&quot;,\&quot;BHO\&quot;:\&quot;Bhola\&quot;,\&quot;BOG\&quot;:\&quot;Bogra\&quot;,\&quot;BRA\&quot;:\&quot;Brahmanbaria\&quot;,\&quot;CHA\&quot;:\&quot;Chandpur\&quot;,\&quot;CHI\&quot;:\&quot;Chittagong\&quot;,\&quot;CHU\&quot;:\&quot;Chuadanga\&quot;,\&quot;COM\&quot;:\&quot;Comilla\&quot;,\&quot;COX\&quot;:\&quot;Cox&quot; , &quot;'&quot; , &quot;s Bazar\&quot;,\&quot;DHA\&quot;:\&quot;Dhaka\&quot;,\&quot;DIN\&quot;:\&quot;Dinajpur\&quot;,\&quot;FAR\&quot;:\&quot;Faridpur \&quot;,\&quot;FEN\&quot;:\&quot;Feni\&quot;,\&quot;GAI\&quot;:\&quot;Gaibandha\&quot;,\&quot;GAZI\&quot;:\&quot;Gazipur\&quot;,\&quot;GOP\&quot;:\&quot;Gopalganj\&quot;,\&quot;HAB\&quot;:\&quot;Habiganj\&quot;,\&quot;JAM\&quot;:\&quot;Jamalpur\&quot;,\&quot;JES\&quot;:\&quot;Jessore\&quot;,\&quot;JHA\&quot;:\&quot;Jhalokati\&quot;,\&quot;JHE\&quot;:\&quot;Jhenaidah\&quot;,\&quot;JOY\&quot;:\&quot;Joypurhat\&quot;,\&quot;KHA\&quot;:\&quot;Khagrachhari\&quot;,\&quot;KHU\&quot;:\&quot;Khulna\&quot;,\&quot;KIS\&quot;:\&quot;Kishoreganj\&quot;,\&quot;KUR\&quot;:\&quot;Kurigram\&quot;,\&quot;KUS\&quot;:\&quot;Kushtia\&quot;,\&quot;LAK\&quot;:\&quot;Lakshmipur\&quot;,\&quot;LAL\&quot;:\&quot;Lalmonirhat\&quot;,\&quot;MAD\&quot;:\&quot;Madaripur\&quot;,\&quot;MAG\&quot;:\&quot;Magura\&quot;,\&quot;MAN\&quot;:\&quot;Manikganj \&quot;,\&quot;MEH\&quot;:\&quot;Meherpur\&quot;,\&quot;MOU\&quot;:\&quot;Moulvibazar\&quot;,\&quot;MUN\&quot;:\&quot;Munshiganj\&quot;,\&quot;MYM\&quot;:\&quot;Mymensingh\&quot;,\&quot;NAO\&quot;:\&quot;Naogaon\&quot;,\&quot;NAR\&quot;:\&quot;Narail\&quot;,\&quot;NARG\&quot;:\&quot;Narayanganj\&quot;,\&quot;NARD\&quot;:\&quot;Narsingdi\&quot;,\&quot;NAT\&quot;:\&quot;Natore\&quot;,\&quot;NAW\&quot;:\&quot;Nawabganj\&quot;,\&quot;NET\&quot;:\&quot;Netrakona\&quot;,\&quot;NIL\&quot;:\&quot;Nilphamari\&quot;,\&quot;NOA\&quot;:\&quot;Noakhali\&quot;,\&quot;PAB\&quot;:\&quot;Pabna\&quot;,\&quot;PAN\&quot;:\&quot;Panchagarh\&quot;,\&quot;PAT\&quot;:\&quot;Patuakhali\&quot;,\&quot;PIR\&quot;:\&quot;Pirojpur\&quot;,\&quot;RAJB\&quot;:\&quot;Rajbari\&quot;,\&quot;RAJ\&quot;:\&quot;Rajshahi\&quot;,\&quot;RAN\&quot;:\&quot;Rangamati\&quot;,\&quot;RANP\&quot;:\&quot;Rangpur\&quot;,\&quot;SAT\&quot;:\&quot;Satkhira\&quot;,\&quot;SHA\&quot;:\&quot;Shariatpur\&quot;,\&quot;SHE\&quot;:\&quot;Sherpur\&quot;,\&quot;SIR\&quot;:\&quot;Sirajganj\&quot;,\&quot;SUN\&quot;:\&quot;Sunamganj\&quot;,\&quot;SYL\&quot;:\&quot;Sylhet\&quot;,\&quot;TAN\&quot;:\&quot;Tangail\&quot;,\&quot;THA\&quot;:\&quot;Thakurgaon\&quot;},\&quot;BR\&quot;:{\&quot;AC\&quot;:\&quot;Acre\&quot;,\&quot;AL\&quot;:\&quot;Alagoas\&quot;,\&quot;AP\&quot;:\&quot;Amap\u00e1\&quot;,\&quot;AM\&quot;:\&quot;Amazonas\&quot;,\&quot;BA\&quot;:\&quot;Bahia\&quot;,\&quot;CE\&quot;:\&quot;Cear\u00e1\&quot;,\&quot;DF\&quot;:\&quot;Distrito Federal\&quot;,\&quot;ES\&quot;:\&quot;Esp\u00edrito Santo\&quot;,\&quot;GO\&quot;:\&quot;Goi\u00e1s\&quot;,\&quot;MA\&quot;:\&quot;Maranh\u00e3o\&quot;,\&quot;MT\&quot;:\&quot;Mato Grosso\&quot;,\&quot;MS\&quot;:\&quot;Mato Grosso do Sul\&quot;,\&quot;MG\&quot;:\&quot;Minas Gerais\&quot;,\&quot;PA\&quot;:\&quot;Par\u00e1\&quot;,\&quot;PB\&quot;:\&quot;Para\u00edba\&quot;,\&quot;PR\&quot;:\&quot;Paran\u00e1\&quot;,\&quot;PE\&quot;:\&quot;Pernambuco\&quot;,\&quot;PI\&quot;:\&quot;Piau\u00ed\&quot;,\&quot;RJ\&quot;:\&quot;Rio de Janeiro\&quot;,\&quot;RN\&quot;:\&quot;Rio Grande do Norte\&quot;,\&quot;RS\&quot;:\&quot;Rio Grande do Sul\&quot;,\&quot;RO\&quot;:\&quot;Rond\u00f4nia\&quot;,\&quot;RR\&quot;:\&quot;Roraima\&quot;,\&quot;SC\&quot;:\&quot;Santa Catarina\&quot;,\&quot;SP\&quot;:\&quot;S\u00e3o Paulo\&quot;,\&quot;SE\&quot;:\&quot;Sergipe\&quot;,\&quot;TO\&quot;:\&quot;Tocantins\&quot;},\&quot;BG\&quot;:{\&quot;BG-01\&quot;:\&quot;Blagoevgrad\&quot;,\&quot;BG-02\&quot;:\&quot;Burgas\&quot;,\&quot;BG-08\&quot;:\&quot;Dobrich\&quot;,\&quot;BG-07\&quot;:\&quot;Gabrovo\&quot;,\&quot;BG-26\&quot;:\&quot;Haskovo\&quot;,\&quot;BG-09\&quot;:\&quot;Kardzhali\&quot;,\&quot;BG-10\&quot;:\&quot;Kyustendil\&quot;,\&quot;BG-11\&quot;:\&quot;Lovech\&quot;,\&quot;BG-12\&quot;:\&quot;Montana\&quot;,\&quot;BG-13\&quot;:\&quot;Pazardzhik\&quot;,\&quot;BG-14\&quot;:\&quot;Pernik\&quot;,\&quot;BG-15\&quot;:\&quot;Pleven\&quot;,\&quot;BG-16\&quot;:\&quot;Plovdiv\&quot;,\&quot;BG-17\&quot;:\&quot;Razgrad\&quot;,\&quot;BG-18\&quot;:\&quot;Ruse\&quot;,\&quot;BG-27\&quot;:\&quot;Shumen\&quot;,\&quot;BG-19\&quot;:\&quot;Silistra\&quot;,\&quot;BG-20\&quot;:\&quot;Sliven\&quot;,\&quot;BG-21\&quot;:\&quot;Smolyan\&quot;,\&quot;BG-23\&quot;:\&quot;Sofia\&quot;,\&quot;BG-22\&quot;:\&quot;Sofia-Grad\&quot;,\&quot;BG-24\&quot;:\&quot;Stara Zagora\&quot;,\&quot;BG-25\&quot;:\&quot;Targovishte\&quot;,\&quot;BG-03\&quot;:\&quot;Varna\&quot;,\&quot;BG-04\&quot;:\&quot;Veliko Tarnovo\&quot;,\&quot;BG-05\&quot;:\&quot;Vidin\&quot;,\&quot;BG-06\&quot;:\&quot;Vratsa\&quot;,\&quot;BG-28\&quot;:\&quot;Yambol\&quot;},\&quot;CA\&quot;:{\&quot;AB\&quot;:\&quot;Alberta\&quot;,\&quot;BC\&quot;:\&quot;British Columbia\&quot;,\&quot;MB\&quot;:\&quot;Manitoba\&quot;,\&quot;NB\&quot;:\&quot;New Brunswick\&quot;,\&quot;NL\&quot;:\&quot;Newfoundland and Labrador\&quot;,\&quot;NT\&quot;:\&quot;Northwest Territories\&quot;,\&quot;NS\&quot;:\&quot;Nova Scotia\&quot;,\&quot;NU\&quot;:\&quot;Nunavut\&quot;,\&quot;ON\&quot;:\&quot;Ontario\&quot;,\&quot;PE\&quot;:\&quot;Prince Edward Island\&quot;,\&quot;QC\&quot;:\&quot;Quebec\&quot;,\&quot;SK\&quot;:\&quot;Saskatchewan\&quot;,\&quot;YT\&quot;:\&quot;Yukon Territory\&quot;},\&quot;CN\&quot;:{\&quot;CN1\&quot;:\&quot;Yunnan \\\/ \u4e91\u5357\&quot;,\&quot;CN2\&quot;:\&quot;Beijing \\\/ \u5317\u4eac\&quot;,\&quot;CN3\&quot;:\&quot;Tianjin \\\/ \u5929\u6d25\&quot;,\&quot;CN4\&quot;:\&quot;Hebei \\\/ \u6cb3\u5317\&quot;,\&quot;CN5\&quot;:\&quot;Shanxi \\\/ \u5c71\u897f\&quot;,\&quot;CN6\&quot;:\&quot;Inner Mongolia \\\/ \u5167\u8499\u53e4\&quot;,\&quot;CN7\&quot;:\&quot;Liaoning \\\/ \u8fbd\u5b81\&quot;,\&quot;CN8\&quot;:\&quot;Jilin \\\/ \u5409\u6797\&quot;,\&quot;CN9\&quot;:\&quot;Heilongjiang \\\/ \u9ed1\u9f99\u6c5f\&quot;,\&quot;CN10\&quot;:\&quot;Shanghai \\\/ \u4e0a\u6d77\&quot;,\&quot;CN11\&quot;:\&quot;Jiangsu \\\/ \u6c5f\u82cf\&quot;,\&quot;CN12\&quot;:\&quot;Zhejiang \\\/ \u6d59\u6c5f\&quot;,\&quot;CN13\&quot;:\&quot;Anhui \\\/ \u5b89\u5fbd\&quot;,\&quot;CN14\&quot;:\&quot;Fujian \\\/ \u798f\u5efa\&quot;,\&quot;CN15\&quot;:\&quot;Jiangxi \\\/ \u6c5f\u897f\&quot;,\&quot;CN16\&quot;:\&quot;Shandong \\\/ \u5c71\u4e1c\&quot;,\&quot;CN17\&quot;:\&quot;Henan \\\/ \u6cb3\u5357\&quot;,\&quot;CN18\&quot;:\&quot;Hubei \\\/ \u6e56\u5317\&quot;,\&quot;CN19\&quot;:\&quot;Hunan \\\/ \u6e56\u5357\&quot;,\&quot;CN20\&quot;:\&quot;Guangdong \\\/ \u5e7f\u4e1c\&quot;,\&quot;CN21\&quot;:\&quot;Guangxi Zhuang \\\/ \u5e7f\u897f\u58ee\u65cf\&quot;,\&quot;CN22\&quot;:\&quot;Hainan \\\/ \u6d77\u5357\&quot;,\&quot;CN23\&quot;:\&quot;Chongqing \\\/ \u91cd\u5e86\&quot;,\&quot;CN24\&quot;:\&quot;Sichuan \\\/ \u56db\u5ddd\&quot;,\&quot;CN25\&quot;:\&quot;Guizhou \\\/ \u8d35\u5dde\&quot;,\&quot;CN26\&quot;:\&quot;Shaanxi \\\/ \u9655\u897f\&quot;,\&quot;CN27\&quot;:\&quot;Gansu \\\/ \u7518\u8083\&quot;,\&quot;CN28\&quot;:\&quot;Qinghai \\\/ \u9752\u6d77\&quot;,\&quot;CN29\&quot;:\&quot;Ningxia Hui \\\/ \u5b81\u590f\&quot;,\&quot;CN30\&quot;:\&quot;Macau \\\/ \u6fb3\u95e8\&quot;,\&quot;CN31\&quot;:\&quot;Tibet \\\/ \u897f\u85cf\&quot;,\&quot;CN32\&quot;:\&quot;Xinjiang \\\/ \u65b0\u7586\&quot;},\&quot;GR\&quot;:{\&quot;I\&quot;:\&quot;\\u0391\\u03c4\\u03c4\\u03b9\\u03ba\\u03ae\&quot;,\&quot;A\&quot;:\&quot;\\u0391\\u03bd\\u03b1\\u03c4\\u03bf\\u03bb\\u03b9\\u03ba\\u03ae \\u039c\\u03b1\\u03ba\\u03b5\\u03b4\\u03bf\\u03bd\\u03af\\u03b1 \\u03ba\\u03b1\\u03b9 \\u0398\\u03c1\\u03ac\\u03ba\\u03b7\&quot;,\&quot;B\&quot;:\&quot;\\u039a\\u03b5\\u03bd\\u03c4\\u03c1\\u03b9\\u03ba\\u03ae \\u039c\\u03b1\\u03ba\\u03b5\\u03b4\\u03bf\\u03bd\\u03af\\u03b1\&quot;,\&quot;C\&quot;:\&quot;\\u0394\\u03c5\\u03c4\\u03b9\\u03ba\\u03ae \\u039c\\u03b1\\u03ba\\u03b5\\u03b4\\u03bf\\u03bd\\u03af\\u03b1\&quot;,\&quot;D\&quot;:\&quot;\\u0389\\u03c0\\u03b5\\u03b9\\u03c1\\u03bf\\u03c2\&quot;,\&quot;E\&quot;:\&quot;\\u0398\\u03b5\\u03c3\\u03c3\\u03b1\\u03bb\\u03af\\u03b1\&quot;,\&quot;F\&quot;:\&quot;\\u0399\\u03cc\\u03bd\\u03b9\\u03bf\\u03b9 \\u039d\\u03ae\\u03c3\\u03bf\\u03b9\&quot;,\&quot;G\&quot;:\&quot;\\u0394\\u03c5\\u03c4\\u03b9\\u03ba\\u03ae \\u0395\\u03bb\\u03bb\\u03ac\\u03b4\\u03b1\&quot;,\&quot;H\&quot;:\&quot;\\u03a3\\u03c4\\u03b5\\u03c1\\u03b5\\u03ac \\u0395\\u03bb\\u03bb\\u03ac\\u03b4\\u03b1\&quot;,\&quot;J\&quot;:\&quot;\\u03a0\\u03b5\\u03bb\\u03bf\\u03c0\\u03cc\\u03bd\\u03bd\\u03b7\\u03c3\\u03bf\\u03c2\&quot;,\&quot;K\&quot;:\&quot;\\u0392\\u03cc\\u03c1\\u03b5\\u03b9\\u03bf \\u0391\\u03b9\\u03b3\\u03b1\\u03af\\u03bf\&quot;,\&quot;L\&quot;:\&quot;\\u039d\\u03cc\\u03c4\\u03b9\\u03bf \\u0391\\u03b9\\u03b3\\u03b1\\u03af\\u03bf\&quot;,\&quot;M\&quot;:\&quot;\\u039a\\u03c1\\u03ae\\u03c4\\u03b7\&quot;},\&quot;HK\&quot;:{\&quot;HONG KONG\&quot;:\&quot;Hong Kong Island\&quot;,\&quot;KOWLOON\&quot;:\&quot;Kowloon\&quot;,\&quot;NEW TERRITORIES\&quot;:\&quot;New Territories\&quot;},\&quot;HU\&quot;:{\&quot;BK\&quot;:\&quot;B\\u00e1cs-Kiskun\&quot;,\&quot;BE\&quot;:\&quot;B\\u00e9k\\u00e9s\&quot;,\&quot;BA\&quot;:\&quot;Baranya\&quot;,\&quot;BZ\&quot;:\&quot;Borsod-Aba\\u00faj-Zempl\\u00e9n\&quot;,\&quot;BU\&quot;:\&quot;Budapest\&quot;,\&quot;CS\&quot;:\&quot;Csongr\\u00e1d\&quot;,\&quot;FE\&quot;:\&quot;Fej\\u00e9r\&quot;,\&quot;GS\&quot;:\&quot;Gy\\u0151r-Moson-Sopron\&quot;,\&quot;HB\&quot;:\&quot;Hajd\\u00fa-Bihar\&quot;,\&quot;HE\&quot;:\&quot;Heves\&quot;,\&quot;JN\&quot;:\&quot;J\\u00e1sz-Nagykun-Szolnok\&quot;,\&quot;KE\&quot;:\&quot;Kom\\u00e1rom-Esztergom\&quot;,\&quot;NO\&quot;:\&quot;N\\u00f3gr\\u00e1d\&quot;,\&quot;PE\&quot;:\&quot;Pest\&quot;,\&quot;SO\&quot;:\&quot;Somogy\&quot;,\&quot;SZ\&quot;:\&quot;Szabolcs-Szatm\\u00e1r-Bereg\&quot;,\&quot;TO\&quot;:\&quot;Tolna\&quot;,\&quot;VA\&quot;:\&quot;Vas\&quot;,\&quot;VE\&quot;:\&quot;Veszpr\\u00e9m\&quot;,\&quot;ZA\&quot;:\&quot;Zala\&quot;},\&quot;IN\&quot;:{\&quot;AP\&quot;:\&quot;Andhra Pradesh\&quot;,\&quot;AR\&quot;:\&quot;Arunachal Pradesh\&quot;,\&quot;AS\&quot;:\&quot;Assam\&quot;,\&quot;BR\&quot;:\&quot;Bihar\&quot;,\&quot;CT\&quot;:\&quot;Chhattisgarh\&quot;,\&quot;GA\&quot;:\&quot;Goa\&quot;,\&quot;GJ\&quot;:\&quot;Gujarat\&quot;,\&quot;HR\&quot;:\&quot;Haryana\&quot;,\&quot;HP\&quot;:\&quot;Himachal Pradesh\&quot;,\&quot;JK\&quot;:\&quot;Jammu and Kashmir\&quot;,\&quot;JH\&quot;:\&quot;Jharkhand\&quot;,\&quot;KA\&quot;:\&quot;Karnataka\&quot;,\&quot;KL\&quot;:\&quot;Kerala\&quot;,\&quot;MP\&quot;:\&quot;Madhya Pradesh\&quot;,\&quot;MH\&quot;:\&quot;Maharashtra\&quot;,\&quot;MN\&quot;:\&quot;Manipur\&quot;,\&quot;ML\&quot;:\&quot;Meghalaya\&quot;,\&quot;MZ\&quot;:\&quot;Mizoram\&quot;,\&quot;NL\&quot;:\&quot;Nagaland\&quot;,\&quot;OR\&quot;:\&quot;Orissa\&quot;,\&quot;PB\&quot;:\&quot;Punjab\&quot;,\&quot;RJ\&quot;:\&quot;Rajasthan\&quot;,\&quot;SK\&quot;:\&quot;Sikkim\&quot;,\&quot;TN\&quot;:\&quot;Tamil Nadu\&quot;,\&quot;TS\&quot;:\&quot;Telangana\&quot;,\&quot;TR\&quot;:\&quot;Tripura\&quot;,\&quot;UK\&quot;:\&quot;Uttarakhand\&quot;,\&quot;UP\&quot;:\&quot;Uttar Pradesh\&quot;,\&quot;WB\&quot;:\&quot;West Bengal\&quot;,\&quot;AN\&quot;:\&quot;Andaman and Nicobar Islands\&quot;,\&quot;CH\&quot;:\&quot;Chandigarh\&quot;,\&quot;DN\&quot;:\&quot;Dadar and Nagar Haveli\&quot;,\&quot;DD\&quot;:\&quot;Daman and Diu\&quot;,\&quot;DL\&quot;:\&quot;Delhi\&quot;,\&quot;LD\&quot;:\&quot;Lakshadeep\&quot;,\&quot;PY\&quot;:\&quot;Pondicherry (Puducherry)\&quot;},\&quot;ID\&quot;:{\&quot;AC\&quot;:\&quot;Daerah Istimewa Aceh\&quot;,\&quot;SU\&quot;:\&quot;Sumatera Utara\&quot;,\&quot;SB\&quot;:\&quot;Sumatera Barat\&quot;,\&quot;RI\&quot;:\&quot;Riau\&quot;,\&quot;KR\&quot;:\&quot;Kepulauan Riau\&quot;,\&quot;JA\&quot;:\&quot;Jambi\&quot;,\&quot;SS\&quot;:\&quot;Sumatera Selatan\&quot;,\&quot;BB\&quot;:\&quot;Bangka Belitung\&quot;,\&quot;BE\&quot;:\&quot;Bengkulu\&quot;,\&quot;LA\&quot;:\&quot;Lampung\&quot;,\&quot;JK\&quot;:\&quot;DKI Jakarta\&quot;,\&quot;JB\&quot;:\&quot;Jawa Barat\&quot;,\&quot;BT\&quot;:\&quot;Banten\&quot;,\&quot;JT\&quot;:\&quot;Jawa Tengah\&quot;,\&quot;JI\&quot;:\&quot;Jawa Timur\&quot;,\&quot;YO\&quot;:\&quot;Daerah Istimewa Yogyakarta\&quot;,\&quot;BA\&quot;:\&quot;Bali\&quot;,\&quot;NB\&quot;:\&quot;Nusa Tenggara Barat\&quot;,\&quot;NT\&quot;:\&quot;Nusa Tenggara Timur\&quot;,\&quot;KB\&quot;:\&quot;Kalimantan Barat\&quot;,\&quot;KT\&quot;:\&quot;Kalimantan Tengah\&quot;,\&quot;KI\&quot;:\&quot;Kalimantan Timur\&quot;,\&quot;KS\&quot;:\&quot;Kalimantan Selatan\&quot;,\&quot;KU\&quot;:\&quot;Kalimantan Utara\&quot;,\&quot;SA\&quot;:\&quot;Sulawesi Utara\&quot;,\&quot;ST\&quot;:\&quot;Sulawesi Tengah\&quot;,\&quot;SG\&quot;:\&quot;Sulawesi Tenggara\&quot;,\&quot;SR\&quot;:\&quot;Sulawesi Barat\&quot;,\&quot;SN\&quot;:\&quot;Sulawesi Selatan\&quot;,\&quot;GO\&quot;:\&quot;Gorontalo\&quot;,\&quot;MA\&quot;:\&quot;Maluku\&quot;,\&quot;MU\&quot;:\&quot;Maluku Utara\&quot;,\&quot;PA\&quot;:\&quot;Papua\&quot;,\&quot;PB\&quot;:\&quot;Papua Barat\&quot;},\&quot;IR\&quot;:{\&quot;KHZ\&quot;:\&quot;Khuzestan  (\\u062e\\u0648\\u0632\\u0633\\u062a\\u0627\\u0646)\&quot;,\&quot;THR\&quot;:\&quot;Tehran  (\\u062a\\u0647\\u0631\\u0627\\u0646)\&quot;,\&quot;ILM\&quot;:\&quot;Ilaam (\\u0627\\u06cc\\u0644\\u0627\\u0645)\&quot;,\&quot;BHR\&quot;:\&quot;Bushehr (\\u0628\\u0648\\u0634\\u0647\\u0631)\&quot;,\&quot;ADL\&quot;:\&quot;Ardabil (\\u0627\\u0631\\u062f\\u0628\\u06cc\\u0644)\&quot;,\&quot;ESF\&quot;:\&quot;Isfahan (\\u0627\\u0635\\u0641\\u0647\\u0627\\u0646)\&quot;,\&quot;YZD\&quot;:\&quot;Yazd (\\u06cc\\u0632\\u062f)\&quot;,\&quot;KRH\&quot;:\&quot;Kermanshah (\\u06a9\\u0631\\u0645\\u0627\\u0646\\u0634\\u0627\\u0647)\&quot;,\&quot;KRN\&quot;:\&quot;Kerman (\\u06a9\\u0631\\u0645\\u0627\\u0646)\&quot;,\&quot;HDN\&quot;:\&quot;Hamadan (\\u0647\\u0645\\u062f\\u0627\\u0646)\&quot;,\&quot;GZN\&quot;:\&quot;Qazvin (\\u0642\\u0632\\u0648\\u06cc\\u0646)\&quot;,\&quot;ZJN\&quot;:\&quot;Zanjan (\\u0632\\u0646\\u062c\\u0627\\u0646)\&quot;,\&quot;LRS\&quot;:\&quot;Luristan (\\u0644\\u0631\\u0633\\u062a\\u0627\\u0646)\&quot;,\&quot;ABZ\&quot;:\&quot;Alborz (\\u0627\\u0644\\u0628\\u0631\\u0632)\&quot;,\&quot;EAZ\&quot;:\&quot;East Azarbaijan (\\u0622\\u0630\\u0631\\u0628\\u0627\\u06cc\\u062c\\u0627\\u0646 \\u0634\\u0631\\u0642\\u06cc)\&quot;,\&quot;WAZ\&quot;:\&quot;West Azarbaijan (\\u0622\\u0630\\u0631\\u0628\\u0627\\u06cc\\u062c\\u0627\\u0646 \\u063a\\u0631\\u0628\\u06cc)\&quot;,\&quot;CHB\&quot;:\&quot;Chaharmahal and Bakhtiari (\\u0686\\u0647\\u0627\\u0631\\u0645\\u062d\\u0627\\u0644 \\u0648 \\u0628\\u062e\\u062a\\u06cc\\u0627\\u0631\\u06cc)\&quot;,\&quot;SKH\&quot;:\&quot;South Khorasan (\\u062e\\u0631\\u0627\\u0633\\u0627\\u0646 \\u062c\\u0646\\u0648\\u0628\\u06cc)\&quot;,\&quot;RKH\&quot;:\&quot;Razavi Khorasan (\\u062e\\u0631\\u0627\\u0633\\u0627\\u0646 \\u0631\\u0636\\u0648\\u06cc)\&quot;,\&quot;NKH\&quot;:\&quot;North Khorasan (\\u062e\\u0631\\u0627\\u0633\\u0627\\u0646 \\u062c\\u0646\\u0648\\u0628\\u06cc)\&quot;,\&quot;SMN\&quot;:\&quot;Semnan (\\u0633\\u0645\\u0646\\u0627\\u0646)\&quot;,\&quot;FRS\&quot;:\&quot;Fars (\\u0641\\u0627\\u0631\\u0633)\&quot;,\&quot;QHM\&quot;:\&quot;Qom (\\u0642\\u0645)\&quot;,\&quot;KRD\&quot;:\&quot;Kurdistan (\\u06a9\\u0631\\u062f\\u0633\\u062a\\u0627\\u0646)\&quot;,\&quot;KBD\&quot;:\&quot;Kohgiluyeh and BoyerAhmad (\\u06a9\\u0647\\u06af\\u06cc\\u0644\\u0648\\u06cc\\u06cc\\u0647 \\u0648 \\u0628\\u0648\\u06cc\\u0631\\u0627\\u062d\\u0645\\u062f)\&quot;,\&quot;GLS\&quot;:\&quot;Golestan (\\u06af\\u0644\\u0633\\u062a\\u0627\\u0646)\&quot;,\&quot;GIL\&quot;:\&quot;Gilan (\\u06af\\u06cc\\u0644\\u0627\\u0646)\&quot;,\&quot;MZN\&quot;:\&quot;Mazandaran (\\u0645\\u0627\\u0632\\u0646\\u062f\\u0631\\u0627\\u0646)\&quot;,\&quot;MKZ\&quot;:\&quot;Markazi (\\u0645\\u0631\\u06a9\\u0632\\u06cc)\&quot;,\&quot;HRZ\&quot;:\&quot;Hormozgan (\\u0647\\u0631\\u0645\\u0632\\u06af\\u0627\\u0646)\&quot;,\&quot;SBN\&quot;:\&quot;Sistan and Baluchestan (\\u0633\\u06cc\\u0633\\u062a\\u0627\\u0646 \\u0648 \\u0628\\u0644\\u0648\\u0686\\u0633\\u062a\\u0627\\u0646)\&quot;},\&quot;IT\&quot;:{\&quot;AG\&quot;:\&quot;Agrigento\&quot;,\&quot;AL\&quot;:\&quot;Alessandria\&quot;,\&quot;AN\&quot;:\&quot;Ancona\&quot;,\&quot;AO\&quot;:\&quot;Aosta\&quot;,\&quot;AR\&quot;:\&quot;Arezzo\&quot;,\&quot;AP\&quot;:\&quot;Ascoli Piceno\&quot;,\&quot;AT\&quot;:\&quot;Asti\&quot;,\&quot;AV\&quot;:\&quot;Avellino\&quot;,\&quot;BA\&quot;:\&quot;Bari\&quot;,\&quot;BT\&quot;:\&quot;Barletta-Andria-Trani\&quot;,\&quot;BL\&quot;:\&quot;Belluno\&quot;,\&quot;BN\&quot;:\&quot;Benevento\&quot;,\&quot;BG\&quot;:\&quot;Bergamo\&quot;,\&quot;BI\&quot;:\&quot;Biella\&quot;,\&quot;BO\&quot;:\&quot;Bologna\&quot;,\&quot;BZ\&quot;:\&quot;Bolzano\&quot;,\&quot;BS\&quot;:\&quot;Brescia\&quot;,\&quot;BR\&quot;:\&quot;Brindisi\&quot;,\&quot;CA\&quot;:\&quot;Cagliari\&quot;,\&quot;CL\&quot;:\&quot;Caltanissetta\&quot;,\&quot;CB\&quot;:\&quot;Campobasso\&quot;,\&quot;CI\&quot;:\&quot;Carbonia-Iglesias\&quot;,\&quot;CE\&quot;:\&quot;Caserta\&quot;,\&quot;CT\&quot;:\&quot;Catania\&quot;,\&quot;CZ\&quot;:\&quot;Catanzaro\&quot;,\&quot;CH\&quot;:\&quot;Chieti\&quot;,\&quot;CO\&quot;:\&quot;Como\&quot;,\&quot;CS\&quot;:\&quot;Cosenza\&quot;,\&quot;CR\&quot;:\&quot;Cremona\&quot;,\&quot;KR\&quot;:\&quot;Crotone\&quot;,\&quot;CN\&quot;:\&quot;Cuneo\&quot;,\&quot;EN\&quot;:\&quot;Enna\&quot;,\&quot;FM\&quot;:\&quot;Fermo\&quot;,\&quot;FE\&quot;:\&quot;Ferrara\&quot;,\&quot;FI\&quot;:\&quot;Firenze\&quot;,\&quot;FG\&quot;:\&quot;Foggia\&quot;,\&quot;FC\&quot;:\&quot;Forl\\u00ec-Cesena\&quot;,\&quot;FR\&quot;:\&quot;Frosinone\&quot;,\&quot;GE\&quot;:\&quot;Genova\&quot;,\&quot;GO\&quot;:\&quot;Gorizia\&quot;,\&quot;GR\&quot;:\&quot;Grosseto\&quot;,\&quot;IM\&quot;:\&quot;Imperia\&quot;,\&quot;IS\&quot;:\&quot;Isernia\&quot;,\&quot;SP\&quot;:\&quot;La Spezia\&quot;,\&quot;AQ\&quot;:\&quot;L&amp;apos;Aquila\&quot;,\&quot;LT\&quot;:\&quot;Latina\&quot;,\&quot;LE\&quot;:\&quot;Lecce\&quot;,\&quot;LC\&quot;:\&quot;Lecco\&quot;,\&quot;LI\&quot;:\&quot;Livorno\&quot;,\&quot;LO\&quot;:\&quot;Lodi\&quot;,\&quot;LU\&quot;:\&quot;Lucca\&quot;,\&quot;MC\&quot;:\&quot;Macerata\&quot;,\&quot;MN\&quot;:\&quot;Mantova\&quot;,\&quot;MS\&quot;:\&quot;Massa-Carrara\&quot;,\&quot;MT\&quot;:\&quot;Matera\&quot;,\&quot;ME\&quot;:\&quot;Messina\&quot;,\&quot;MI\&quot;:\&quot;Milano\&quot;,\&quot;MO\&quot;:\&quot;Modena\&quot;,\&quot;MB\&quot;:\&quot;Monza e della Brianza\&quot;,\&quot;NA\&quot;:\&quot;Napoli\&quot;,\&quot;NO\&quot;:\&quot;Novara\&quot;,\&quot;NU\&quot;:\&quot;Nuoro\&quot;,\&quot;OT\&quot;:\&quot;Olbia-Tempio\&quot;,\&quot;OR\&quot;:\&quot;Oristano\&quot;,\&quot;PD\&quot;:\&quot;Padova\&quot;,\&quot;PA\&quot;:\&quot;Palermo\&quot;,\&quot;PR\&quot;:\&quot;Parma\&quot;,\&quot;PV\&quot;:\&quot;Pavia\&quot;,\&quot;PG\&quot;:\&quot;Perugia\&quot;,\&quot;PU\&quot;:\&quot;Pesaro e Urbino\&quot;,\&quot;PE\&quot;:\&quot;Pescara\&quot;,\&quot;PC\&quot;:\&quot;Piacenza\&quot;,\&quot;PI\&quot;:\&quot;Pisa\&quot;,\&quot;PT\&quot;:\&quot;Pistoia\&quot;,\&quot;PN\&quot;:\&quot;Pordenone\&quot;,\&quot;PZ\&quot;:\&quot;Potenza\&quot;,\&quot;PO\&quot;:\&quot;Prato\&quot;,\&quot;RG\&quot;:\&quot;Ragusa\&quot;,\&quot;RA\&quot;:\&quot;Ravenna\&quot;,\&quot;RC\&quot;:\&quot;Reggio Calabria\&quot;,\&quot;RE\&quot;:\&quot;Reggio Emilia\&quot;,\&quot;RI\&quot;:\&quot;Rieti\&quot;,\&quot;RN\&quot;:\&quot;Rimini\&quot;,\&quot;RM\&quot;:\&quot;Roma\&quot;,\&quot;RO\&quot;:\&quot;Rovigo\&quot;,\&quot;SA\&quot;:\&quot;Salerno\&quot;,\&quot;VS\&quot;:\&quot;Medio Campidano\&quot;,\&quot;SS\&quot;:\&quot;Sassari\&quot;,\&quot;SV\&quot;:\&quot;Savona\&quot;,\&quot;SI\&quot;:\&quot;Siena\&quot;,\&quot;SR\&quot;:\&quot;Siracusa\&quot;,\&quot;SO\&quot;:\&quot;Sondrio\&quot;,\&quot;TA\&quot;:\&quot;Taranto\&quot;,\&quot;TE\&quot;:\&quot;Teramo\&quot;,\&quot;TR\&quot;:\&quot;Terni\&quot;,\&quot;TO\&quot;:\&quot;Torino\&quot;,\&quot;OG\&quot;:\&quot;Ogliastra\&quot;,\&quot;TP\&quot;:\&quot;Trapani\&quot;,\&quot;TN\&quot;:\&quot;Trento\&quot;,\&quot;TV\&quot;:\&quot;Treviso\&quot;,\&quot;TS\&quot;:\&quot;Trieste\&quot;,\&quot;UD\&quot;:\&quot;Udine\&quot;,\&quot;VA\&quot;:\&quot;Varese\&quot;,\&quot;VE\&quot;:\&quot;Venezia\&quot;,\&quot;VB\&quot;:\&quot;Verbano-Cusio-Ossola\&quot;,\&quot;VC\&quot;:\&quot;Vercelli\&quot;,\&quot;VR\&quot;:\&quot;Verona\&quot;,\&quot;VV\&quot;:\&quot;Vibo Valentia\&quot;,\&quot;VI\&quot;:\&quot;Vicenza\&quot;,\&quot;VT\&quot;:\&quot;Viterbo\&quot;},\&quot;JP\&quot;:{\&quot;JP01\&quot;:\&quot;Hokkaido\&quot;,\&quot;JP02\&quot;:\&quot;Aomori\&quot;,\&quot;JP03\&quot;:\&quot;Iwate\&quot;,\&quot;JP04\&quot;:\&quot;Miyagi\&quot;,\&quot;JP05\&quot;:\&quot;Akita\&quot;,\&quot;JP06\&quot;:\&quot;Yamagata\&quot;,\&quot;JP07\&quot;:\&quot;Fukushima\&quot;,\&quot;JP08\&quot;:\&quot;Ibaraki\&quot;,\&quot;JP09\&quot;:\&quot;Tochigi\&quot;,\&quot;JP10\&quot;:\&quot;Gunma\&quot;,\&quot;JP11\&quot;:\&quot;Saitama\&quot;,\&quot;JP12\&quot;:\&quot;Chiba\&quot;,\&quot;JP13\&quot;:\&quot;Tokyo\&quot;,\&quot;JP14\&quot;:\&quot;Kanagawa\&quot;,\&quot;JP15\&quot;:\&quot;Niigata\&quot;,\&quot;JP16\&quot;:\&quot;Toyama\&quot;,\&quot;JP17\&quot;:\&quot;Ishikawa\&quot;,\&quot;JP18\&quot;:\&quot;Fukui\&quot;,\&quot;JP19\&quot;:\&quot;Yamanashi\&quot;,\&quot;JP20\&quot;:\&quot;Nagano\&quot;,\&quot;JP21\&quot;:\&quot;Gifu\&quot;,\&quot;JP22\&quot;:\&quot;Shizuoka\&quot;,\&quot;JP23\&quot;:\&quot;Aichi\&quot;,\&quot;JP24\&quot;:\&quot;Mie\&quot;,\&quot;JP25\&quot;:\&quot;Shiga\&quot;,\&quot;JP26\&quot;:\&quot;Kyoto\&quot;,\&quot;JP27\&quot;:\&quot;Osaka\&quot;,\&quot;JP28\&quot;:\&quot;Hyogo\&quot;,\&quot;JP29\&quot;:\&quot;Nara\&quot;,\&quot;JP30\&quot;:\&quot;Wakayama\&quot;,\&quot;JP31\&quot;:\&quot;Tottori\&quot;,\&quot;JP32\&quot;:\&quot;Shimane\&quot;,\&quot;JP33\&quot;:\&quot;Okayama\&quot;,\&quot;JP34\&quot;:\&quot;Hiroshima\&quot;,\&quot;JP35\&quot;:\&quot;Yamaguchi\&quot;,\&quot;JP36\&quot;:\&quot;Tokushima\&quot;,\&quot;JP37\&quot;:\&quot;Kagawa\&quot;,\&quot;JP38\&quot;:\&quot;Ehime\&quot;,\&quot;JP39\&quot;:\&quot;Kochi\&quot;,\&quot;JP40\&quot;:\&quot;Fukuoka\&quot;,\&quot;JP41\&quot;:\&quot;Saga\&quot;,\&quot;JP42\&quot;:\&quot;Nagasaki\&quot;,\&quot;JP43\&quot;:\&quot;Kumamoto\&quot;,\&quot;JP44\&quot;:\&quot;Oita\&quot;,\&quot;JP45\&quot;:\&quot;Miyazaki\&quot;,\&quot;JP46\&quot;:\&quot;Kagoshima\&quot;,\&quot;JP47\&quot;:\&quot;Okinawa\&quot;},\&quot;MY\&quot;:{\&quot;JHR\&quot;:\&quot;Johor\&quot;,\&quot;KDH\&quot;:\&quot;Kedah\&quot;,\&quot;KTN\&quot;:\&quot;Kelantan\&quot;,\&quot;LBN\&quot;:\&quot;Labuan\&quot;,\&quot;MLK\&quot;:\&quot;Malacca (Melaka)\&quot;,\&quot;NSN\&quot;:\&quot;Negeri Sembilan\&quot;,\&quot;PHG\&quot;:\&quot;Pahang\&quot;,\&quot;PNG\&quot;:\&quot;Penang (Pulau Pinang)\&quot;,\&quot;PRK\&quot;:\&quot;Perak\&quot;,\&quot;PLS\&quot;:\&quot;Perlis\&quot;,\&quot;SBH\&quot;:\&quot;Sabah\&quot;,\&quot;SWK\&quot;:\&quot;Sarawak\&quot;,\&quot;SGR\&quot;:\&quot;Selangor\&quot;,\&quot;TRG\&quot;:\&quot;Terengganu\&quot;,\&quot;PJY\&quot;:\&quot;Putrajaya\&quot;,\&quot;KUL\&quot;:\&quot;Kuala Lumpur\&quot;},\&quot;MX\&quot;:{\&quot;Distrito Federal\&quot;:\&quot;Distrito Federal\&quot;,\&quot;Jalisco\&quot;:\&quot;Jalisco\&quot;,\&quot;Nuevo Leon\&quot;:\&quot;Nuevo Le\\u00f3n\&quot;,\&quot;Aguascalientes\&quot;:\&quot;Aguascalientes\&quot;,\&quot;Baja California\&quot;:\&quot;Baja California\&quot;,\&quot;Baja California Sur\&quot;:\&quot;Baja California Sur\&quot;,\&quot;Campeche\&quot;:\&quot;Campeche\&quot;,\&quot;Chiapas\&quot;:\&quot;Chiapas\&quot;,\&quot;Chihuahua\&quot;:\&quot;Chihuahua\&quot;,\&quot;Coahuila\&quot;:\&quot;Coahuila\&quot;,\&quot;Colima\&quot;:\&quot;Colima\&quot;,\&quot;Durango\&quot;:\&quot;Durango\&quot;,\&quot;Guanajuato\&quot;:\&quot;Guanajuato\&quot;,\&quot;Guerrero\&quot;:\&quot;Guerrero\&quot;,\&quot;Hidalgo\&quot;:\&quot;Hidalgo\&quot;,\&quot;Estado de Mexico\&quot;:\&quot;Edo. de M\\u00e9xico\&quot;,\&quot;Michoacan\&quot;:\&quot;Michoac\\u00e1n\&quot;,\&quot;Morelos\&quot;:\&quot;Morelos\&quot;,\&quot;Nayarit\&quot;:\&quot;Nayarit\&quot;,\&quot;Oaxaca\&quot;:\&quot;Oaxaca\&quot;,\&quot;Puebla\&quot;:\&quot;Puebla\&quot;,\&quot;Queretaro\&quot;:\&quot;Quer\\u00e9taro\&quot;,\&quot;Quintana Roo\&quot;:\&quot;Quintana Roo\&quot;,\&quot;San Luis Potosi\&quot;:\&quot;San Luis Potos\\u00ed\&quot;,\&quot;Sinaloa\&quot;:\&quot;Sinaloa\&quot;,\&quot;Sonora\&quot;:\&quot;Sonora\&quot;,\&quot;Tabasco\&quot;:\&quot;Tabasco\&quot;,\&quot;Tamaulipas\&quot;:\&quot;Tamaulipas\&quot;,\&quot;Tlaxcala\&quot;:\&quot;Tlaxcala\&quot;,\&quot;Veracruz\&quot;:\&quot;Veracruz\&quot;,\&quot;Yucatan\&quot;:\&quot;Yucat\\u00e1n\&quot;,\&quot;Zacatecas\&quot;:\&quot;Zacatecas\&quot;},\&quot;NP\&quot;:{\&quot;BAG\&quot;:\&quot;Bagmati\&quot;,\&quot;BHE\&quot;:\&quot;Bheri\&quot;,\&quot;DHA\&quot;:\&quot;Dhawalagiri\&quot;,\&quot;GAN\&quot;:\&quot;Gandaki\&quot;,\&quot;JAN\&quot;:\&quot;Janakpur\&quot;,\&quot;KAR\&quot;:\&quot;Karnali\&quot;,\&quot;KOS\&quot;:\&quot;Koshi\&quot;,\&quot;LUM\&quot;:\&quot;Lumbini\&quot;,\&quot;MAH\&quot;:\&quot;Mahakali\&quot;,\&quot;MEC\&quot;:\&quot;Mechi\&quot;,\&quot;NAR\&quot;:\&quot;Narayani\&quot;,\&quot;RAP\&quot;:\&quot;Rapti\&quot;,\&quot;SAG\&quot;:\&quot;Sagarmatha\&quot;,\&quot;SET\&quot;:\&quot;Seti\&quot;},\&quot;NZ\&quot;:{\&quot;NL\&quot;:\&quot;Northland\&quot;,\&quot;AK\&quot;:\&quot;Auckland\&quot;,\&quot;WA\&quot;:\&quot;Waikato\&quot;,\&quot;BP\&quot;:\&quot;Bay of Plenty\&quot;,\&quot;TK\&quot;:\&quot;Taranaki\&quot;,\&quot;GI\&quot;:\&quot;Gisborne\&quot;,\&quot;HB\&quot;:\&quot;Hawke\u2019s Bay\&quot;,\&quot;MW\&quot;:\&quot;Manawatu-Wanganui\&quot;,\&quot;WE\&quot;:\&quot;Wellington\&quot;,\&quot;NS\&quot;:\&quot;Nelson\&quot;,\&quot;MB\&quot;:\&quot;Marlborough\&quot;,\&quot;TM\&quot;:\&quot;Tasman\&quot;,\&quot;WC\&quot;:\&quot;West Coast\&quot;,\&quot;CT\&quot;:\&quot;Canterbury\&quot;,\&quot;OT\&quot;:\&quot;Otago\&quot;,\&quot;SL\&quot;:\&quot;Southland\&quot;},\&quot;PE\&quot;:{\&quot;CAL\&quot;:\&quot;El Callao\&quot;,\&quot;LMA\&quot;:\&quot;Municipalidad Metropolitana de Lima\&quot;,\&quot;AMA\&quot;:\&quot;Amazonas\&quot;,\&quot;ANC\&quot;:\&quot;Ancash\&quot;,\&quot;APU\&quot;:\&quot;Apur\u00edmac\&quot;,\&quot;ARE\&quot;:\&quot;Arequipa\&quot;,\&quot;AYA\&quot;:\&quot;Ayacucho\&quot;,\&quot;CAJ\&quot;:\&quot;Cajamarca\&quot;,\&quot;CUS\&quot;:\&quot;Cusco\&quot;,\&quot;HUV\&quot;:\&quot;Huancavelica\&quot;,\&quot;HUC\&quot;:\&quot;Hu\u00e1nuco\&quot;,\&quot;ICA\&quot;:\&quot;Ica\&quot;,\&quot;JUN\&quot;:\&quot;Jun\u00edn\&quot;,\&quot;LAL\&quot;:\&quot;La Libertad\&quot;,\&quot;LAM\&quot;:\&quot;Lambayeque\&quot;,\&quot;LIM\&quot;:\&quot;Lima\&quot;,\&quot;LOR\&quot;:\&quot;Loreto\&quot;,\&quot;MDD\&quot;:\&quot;Madre de Dios\&quot;,\&quot;MOQ\&quot;:\&quot;Moquegua\&quot;,\&quot;PAS\&quot;:\&quot;Pasco\&quot;,\&quot;PIU\&quot;:\&quot;Piura\&quot;,\&quot;PUN\&quot;:\&quot;Puno\&quot;,\&quot;SAM\&quot;:\&quot;San Mart\u00edn\&quot;,\&quot;TAC\&quot;:\&quot;Tacna\&quot;,\&quot;TUM\&quot;:\&quot;Tumbes\&quot;,\&quot;UCA\&quot;:\&quot;Ucayali\&quot;},\&quot;PH\&quot;:{\&quot;ABR\&quot;:\&quot;Abra\&quot;,\&quot;AGN\&quot;:\&quot;Agusan del Norte\&quot;,\&quot;AGS\&quot;:\&quot;Agusan del Sur\&quot;,\&quot;AKL\&quot;:\&quot;Aklan\&quot;,\&quot;ALB\&quot;:\&quot;Albay\&quot;,\&quot;ANT\&quot;:\&quot;Antique\&quot;,\&quot;APA\&quot;:\&quot;Apayao\&quot;,\&quot;AUR\&quot;:\&quot;Aurora\&quot;,\&quot;BAS\&quot;:\&quot;Basilan\&quot;,\&quot;BAN\&quot;:\&quot;Bataan\&quot;,\&quot;BTN\&quot;:\&quot;Batanes\&quot;,\&quot;BTG\&quot;:\&quot;Batangas\&quot;,\&quot;BEN\&quot;:\&quot;Benguet\&quot;,\&quot;BIL\&quot;:\&quot;Biliran\&quot;,\&quot;BOH\&quot;:\&quot;Bohol\&quot;,\&quot;BUK\&quot;:\&quot;Bukidnon\&quot;,\&quot;BUL\&quot;:\&quot;Bulacan\&quot;,\&quot;CAG\&quot;:\&quot;Cagayan\&quot;,\&quot;CAN\&quot;:\&quot;Camarines Norte\&quot;,\&quot;CAS\&quot;:\&quot;Camarines Sur\&quot;,\&quot;CAM\&quot;:\&quot;Camiguin\&quot;,\&quot;CAP\&quot;:\&quot;Capiz\&quot;,\&quot;CAT\&quot;:\&quot;Catanduanes\&quot;,\&quot;CAV\&quot;:\&quot;Cavite\&quot;,\&quot;CEB\&quot;:\&quot;Cebu\&quot;,\&quot;COM\&quot;:\&quot;Compostela Valley\&quot;,\&quot;NCO\&quot;:\&quot;Cotabato\&quot;,\&quot;DAV\&quot;:\&quot;Davao del Norte\&quot;,\&quot;DAS\&quot;:\&quot;Davao del Sur\&quot;,\&quot;DAC\&quot;:\&quot;Davao Occidental\&quot;,\&quot;DAO\&quot;:\&quot;Davao Oriental\&quot;,\&quot;DIN\&quot;:\&quot;Dinagat Islands\&quot;,\&quot;EAS\&quot;:\&quot;Eastern Samar\&quot;,\&quot;GUI\&quot;:\&quot;Guimaras\&quot;,\&quot;IFU\&quot;:\&quot;Ifugao\&quot;,\&quot;ILN\&quot;:\&quot;Ilocos Norte\&quot;,\&quot;ILS\&quot;:\&quot;Ilocos Sur\&quot;,\&quot;ILI\&quot;:\&quot;Iloilo\&quot;,\&quot;ISA\&quot;:\&quot;Isabela\&quot;,\&quot;KAL\&quot;:\&quot;Kalinga\&quot;,\&quot;LUN\&quot;:\&quot;La Union\&quot;,\&quot;LAG\&quot;:\&quot;Laguna\&quot;,\&quot;LAN\&quot;:\&quot;Lanao del Norte\&quot;,\&quot;LAS\&quot;:\&quot;Lanao del Sur\&quot;,\&quot;LEY\&quot;:\&quot;Leyte\&quot;,\&quot;MAG\&quot;:\&quot;Maguindanao\&quot;,\&quot;MAD\&quot;:\&quot;Marinduque\&quot;,\&quot;MAS\&quot;:\&quot;Masbate\&quot;,\&quot;MSC\&quot;:\&quot;Misamis Occidental\&quot;,\&quot;MSR\&quot;:\&quot;Misamis Oriental\&quot;,\&quot;MOU\&quot;:\&quot;Mountain Province\&quot;,\&quot;NEC\&quot;:\&quot;Negros Occidental\&quot;,\&quot;NER\&quot;:\&quot;Negros Oriental\&quot;,\&quot;NSA\&quot;:\&quot;Northern Samar\&quot;,\&quot;NUE\&quot;:\&quot;Nueva Ecija\&quot;,\&quot;NUV\&quot;:\&quot;Nueva Vizcaya\&quot;,\&quot;MDC\&quot;:\&quot;Occidental Mindoro\&quot;,\&quot;MDR\&quot;:\&quot;Oriental Mindoro\&quot;,\&quot;PLW\&quot;:\&quot;Palawan\&quot;,\&quot;PAM\&quot;:\&quot;Pampanga\&quot;,\&quot;PAN\&quot;:\&quot;Pangasinan\&quot;,\&quot;QUE\&quot;:\&quot;Quezon\&quot;,\&quot;QUI\&quot;:\&quot;Quirino\&quot;,\&quot;RIZ\&quot;:\&quot;Rizal\&quot;,\&quot;ROM\&quot;:\&quot;Romblon\&quot;,\&quot;WSA\&quot;:\&quot;Samar\&quot;,\&quot;SAR\&quot;:\&quot;Sarangani\&quot;,\&quot;SIQ\&quot;:\&quot;Siquijor\&quot;,\&quot;SOR\&quot;:\&quot;Sorsogon\&quot;,\&quot;SCO\&quot;:\&quot;South Cotabato\&quot;,\&quot;SLE\&quot;:\&quot;Southern Leyte\&quot;,\&quot;SUK\&quot;:\&quot;Sultan Kudarat\&quot;,\&quot;SLU\&quot;:\&quot;Sulu\&quot;,\&quot;SUN\&quot;:\&quot;Surigao del Norte\&quot;,\&quot;SUR\&quot;:\&quot;Surigao del Sur\&quot;,\&quot;TAR\&quot;:\&quot;Tarlac\&quot;,\&quot;TAW\&quot;:\&quot;Tawi-Tawi\&quot;,\&quot;ZMB\&quot;:\&quot;Zambales\&quot;,\&quot;ZAN\&quot;:\&quot;Zamboanga del Norte\&quot;,\&quot;ZAS\&quot;:\&quot;Zamboanga del Sur\&quot;,\&quot;ZSI\&quot;:\&quot;Zamboanga Sibugay\&quot;,\&quot;00\&quot;:\&quot;Metro Manila\&quot;},\&quot;ZA\&quot;:{\&quot;EC\&quot;:\&quot;Eastern Cape\&quot;,\&quot;FS\&quot;:\&quot;Free State\&quot;,\&quot;GP\&quot;:\&quot;Gauteng\&quot;,\&quot;KZN\&quot;:\&quot;KwaZulu-Natal\&quot;,\&quot;LP\&quot;:\&quot;Limpopo\&quot;,\&quot;MP\&quot;:\&quot;Mpumalanga\&quot;,\&quot;NC\&quot;:\&quot;Northern Cape\&quot;,\&quot;NW\&quot;:\&quot;North West\&quot;,\&quot;WC\&quot;:\&quot;Western Cape\&quot;},\&quot;ES\&quot;:{\&quot;C\&quot;:\&quot;A Coru\u00f1a\&quot;,\&quot;VI\&quot;:\&quot;Araba\\\/\u00c1lava\&quot;,\&quot;AB\&quot;:\&quot;Albacete\&quot;,\&quot;A\&quot;:\&quot;Alicante\&quot;,\&quot;AL\&quot;:\&quot;Almer\u00eda\&quot;,\&quot;O\&quot;:\&quot;Asturias\&quot;,\&quot;AV\&quot;:\&quot;\u00c1vila\&quot;,\&quot;BA\&quot;:\&quot;Badajoz\&quot;,\&quot;PM\&quot;:\&quot;Baleares\&quot;,\&quot;B\&quot;:\&quot;Barcelona\&quot;,\&quot;BU\&quot;:\&quot;Burgos\&quot;,\&quot;CC\&quot;:\&quot;C\u00e1ceres\&quot;,\&quot;CA\&quot;:\&quot;C\u00e1diz\&quot;,\&quot;S\&quot;:\&quot;Cantabria\&quot;,\&quot;CS\&quot;:\&quot;Castell\u00f3n\&quot;,\&quot;CE\&quot;:\&quot;Ceuta\&quot;,\&quot;CR\&quot;:\&quot;Ciudad Real\&quot;,\&quot;CO\&quot;:\&quot;C\u00f3rdoba\&quot;,\&quot;CU\&quot;:\&quot;Cuenca\&quot;,\&quot;GI\&quot;:\&quot;Girona\&quot;,\&quot;GR\&quot;:\&quot;Granada\&quot;,\&quot;GU\&quot;:\&quot;Guadalajara\&quot;,\&quot;SS\&quot;:\&quot;Gipuzkoa\&quot;,\&quot;H\&quot;:\&quot;Huelva\&quot;,\&quot;HU\&quot;:\&quot;Huesca\&quot;,\&quot;J\&quot;:\&quot;Ja\u00e9n\&quot;,\&quot;LO\&quot;:\&quot;La Rioja\&quot;,\&quot;GC\&quot;:\&quot;Las Palmas\&quot;,\&quot;LE\&quot;:\&quot;Le\u00f3n\&quot;,\&quot;L\&quot;:\&quot;Lleida\&quot;,\&quot;LU\&quot;:\&quot;Lugo\&quot;,\&quot;M\&quot;:\&quot;Madrid\&quot;,\&quot;MA\&quot;:\&quot;M\u00e1laga\&quot;,\&quot;ML\&quot;:\&quot;Melilla\&quot;,\&quot;MU\&quot;:\&quot;Murcia\&quot;,\&quot;NA\&quot;:\&quot;Navarra\&quot;,\&quot;OR\&quot;:\&quot;Ourense\&quot;,\&quot;P\&quot;:\&quot;Palencia\&quot;,\&quot;PO\&quot;:\&quot;Pontevedra\&quot;,\&quot;SA\&quot;:\&quot;Salamanca\&quot;,\&quot;TF\&quot;:\&quot;Santa Cruz de Tenerife\&quot;,\&quot;SG\&quot;:\&quot;Segovia\&quot;,\&quot;SE\&quot;:\&quot;Sevilla\&quot;,\&quot;SO\&quot;:\&quot;Soria\&quot;,\&quot;T\&quot;:\&quot;Tarragona\&quot;,\&quot;TE\&quot;:\&quot;Teruel\&quot;,\&quot;TO\&quot;:\&quot;Toledo\&quot;,\&quot;V\&quot;:\&quot;Valencia\&quot;,\&quot;VA\&quot;:\&quot;Valladolid\&quot;,\&quot;BI\&quot;:\&quot;Bizkaia\&quot;,\&quot;ZA\&quot;:\&quot;Zamora\&quot;,\&quot;Z\&quot;:\&quot;Zaragoza\&quot;},\&quot;TH\&quot;:{\&quot;TH-37\&quot;:\&quot;Amnat Charoen (\u0e2d\u0e33\u0e19\u0e32\u0e08\u0e40\u0e08\u0e23\u0e34\u0e0d)\&quot;,\&quot;TH-15\&quot;:\&quot;Ang Thong (\u0e2d\u0e48\u0e32\u0e07\u0e17\u0e2d\u0e07)\&quot;,\&quot;TH-14\&quot;:\&quot;Ayutthaya (\u0e1e\u0e23\u0e30\u0e19\u0e04\u0e23\u0e28\u0e23\u0e35\u0e2d\u0e22\u0e38\u0e18\u0e22\u0e32)\&quot;,\&quot;TH-10\&quot;:\&quot;Bangkok (\u0e01\u0e23\u0e38\u0e07\u0e40\u0e17\u0e1e\u0e21\u0e2b\u0e32\u0e19\u0e04\u0e23)\&quot;,\&quot;TH-38\&quot;:\&quot;Bueng Kan (\u0e1a\u0e36\u0e07\u0e01\u0e32\u0e2c)\&quot;,\&quot;TH-31\&quot;:\&quot;Buri Ram (\u0e1a\u0e38\u0e23\u0e35\u0e23\u0e31\u0e21\u0e22\u0e4c)\&quot;,\&quot;TH-24\&quot;:\&quot;Chachoengsao (\u0e09\u0e30\u0e40\u0e0a\u0e34\u0e07\u0e40\u0e17\u0e23\u0e32)\&quot;,\&quot;TH-18\&quot;:\&quot;Chai Nat (\u0e0a\u0e31\u0e22\u0e19\u0e32\u0e17)\&quot;,\&quot;TH-36\&quot;:\&quot;Chaiyaphum (\u0e0a\u0e31\u0e22\u0e20\u0e39\u0e21\u0e34)\&quot;,\&quot;TH-22\&quot;:\&quot;Chanthaburi (\u0e08\u0e31\u0e19\u0e17\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-50\&quot;:\&quot;Chiang Mai (\u0e40\u0e0a\u0e35\u0e22\u0e07\u0e43\u0e2b\u0e21\u0e48)\&quot;,\&quot;TH-57\&quot;:\&quot;Chiang Rai (\u0e40\u0e0a\u0e35\u0e22\u0e07\u0e23\u0e32\u0e22)\&quot;,\&quot;TH-20\&quot;:\&quot;Chonburi (\u0e0a\u0e25\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-86\&quot;:\&quot;Chumphon (\u0e0a\u0e38\u0e21\u0e1e\u0e23)\&quot;,\&quot;TH-46\&quot;:\&quot;Kalasin (\u0e01\u0e32\u0e2c\u0e2a\u0e34\u0e19\u0e18\u0e38\u0e4c)\&quot;,\&quot;TH-62\&quot;:\&quot;Kamphaeng Phet (\u0e01\u0e33\u0e41\u0e1e\u0e07\u0e40\u0e1e\u0e0a\u0e23)\&quot;,\&quot;TH-71\&quot;:\&quot;Kanchanaburi (\u0e01\u0e32\u0e0d\u0e08\u0e19\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-40\&quot;:\&quot;Khon Kaen (\u0e02\u0e2d\u0e19\u0e41\u0e01\u0e48\u0e19)\&quot;,\&quot;TH-81\&quot;:\&quot;Krabi (\u0e01\u0e23\u0e30\u0e1a\u0e35\u0e48)\&quot;,\&quot;TH-52\&quot;:\&quot;Lampang (\u0e25\u0e33\u0e1b\u0e32\u0e07)\&quot;,\&quot;TH-51\&quot;:\&quot;Lamphun (\u0e25\u0e33\u0e1e\u0e39\u0e19)\&quot;,\&quot;TH-42\&quot;:\&quot;Loei (\u0e40\u0e25\u0e22)\&quot;,\&quot;TH-16\&quot;:\&quot;Lopburi (\u0e25\u0e1e\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-58\&quot;:\&quot;Mae Hong Son (\u0e41\u0e21\u0e48\u0e2e\u0e48\u0e2d\u0e07\u0e2a\u0e2d\u0e19)\&quot;,\&quot;TH-44\&quot;:\&quot;Maha Sarakham (\u0e21\u0e2b\u0e32\u0e2a\u0e32\u0e23\u0e04\u0e32\u0e21)\&quot;,\&quot;TH-49\&quot;:\&quot;Mukdahan (\u0e21\u0e38\u0e01\u0e14\u0e32\u0e2b\u0e32\u0e23)\&quot;,\&quot;TH-26\&quot;:\&quot;Nakhon Nayok (\u0e19\u0e04\u0e23\u0e19\u0e32\u0e22\u0e01)\&quot;,\&quot;TH-73\&quot;:\&quot;Nakhon Pathom (\u0e19\u0e04\u0e23\u0e1b\u0e10\u0e21)\&quot;,\&quot;TH-48\&quot;:\&quot;Nakhon Phanom (\u0e19\u0e04\u0e23\u0e1e\u0e19\u0e21)\&quot;,\&quot;TH-30\&quot;:\&quot;Nakhon Ratchasima (\u0e19\u0e04\u0e23\u0e23\u0e32\u0e0a\u0e2a\u0e35\u0e21\u0e32)\&quot;,\&quot;TH-60\&quot;:\&quot;Nakhon Sawan (\u0e19\u0e04\u0e23\u0e2a\u0e27\u0e23\u0e23\u0e04\u0e4c)\&quot;,\&quot;TH-80\&quot;:\&quot;Nakhon Si Thammarat (\u0e19\u0e04\u0e23\u0e28\u0e23\u0e35\u0e18\u0e23\u0e23\u0e21\u0e23\u0e32\u0e0a)\&quot;,\&quot;TH-55\&quot;:\&quot;Nan (\u0e19\u0e48\u0e32\u0e19)\&quot;,\&quot;TH-96\&quot;:\&quot;Narathiwat (\u0e19\u0e23\u0e32\u0e18\u0e34\u0e27\u0e32\u0e2a)\&quot;,\&quot;TH-39\&quot;:\&quot;Nong Bua Lam Phu (\u0e2b\u0e19\u0e2d\u0e07\u0e1a\u0e31\u0e27\u0e25\u0e33\u0e20\u0e39)\&quot;,\&quot;TH-43\&quot;:\&quot;Nong Khai (\u0e2b\u0e19\u0e2d\u0e07\u0e04\u0e32\u0e22)\&quot;,\&quot;TH-12\&quot;:\&quot;Nonthaburi (\u0e19\u0e19\u0e17\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-13\&quot;:\&quot;Pathum Thani (\u0e1b\u0e17\u0e38\u0e21\u0e18\u0e32\u0e19\u0e35)\&quot;,\&quot;TH-94\&quot;:\&quot;Pattani (\u0e1b\u0e31\u0e15\u0e15\u0e32\u0e19\u0e35)\&quot;,\&quot;TH-82\&quot;:\&quot;Phang Nga (\u0e1e\u0e31\u0e07\u0e07\u0e32)\&quot;,\&quot;TH-93\&quot;:\&quot;Phatthalung (\u0e1e\u0e31\u0e17\u0e25\u0e38\u0e07)\&quot;,\&quot;TH-56\&quot;:\&quot;Phayao (\u0e1e\u0e30\u0e40\u0e22\u0e32)\&quot;,\&quot;TH-67\&quot;:\&quot;Phetchabun (\u0e40\u0e1e\u0e0a\u0e23\u0e1a\u0e39\u0e23\u0e13\u0e4c)\&quot;,\&quot;TH-76\&quot;:\&quot;Phetchaburi (\u0e40\u0e1e\u0e0a\u0e23\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-66\&quot;:\&quot;Phichit (\u0e1e\u0e34\u0e08\u0e34\u0e15\u0e23)\&quot;,\&quot;TH-65\&quot;:\&quot;Phitsanulok (\u0e1e\u0e34\u0e29\u0e13\u0e38\u0e42\u0e25\u0e01)\&quot;,\&quot;TH-54\&quot;:\&quot;Phrae (\u0e41\u0e1e\u0e23\u0e48)\&quot;,\&quot;TH-83\&quot;:\&quot;Phuket (\u0e20\u0e39\u0e40\u0e01\u0e47\u0e15)\&quot;,\&quot;TH-25\&quot;:\&quot;Prachin Buri (\u0e1b\u0e23\u0e32\u0e08\u0e35\u0e19\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-77\&quot;:\&quot;Prachuap Khiri Khan (\u0e1b\u0e23\u0e30\u0e08\u0e27\u0e1a\u0e04\u0e35\u0e23\u0e35\u0e02\u0e31\u0e19\u0e18\u0e4c)\&quot;,\&quot;TH-85\&quot;:\&quot;Ranong (\u0e23\u0e30\u0e19\u0e2d\u0e07)\&quot;,\&quot;TH-70\&quot;:\&quot;Ratchaburi (\u0e23\u0e32\u0e0a\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-21\&quot;:\&quot;Rayong (\u0e23\u0e30\u0e22\u0e2d\u0e07)\&quot;,\&quot;TH-45\&quot;:\&quot;Roi Et (\u0e23\u0e49\u0e2d\u0e22\u0e40\u0e2d\u0e47\u0e14)\&quot;,\&quot;TH-27\&quot;:\&quot;Sa Kaeo (\u0e2a\u0e23\u0e30\u0e41\u0e01\u0e49\u0e27)\&quot;,\&quot;TH-47\&quot;:\&quot;Sakon Nakhon (\u0e2a\u0e01\u0e25\u0e19\u0e04\u0e23)\&quot;,\&quot;TH-11\&quot;:\&quot;Samut Prakan (\u0e2a\u0e21\u0e38\u0e17\u0e23\u0e1b\u0e23\u0e32\u0e01\u0e32\u0e23)\&quot;,\&quot;TH-74\&quot;:\&quot;Samut Sakhon (\u0e2a\u0e21\u0e38\u0e17\u0e23\u0e2a\u0e32\u0e04\u0e23)\&quot;,\&quot;TH-75\&quot;:\&quot;Samut Songkhram (\u0e2a\u0e21\u0e38\u0e17\u0e23\u0e2a\u0e07\u0e04\u0e23\u0e32\u0e21)\&quot;,\&quot;TH-19\&quot;:\&quot;Saraburi (\u0e2a\u0e23\u0e30\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-91\&quot;:\&quot;Satun (\u0e2a\u0e15\u0e39\u0e25)\&quot;,\&quot;TH-17\&quot;:\&quot;Sing Buri (\u0e2a\u0e34\u0e07\u0e2b\u0e4c\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-33\&quot;:\&quot;Sisaket (\u0e28\u0e23\u0e35\u0e2a\u0e30\u0e40\u0e01\u0e29)\&quot;,\&quot;TH-90\&quot;:\&quot;Songkhla (\u0e2a\u0e07\u0e02\u0e25\u0e32)\&quot;,\&quot;TH-64\&quot;:\&quot;Sukhothai (\u0e2a\u0e38\u0e42\u0e02\u0e17\u0e31\u0e22)\&quot;,\&quot;TH-72\&quot;:\&quot;Suphan Buri (\u0e2a\u0e38\u0e1e\u0e23\u0e23\u0e13\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-84\&quot;:\&quot;Surat Thani (\u0e2a\u0e38\u0e23\u0e32\u0e29\u0e0e\u0e23\u0e4c\u0e18\u0e32\u0e19\u0e35)\&quot;,\&quot;TH-32\&quot;:\&quot;Surin (\u0e2a\u0e38\u0e23\u0e34\u0e19\u0e17\u0e23\u0e4c)\&quot;,\&quot;TH-63\&quot;:\&quot;Tak (\u0e15\u0e32\u0e01)\&quot;,\&quot;TH-92\&quot;:\&quot;Trang (\u0e15\u0e23\u0e31\u0e07)\&quot;,\&quot;TH-23\&quot;:\&quot;Trat (\u0e15\u0e23\u0e32\u0e14)\&quot;,\&quot;TH-34\&quot;:\&quot;Ubon Ratchathani (\u0e2d\u0e38\u0e1a\u0e25\u0e23\u0e32\u0e0a\u0e18\u0e32\u0e19\u0e35)\&quot;,\&quot;TH-41\&quot;:\&quot;Udon Thani (\u0e2d\u0e38\u0e14\u0e23\u0e18\u0e32\u0e19\u0e35)\&quot;,\&quot;TH-61\&quot;:\&quot;Uthai Thani (\u0e2d\u0e38\u0e17\u0e31\u0e22\u0e18\u0e32\u0e19\u0e35)\&quot;,\&quot;TH-53\&quot;:\&quot;Uttaradit (\u0e2d\u0e38\u0e15\u0e23\u0e14\u0e34\u0e15\u0e16\u0e4c)\&quot;,\&quot;TH-95\&quot;:\&quot;Yala (\u0e22\u0e30\u0e25\u0e32)\&quot;,\&quot;TH-35\&quot;:\&quot;Yasothon (\u0e22\u0e42\u0e2a\u0e18\u0e23)\&quot;},\&quot;TR\&quot;:{\&quot;TR01\&quot;:\&quot;Adana\&quot;,\&quot;TR02\&quot;:\&quot;Ad\u0131yaman\&quot;,\&quot;TR03\&quot;:\&quot;Afyon\&quot;,\&quot;TR04\&quot;:\&quot;A\u011fr\u0131\&quot;,\&quot;TR05\&quot;:\&quot;Amasya\&quot;,\&quot;TR06\&quot;:\&quot;Ankara\&quot;,\&quot;TR07\&quot;:\&quot;Antalya\&quot;,\&quot;TR08\&quot;:\&quot;Artvin\&quot;,\&quot;TR09\&quot;:\&quot;Ayd\u0131n\&quot;,\&quot;TR10\&quot;:\&quot;Bal\u0131kesir\&quot;,\&quot;TR11\&quot;:\&quot;Bilecik\&quot;,\&quot;TR12\&quot;:\&quot;Bing\u00f6l\&quot;,\&quot;TR13\&quot;:\&quot;Bitlis\&quot;,\&quot;TR14\&quot;:\&quot;Bolu\&quot;,\&quot;TR15\&quot;:\&quot;Burdur\&quot;,\&quot;TR16\&quot;:\&quot;Bursa\&quot;,\&quot;TR17\&quot;:\&quot;\u00c7anakkale\&quot;,\&quot;TR18\&quot;:\&quot;\u00c7ank\u0131r\u0131\&quot;,\&quot;TR19\&quot;:\&quot;\u00c7orum\&quot;,\&quot;TR20\&quot;:\&quot;Denizli\&quot;,\&quot;TR21\&quot;:\&quot;Diyarbak\u0131r\&quot;,\&quot;TR22\&quot;:\&quot;Edirne\&quot;,\&quot;TR23\&quot;:\&quot;Elaz\u0131\u011f\&quot;,\&quot;TR24\&quot;:\&quot;Erzincan\&quot;,\&quot;TR25\&quot;:\&quot;Erzurum\&quot;,\&quot;TR26\&quot;:\&quot;Eski\u015fehir\&quot;,\&quot;TR27\&quot;:\&quot;Gaziantep\&quot;,\&quot;TR28\&quot;:\&quot;Giresun\&quot;,\&quot;TR29\&quot;:\&quot;G\u00fcm\u00fc\u015fhane\&quot;,\&quot;TR30\&quot;:\&quot;Hakkari\&quot;,\&quot;TR31\&quot;:\&quot;Hatay\&quot;,\&quot;TR32\&quot;:\&quot;Isparta\&quot;,\&quot;TR33\&quot;:\&quot;\u0130\u00e7el\&quot;,\&quot;TR34\&quot;:\&quot;\u0130stanbul\&quot;,\&quot;TR35\&quot;:\&quot;\u0130zmir\&quot;,\&quot;TR36\&quot;:\&quot;Kars\&quot;,\&quot;TR37\&quot;:\&quot;Kastamonu\&quot;,\&quot;TR38\&quot;:\&quot;Kayseri\&quot;,\&quot;TR39\&quot;:\&quot;K\u0131rklareli\&quot;,\&quot;TR40\&quot;:\&quot;K\u0131r\u015fehir\&quot;,\&quot;TR41\&quot;:\&quot;Kocaeli\&quot;,\&quot;TR42\&quot;:\&quot;Konya\&quot;,\&quot;TR43\&quot;:\&quot;K\u00fctahya\&quot;,\&quot;TR44\&quot;:\&quot;Malatya\&quot;,\&quot;TR45\&quot;:\&quot;Manisa\&quot;,\&quot;TR46\&quot;:\&quot;Kahramanmara\u015f\&quot;,\&quot;TR47\&quot;:\&quot;Mardin\&quot;,\&quot;TR48\&quot;:\&quot;Mu\u011fla\&quot;,\&quot;TR49\&quot;:\&quot;Mu\u015f\&quot;,\&quot;TR50\&quot;:\&quot;Nev\u015fehir\&quot;,\&quot;TR51\&quot;:\&quot;Ni\u011fde\&quot;,\&quot;TR52\&quot;:\&quot;Ordu\&quot;,\&quot;TR53\&quot;:\&quot;Rize\&quot;,\&quot;TR54\&quot;:\&quot;Sakarya\&quot;,\&quot;TR55\&quot;:\&quot;Samsun\&quot;,\&quot;TR56\&quot;:\&quot;Siirt\&quot;,\&quot;TR57\&quot;:\&quot;Sinop\&quot;,\&quot;TR58\&quot;:\&quot;Sivas\&quot;,\&quot;TR59\&quot;:\&quot;Tekirda\u011f\&quot;,\&quot;TR60\&quot;:\&quot;Tokat\&quot;,\&quot;TR61\&quot;:\&quot;Trabzon\&quot;,\&quot;TR62\&quot;:\&quot;Tunceli\&quot;,\&quot;TR63\&quot;:\&quot;\u015eanl\u0131urfa\&quot;,\&quot;TR64\&quot;:\&quot;U\u015fak\&quot;,\&quot;TR65\&quot;:\&quot;Van\&quot;,\&quot;TR66\&quot;:\&quot;Yozgat\&quot;,\&quot;TR67\&quot;:\&quot;Zonguldak\&quot;,\&quot;TR68\&quot;:\&quot;Aksaray\&quot;,\&quot;TR69\&quot;:\&quot;Bayburt\&quot;,\&quot;TR70\&quot;:\&quot;Karaman\&quot;,\&quot;TR71\&quot;:\&quot;K\u0131r\u0131kkale\&quot;,\&quot;TR72\&quot;:\&quot;Batman\&quot;,\&quot;TR73\&quot;:\&quot;\u015e\u0131rnak\&quot;,\&quot;TR74\&quot;:\&quot;Bart\u0131n\&quot;,\&quot;TR75\&quot;:\&quot;Ardahan\&quot;,\&quot;TR76\&quot;:\&quot;I\u011fd\u0131r\&quot;,\&quot;TR77\&quot;:\&quot;Yalova\&quot;,\&quot;TR78\&quot;:\&quot;Karab\u00fck\&quot;,\&quot;TR79\&quot;:\&quot;Kilis\&quot;,\&quot;TR80\&quot;:\&quot;Osmaniye\&quot;,\&quot;TR81\&quot;:\&quot;D\u00fczce\&quot;},\&quot;US\&quot;:{\&quot;AL\&quot;:\&quot;Alabama\&quot;,\&quot;AK\&quot;:\&quot;Alaska\&quot;,\&quot;AZ\&quot;:\&quot;Arizona\&quot;,\&quot;AR\&quot;:\&quot;Arkansas\&quot;,\&quot;CA\&quot;:\&quot;California\&quot;,\&quot;CO\&quot;:\&quot;Colorado\&quot;,\&quot;CT\&quot;:\&quot;Connecticut\&quot;,\&quot;DE\&quot;:\&quot;Delaware\&quot;,\&quot;DC\&quot;:\&quot;District Of Columbia\&quot;,\&quot;FL\&quot;:\&quot;Florida\&quot;,\&quot;GA\&quot;:\&quot;Georgia\&quot;,\&quot;HI\&quot;:\&quot;Hawaii\&quot;,\&quot;ID\&quot;:\&quot;Idaho\&quot;,\&quot;IL\&quot;:\&quot;Illinois\&quot;,\&quot;IN\&quot;:\&quot;Indiana\&quot;,\&quot;IA\&quot;:\&quot;Iowa\&quot;,\&quot;KS\&quot;:\&quot;Kansas\&quot;,\&quot;KY\&quot;:\&quot;Kentucky\&quot;,\&quot;LA\&quot;:\&quot;Louisiana\&quot;,\&quot;ME\&quot;:\&quot;Maine\&quot;,\&quot;MD\&quot;:\&quot;Maryland\&quot;,\&quot;MA\&quot;:\&quot;Massachusetts\&quot;,\&quot;MI\&quot;:\&quot;Michigan\&quot;,\&quot;MN\&quot;:\&quot;Minnesota\&quot;,\&quot;MS\&quot;:\&quot;Mississippi\&quot;,\&quot;MO\&quot;:\&quot;Missouri\&quot;,\&quot;MT\&quot;:\&quot;Montana\&quot;,\&quot;NE\&quot;:\&quot;Nebraska\&quot;,\&quot;NV\&quot;:\&quot;Nevada\&quot;,\&quot;NH\&quot;:\&quot;New Hampshire\&quot;,\&quot;NJ\&quot;:\&quot;New Jersey\&quot;,\&quot;NM\&quot;:\&quot;New Mexico\&quot;,\&quot;NY\&quot;:\&quot;New York\&quot;,\&quot;NC\&quot;:\&quot;North Carolina\&quot;,\&quot;ND\&quot;:\&quot;North Dakota\&quot;,\&quot;OH\&quot;:\&quot;Ohio\&quot;,\&quot;OK\&quot;:\&quot;Oklahoma\&quot;,\&quot;OR\&quot;:\&quot;Oregon\&quot;,\&quot;PA\&quot;:\&quot;Pennsylvania\&quot;,\&quot;RI\&quot;:\&quot;Rhode Island\&quot;,\&quot;SC\&quot;:\&quot;South Carolina\&quot;,\&quot;SD\&quot;:\&quot;South Dakota\&quot;,\&quot;TN\&quot;:\&quot;Tennessee\&quot;,\&quot;TX\&quot;:\&quot;Texas\&quot;,\&quot;UT\&quot;:\&quot;Utah\&quot;,\&quot;VT\&quot;:\&quot;Vermont\&quot;,\&quot;VA\&quot;:\&quot;Virginia\&quot;,\&quot;WA\&quot;:\&quot;Washington\&quot;,\&quot;WV\&quot;:\&quot;West Virginia\&quot;,\&quot;WI\&quot;:\&quot;Wisconsin\&quot;,\&quot;WY\&quot;:\&quot;Wyoming\&quot;,\&quot;AA\&quot;:\&quot;Armed Forces (AA)\&quot;,\&quot;AE\&quot;:\&quot;Armed Forces (AE)\&quot;,\&quot;AP\&quot;:\&quot;Armed Forces (AP)\&quot;}}&quot;,&quot;i18n_select_state_text&quot;:&quot;Select an option\u2026&quot;,&quot;i18n_matches_1&quot;:&quot;One result is available, press enter to select it.&quot;,&quot;i18n_matches_n&quot;:&quot;%qty% results are available, use up and down arrow keys to navigate.&quot;,&quot;i18n_no_matches&quot;:&quot;No matches found&quot;,&quot;i18n_ajax_error&quot;:&quot;Loading failed&quot;,&quot;i18n_input_too_short_1&quot;:&quot;Please enter 1 or more characters&quot;,&quot;i18n_input_too_short_n&quot;:&quot;Please enter %qty% or more characters&quot;,&quot;i18n_input_too_long_1&quot;:&quot;Please delete 1 character&quot;,&quot;i18n_input_too_long_n&quot;:&quot;Please delete %qty% characters&quot;,&quot;i18n_selection_too_long_1&quot;:&quot;You can only select 1 item&quot;,&quot;i18n_selection_too_long_n&quot;:&quot;You can only select %qty% items&quot;,&quot;i18n_load_more&quot;:&quot;Loading more results\u2026&quot;,&quot;i18n_searching&quot;:&quot;Searching\u2026&quot;};
/* ]]&gt; */



/* &lt;![CDATA[ */
var wc_address_i18n_params = {&quot;locale&quot;:&quot;{\&quot;AE\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false,\&quot;hidden\&quot;:true}},\&quot;AF\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;AT\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;AU\&quot;:{\&quot;city\&quot;:{\&quot;label\&quot;:\&quot;Suburb\&quot;},\&quot;postcode\&quot;:{\&quot;label\&quot;:\&quot;Postcode\&quot;},\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;State\&quot;}},\&quot;AX\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;BD\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false},\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;District\&quot;}},\&quot;BE\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false,\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;BI\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;BO\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false,\&quot;hidden\&quot;:true}},\&quot;BS\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false,\&quot;hidden\&quot;:true}},\&quot;CA\&quot;:{\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;CH\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Canton\&quot;,\&quot;required\&quot;:false}},\&quot;CL\&quot;:{\&quot;city\&quot;:{\&quot;required\&quot;:true},\&quot;postcode\&quot;:{\&quot;required\&quot;:false},\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Region\&quot;}},\&quot;CN\&quot;:{\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;CO\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false}},\&quot;CZ\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;DE\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;DK\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;EE\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;FI\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;FR\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;HK\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false},\&quot;city\&quot;:{\&quot;label\&quot;:\&quot;Town \\\/ District\&quot;},\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Region\&quot;}},\&quot;HU\&quot;:{\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;County\&quot;}},\&quot;ID\&quot;:{\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;IE\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false,\&quot;label\&quot;:\&quot;Postcode\&quot;}},\&quot;IS\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;IL\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;IT\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:true,\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;JP\&quot;:{\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Prefecture\&quot;}},\&quot;KR\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;NL\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false,\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;NZ\&quot;:{\&quot;postcode\&quot;:{\&quot;label\&quot;:\&quot;Postcode\&quot;},\&quot;state\&quot;:{\&quot;required\&quot;:false,\&quot;label\&quot;:\&quot;Region\&quot;}},\&quot;NO\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;NP\&quot;:{\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;State \\\/ Zone\&quot;},\&quot;postcode\&quot;:{\&quot;required\&quot;:false}},\&quot;PL\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;PT\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;RO\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;SG\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;SK\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;SI\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;ES\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;LI\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Municipality\&quot;,\&quot;required\&quot;:false}},\&quot;LK\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;SE\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;TR\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;US\&quot;:{\&quot;postcode\&quot;:{\&quot;label\&quot;:\&quot;ZIP\&quot;},\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;State\&quot;}},\&quot;GB\&quot;:{\&quot;postcode\&quot;:{\&quot;label\&quot;:\&quot;Postcode\&quot;},\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;County\&quot;,\&quot;required\&quot;:false}},\&quot;VN\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false},\&quot;postcode\&quot;:{\&quot;required\&quot;:false,\&quot;hidden\&quot;:false},\&quot;address_2\&quot;:{\&quot;required\&quot;:false,\&quot;hidden\&quot;:true}},\&quot;WS\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false,\&quot;hidden\&quot;:true}},\&quot;ZA\&quot;:{\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;ZW\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false,\&quot;hidden\&quot;:true}},\&quot;default\&quot;:{\&quot;first_name\&quot;:{\&quot;label\&quot;:\&quot;First Name\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-first\&quot;],\&quot;autocomplete\&quot;:\&quot;given-name\&quot;},\&quot;last_name\&quot;:{\&quot;label\&quot;:\&quot;Last Name\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-last\&quot;],\&quot;clear\&quot;:true,\&quot;autocomplete\&quot;:\&quot;family-name\&quot;},\&quot;company\&quot;:{\&quot;label\&quot;:\&quot;Company Name\&quot;,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;],\&quot;autocomplete\&quot;:\&quot;organization\&quot;},\&quot;country\&quot;:{\&quot;type\&quot;:\&quot;country\&quot;,\&quot;label\&quot;:\&quot;Country\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;,\&quot;update_totals_on_change\&quot;],\&quot;autocomplete\&quot;:\&quot;country\&quot;},\&quot;address_1\&quot;:{\&quot;label\&quot;:\&quot;Address\&quot;,\&quot;placeholder\&quot;:\&quot;Street address\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;],\&quot;autocomplete\&quot;:\&quot;address-line1\&quot;},\&quot;address_2\&quot;:{\&quot;placeholder\&quot;:\&quot;Apartment, suite, unit etc. (optional)\&quot;,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;],\&quot;required\&quot;:false,\&quot;autocomplete\&quot;:\&quot;address-line2\&quot;},\&quot;city\&quot;:{\&quot;label\&quot;:\&quot;Town \\\/ City\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;],\&quot;autocomplete\&quot;:\&quot;address-level2\&quot;},\&quot;state\&quot;:{\&quot;type\&quot;:\&quot;state\&quot;,\&quot;label\&quot;:\&quot;State \\\/ County\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-first\&quot;,\&quot;address-field\&quot;],\&quot;validate\&quot;:[\&quot;state\&quot;],\&quot;autocomplete\&quot;:\&quot;address-level1\&quot;},\&quot;postcode\&quot;:{\&quot;label\&quot;:\&quot;Postcode \\\/ ZIP\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-last\&quot;,\&quot;address-field\&quot;],\&quot;clear\&quot;:true,\&quot;validate\&quot;:[\&quot;postcode\&quot;],\&quot;autocomplete\&quot;:\&quot;postal-code\&quot;}},\&quot;IN\&quot;:{\&quot;first_name\&quot;:{\&quot;label\&quot;:\&quot;First Name\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-first\&quot;],\&quot;autocomplete\&quot;:\&quot;given-name\&quot;},\&quot;last_name\&quot;:{\&quot;label\&quot;:\&quot;Last Name\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-last\&quot;],\&quot;clear\&quot;:true,\&quot;autocomplete\&quot;:\&quot;family-name\&quot;},\&quot;company\&quot;:{\&quot;label\&quot;:\&quot;Company Name\&quot;,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;],\&quot;autocomplete\&quot;:\&quot;organization\&quot;},\&quot;country\&quot;:{\&quot;type\&quot;:\&quot;country\&quot;,\&quot;label\&quot;:\&quot;Country\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;,\&quot;update_totals_on_change\&quot;],\&quot;autocomplete\&quot;:\&quot;country\&quot;},\&quot;address_1\&quot;:{\&quot;label\&quot;:\&quot;Address\&quot;,\&quot;placeholder\&quot;:\&quot;Street address\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;],\&quot;autocomplete\&quot;:\&quot;address-line1\&quot;},\&quot;address_2\&quot;:{\&quot;placeholder\&quot;:\&quot;Apartment, suite, unit etc. (optional)\&quot;,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;],\&quot;required\&quot;:false,\&quot;autocomplete\&quot;:\&quot;address-line2\&quot;},\&quot;city\&quot;:{\&quot;label\&quot;:\&quot;Town \\\/ City\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;],\&quot;autocomplete\&quot;:\&quot;address-level2\&quot;},\&quot;state\&quot;:{\&quot;type\&quot;:\&quot;state\&quot;,\&quot;label\&quot;:\&quot;State \\\/ County\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-first\&quot;,\&quot;address-field\&quot;],\&quot;validate\&quot;:[\&quot;state\&quot;],\&quot;autocomplete\&quot;:\&quot;address-level1\&quot;},\&quot;postcode\&quot;:{\&quot;label\&quot;:\&quot;Postcode \\\/ ZIP\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-last\&quot;,\&quot;address-field\&quot;],\&quot;clear\&quot;:true,\&quot;validate\&quot;:[\&quot;postcode\&quot;],\&quot;autocomplete\&quot;:\&quot;postal-code\&quot;}}}&quot;,&quot;locale_fields&quot;:&quot;{\&quot;address_1\&quot;:\&quot;#billing_address_1_field, #shipping_address_1_field\&quot;,\&quot;address_2\&quot;:\&quot;#billing_address_2_field, #shipping_address_2_field\&quot;,\&quot;state\&quot;:\&quot;#billing_state_field, #shipping_state_field, #calc_shipping_state_field\&quot;,\&quot;postcode\&quot;:\&quot;#billing_postcode_field, #shipping_postcode_field, #calc_shipping_postcode_field\&quot;,\&quot;city\&quot;:\&quot;#billing_city_field, #shipping_city_field, #calc_shipping_city_field\&quot;}&quot;,&quot;i18n_required_text&quot;:&quot;required&quot;};
/* ]]&gt; */



/* &lt;![CDATA[ */
var wc_checkout_params = {&quot;ajax_url&quot;:&quot;\/wp-admin\/admin-ajax.php&quot;,&quot;wc_ajax_url&quot;:&quot;\/checkout\/?wc-ajax=%%endpoint%%&quot;,&quot;update_order_review_nonce&quot;:&quot;54fc2529e7&quot;,&quot;apply_coupon_nonce&quot;:&quot;4cab8888ca&quot;,&quot;remove_coupon_nonce&quot;:&quot;057942b4fe&quot;,&quot;option_guest_checkout&quot;:&quot;yes&quot;,&quot;checkout_url&quot;:&quot;\/checkout\/?wc-ajax=checkout&quot;,&quot;is_checkout&quot;:&quot;1&quot;,&quot;debug_mode&quot;:&quot;&quot;,&quot;i18n_checkout_error&quot;:&quot;Error processing checkout. Please try again.&quot;};
/* ]]&gt; */




/* &lt;![CDATA[ */
var wc_cart_fragments_params = {&quot;ajax_url&quot;:&quot;\/wp-admin\/admin-ajax.php&quot;,&quot;wc_ajax_url&quot;:&quot;\/checkout\/?wc-ajax=%%endpoint%%&quot;,&quot;fragment_name&quot;:&quot;wc_fragments&quot;};
/* ]]&gt; */







/* &lt;![CDATA[ */
var themifyScript = {&quot;lightbox&quot;:{&quot;lightboxSelector&quot;:&quot;.themify_lightbox&quot;,&quot;lightboxOn&quot;:true,&quot;lightboxContentImages&quot;:false,&quot;lightboxContentImagesSelector&quot;:&quot;.post-content a[href$=jpg],.page-content a[href$=jpg],.post-content a[href$=gif],.page-content a[href$=gif],.post-content a[href$=png],.page-content a[href$=png],.post-content a[href$=JPG],.page-content a[href$=JPG],.post-content a[href$=GIF],.page-content a[href$=GIF],.post-content a[href$=PNG],.page-content a[href$=PNG],.post-content a[href$=jpeg],.page-content a[href$=jpeg],.post-content a[href$=JPEG],.page-content a[href$=JPEG]&quot;,&quot;theme&quot;:&quot;pp_default&quot;,&quot;social_tools&quot;:false,&quot;allow_resize&quot;:true,&quot;show_title&quot;:false,&quot;overlay_gallery&quot;:false,&quot;screenWidthNoLightbox&quot;:600,&quot;deeplinking&quot;:false,&quot;contentImagesAreas&quot;:&quot;.post, .type-page, .type-highlight, .type-slider&quot;,&quot;gallerySelector&quot;:&quot;.gallery-icon > a[href$=jpg],.gallery-icon > a[href$=gif],.gallery-icon > a[href$=png],.gallery-icon > a[href$=JPG],.gallery-icon > a[href$=GIF],.gallery-icon > a[href$=PNG],.gallery-icon > a[href$=jpeg],.gallery-icon > a[href$=JPEG]&quot;,&quot;lightboxGalleryOn&quot;:true},&quot;lightboxContext&quot;:&quot;#pagewrap&quot;,&quot;fixedHeader&quot;:&quot;fixed-header&quot;,&quot;ajax_nonce&quot;:&quot;9edb8546c3&quot;,&quot;ajax_url&quot;:&quot;https:\/\/practice.automationtesting.in\/wp-admin\/admin-ajax.php&quot;,&quot;smallScreen&quot;:&quot;760&quot;,&quot;resizeRefresh&quot;:&quot;250&quot;,&quot;parallaxHeader&quot;:&quot;1&quot;,&quot;loadingImg&quot;:&quot;https:\/\/practice.automationtesting.in\/wp-content\/themes\/themify-ultra\/images\/loading.gif&quot;,&quot;maxPages&quot;:&quot;0&quot;,&quot;autoInfinite&quot;:&quot;auto&quot;,&quot;scrollToNewOnLoad&quot;:&quot;scroll&quot;,&quot;resetFilterOnLoad&quot;:&quot;reset&quot;,&quot;fullPageScroll&quot;:&quot;&quot;,&quot;scrollHighlight&quot;:{&quot;scroll&quot;:&quot;internal&quot;}};
/* ]]&gt; */




/* &lt;![CDATA[ */
var mc4wp_forms_config = [];
/* ]]&gt; */





jQuery(function($) { 

	jQuery( function( $ ) {
		var ppec_mark_fields      = &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_title, #woocommerce_ppec_paypal_description&quot; , &quot;'&quot; , &quot;;
		var ppec_live_fields      = &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_api_username, #woocommerce_ppec_paypal_api_password, #woocommerce_ppec_paypal_api_signature, #woocommerce_ppec_paypal_api_certificate, #woocommerce_ppec_paypal_api_subject&quot; , &quot;'&quot; , &quot;;
		var ppec_sandbox_fields   = &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_sandbox_api_username, #woocommerce_ppec_paypal_sandbox_api_password, #woocommerce_ppec_paypal_sandbox_api_signature, #woocommerce_ppec_paypal_sandbox_api_certificate, #woocommerce_ppec_paypal_sandbox_api_subject&quot; , &quot;'&quot; , &quot;;

		var enable_toggle         = $( &quot; , &quot;'&quot; , &quot;a.ppec-toggle-settings&quot; , &quot;'&quot; , &quot; ).length > 0;
		var enable_sandbox_toggle = $( &quot; , &quot;'&quot; , &quot;a.ppec-toggle-sandbox-settings&quot; , &quot;'&quot; , &quot; ).length > 0;

		$( &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_environment&quot; , &quot;'&quot; , &quot; ).change(function(){
			$( ppec_sandbox_fields + &quot; , &quot;'&quot; , &quot;,&quot; , &quot;'&quot; , &quot; + ppec_live_fields ).closest( &quot; , &quot;'&quot; , &quot;tr&quot; , &quot;'&quot; , &quot; ).hide();

			if ( &quot; , &quot;'&quot; , &quot;live&quot; , &quot;'&quot; , &quot; === $( this ).val() ) {
				$( &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_api_credentials, #woocommerce_ppec_paypal_api_credentials + p&quot; , &quot;'&quot; , &quot; ).show();
				$( &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_sandbox_api_credentials, #woocommerce_ppec_paypal_sandbox_api_credentials + p&quot; , &quot;'&quot; , &quot; ).hide();

				if ( ! enable_toggle ) {
					$( ppec_live_fields ).closest( &quot; , &quot;'&quot; , &quot;tr&quot; , &quot;'&quot; , &quot; ).show();
				}
			} else {
				$( &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_api_credentials, #woocommerce_ppec_paypal_api_credentials + p&quot; , &quot;'&quot; , &quot; ).hide();
				$( &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_sandbox_api_credentials, #woocommerce_ppec_paypal_sandbox_api_credentials + p&quot; , &quot;'&quot; , &quot; ).show();

				if ( ! enable_sandbox_toggle ) {
					$( ppec_sandbox_fields ).closest( &quot; , &quot;'&quot; , &quot;tr&quot; , &quot;'&quot; , &quot; ).show();
				}
			}
		}).change();

		$( &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_mark_enabled&quot; , &quot;'&quot; , &quot; ).change(function(){
			if ( $( this ).is( &quot; , &quot;'&quot; , &quot;:checked&quot; , &quot;'&quot; , &quot; ) ) {
				$( ppec_mark_fields ).closest( &quot; , &quot;'&quot; , &quot;tr&quot; , &quot;'&quot; , &quot; ).show();
			} else {
				$( ppec_mark_fields ).closest( &quot; , &quot;'&quot; , &quot;tr&quot; , &quot;'&quot; , &quot; ).hide();
			}
		}).change();

		$( &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_paymentaction&quot; , &quot;'&quot; , &quot; ).change(function(){
			if ( &quot; , &quot;'&quot; , &quot;sale&quot; , &quot;'&quot; , &quot; === $( this ).val() ) {
				$( &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_instant_payments&quot; , &quot;'&quot; , &quot; ).closest( &quot; , &quot;'&quot; , &quot;tr&quot; , &quot;'&quot; , &quot; ).show();
			} else {
				$( &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_instant_payments&quot; , &quot;'&quot; , &quot; ).closest( &quot; , &quot;'&quot; , &quot;tr&quot; , &quot;'&quot; , &quot; ).hide();
			}
		}).change();

		if ( enable_toggle ) {
			$( document ).on( &quot; , &quot;'&quot; , &quot;click&quot; , &quot;'&quot; , &quot;, &quot; , &quot;'&quot; , &quot;.ppec-toggle-settings&quot; , &quot;'&quot; , &quot;, function() {
				$( ppec_live_fields ).closest( &quot; , &quot;'&quot; , &quot;tr&quot; , &quot;'&quot; , &quot; ).toggle();
			} );
		}
		if ( enable_sandbox_toggle ) {
			$( document ).on( &quot; , &quot;'&quot; , &quot;click&quot; , &quot;'&quot; , &quot;, &quot; , &quot;'&quot; , &quot;.ppec-toggle-sandbox-settings&quot; , &quot;'&quot; , &quot;, function() {
				$( ppec_sandbox_fields ).closest( &quot; , &quot;'&quot; , &quot;tr&quot; , &quot;'&quot; , &quot; ).toggle();
			} );
		}
	});

 });

		
			if (&quot; , &quot;'&quot; , &quot;object&quot; , &quot;'&quot; , &quot; === typeof tbLocalScript) {
				tbLocalScript.transitionSelectors = &quot;.js.csstransitions .module.wow, .js.csstransitions .themify_builder_content .themify_builder_row.wow, .js.csstransitions .module_row.wow, .js.csstransitions .builder-posts-wrap > .post.wow, .js.csstransitions .fly-in > .post, .js.csstransitions .fly-in .row_inner > .tb-column, .js.csstransitions .fade-in > .post, .js.csstransitions .fade-in .row_inner > .tb-column, .js.csstransitions .slide-up > .post, .js.csstransitions .slide-up .row_inner > .tb-column&quot;;
			}
		
			
id(&quot;billing_last_name&quot;)Software&quot;) or . = concat(&quot;




			

			
			

			

	            
	            
		            						Automation Practice Site					
									
				

									

													
																									
															
							
						
													
								

	

	

							
							
						
													
								Shop 
My Account 
Test Cases 
AT Site 
Demo Site 
1 item₹450.00								
							
							
						
													
		
							
								 
 
 
 
 
					



(adsbygoogle = window.adsbygoogle || []).push({});

					



(adsbygoogle = window.adsbygoogle || []).push({});

					



(adsbygoogle = window.adsbygoogle || []).push({});

					



(adsbygoogle = window.adsbygoogle || []).push({});

					



(adsbygoogle = window.adsbygoogle || []).push({});

					



(adsbygoogle = window.adsbygoogle || []).push({});

						
							
									
							
									
					
		

								
						
						
					
					
				
				
				
			
			

	        
		
		
	
	

		




		
	
    	
		
							

			
						

			

				
				
	Returning customer? Click here to login



	
	If you have shopped with us before, please enter your details in the boxes below. If you are a new customer, please proceed to the Billing &amp; Shipping section.

	
		Username or email *
		
	
	
		Password *
		
	
	

	
	
				
		
		
			 Remember me		
	
	
		Lost your password?
	

	

	


	Have a coupon? Click here to enter your code



	
		
	

	
		
	

	




	
		
		
			
				
	
		Billing Details

	
	
	
		First Name *
	
		Last Name *
	
		Company Name
	
		Email Address *
	
		Phone *
	
		Country *   India   Country *          Country *                Select a country…Åland IslandsAfghanistanAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntarcticaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelarusBelauBelgiumBelizeBeninBermudaBhutanBoliviaBonaire, Saint Eustatius and SabaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo (Brazzaville)Congo (Kinshasa)Cook IslandsCosta RicaCroatiaCubaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEthiopiaFalkland IslandsFaroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHondurasHong KongHungaryIcelandIndiaIndonesiaIranIraqIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacao S.A.R., ChinaMacedoniaMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesiaMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmarNamibiaNauruNepalNetherlandsNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorth KoreaNorthern Mariana IslandsNorwayOmanPakistanPalestinian TerritoryPanamaPapua New GuineaParaguayPeruPhilippinesPitcairnPolandPortugalPuerto RicoQatarRepublic of IrelandReunionRomaniaRussiaRwandaSão Tomé and PríncipeSaint BarthélemySaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (Dutch part)Saint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia/Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwazilandSwedenSwitzerlandSyriaTaiwanTajikistanTanzaniaThailandTimor-LesteTogoTokelauTongaTrinidad and TobagoTunisiaTurkeyTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited Kingdom (UK)United States (US)United States (US) Minor Outlying IslandsUnited States (US) Virgin IslandsUruguayUzbekistanVanuatuVaticanVenezuelaVietnamWallis and FutunaWestern SaharaYemenZambiaZimbabwe&lt;input type=&quot;submit&quot; name=&quot;woocommerce_checkout_update_totals&quot; value=&quot;Update country&quot; />
	
		Address *
	
		
	
		Town / City *
	
		State / County *   Telangana   State / County *          State / County *                Select an option…Andhra PradeshArunachal PradeshAssamBiharChhattisgarhGoaGujaratHaryanaHimachal PradeshJammu and KashmirJharkhandKarnatakaKeralaMadhya PradeshMaharashtraManipurMeghalayaMizoramNagalandOrissaPunjabRajasthanSikkimTamil NaduTelanganaTripuraUttarakhandUttar PradeshWest BengalAndaman and Nicobar IslandsChandigarhDadar and Nagar HaveliDaman and DiuDelhiLakshadeepPondicherry (Puducherry)Postcode / ZIP *
	
		
	
	
	
		
			
				 Create an account?
			

		
		
		
			

				Create an account by entering the information below. If you are a returning customer please login at the top of the page.

				
					Account password *
				
				

			

		
		
	
			

			
				
	
	
	
		
			Additional Information

		
		
			Order Notes
		
	
	
			
		

		
	
	Your order

	
	
		
	
		
			Product
			Total
		
	
	
							
						
							Android Quick Start Guide 							 × 1													
						
							₹450.00						
					
						
	

		
			Subtotal
			₹450.00
		

		
		
		
														
						Tax
						₹9.00
					
									
		
		
			Total
			₹459.00 
		

		
	



			
			
	

	
		Direct Bank Transfer 	
			
			Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order won’t be shipped until the funds have cleared in our account.
		
	

	

	
		Check Payments 	
			
			Please send a cheque to Store Name, Store Street, Store Town, Store State / County, Store Postcode.
		
	

	

	
		Cash on Delivery 	
			
			Pay with cash upon delivery.
		
	

	

	
		PayPal Express Checkout 	
			
			Pay using either your PayPal account or credit card. All credit card payments will be processed by PayPal.
		
	
		
		
		
			Since your browser does not support JavaScript, or it is disabled, please ensure you click the &lt;em>Update Totals&lt;/em> button before placing your order. You may be charged more than the amount stated above if you fail to do so.			&lt;br/>&lt;input type=&quot;submit&quot; class=&quot;button alt&quot; name=&quot;woocommerce_checkout_update_totals&quot; value=&quot;Update totals&quot; />
		

		
		
		
		
			


	

	





	

				
				
				
								

			
			

			
		
				
			
	
    
	
	





        			
			

							

					
					

						
						
						
							
															
															
							
							

																	
																			
									
																							
						

																					
									
										
		
							
								



		
							
								  
							
							
							
								  
							
							
							
								  
							
							
							
								  
							
							
							
								  
							
											
							
								

Discover moreSaludCienciasDevelopment Tools

(adsbygoogle = window.adsbygoogle || []).push({});

						
							
								

Discover moreHome Storage &amp; ShelvingSoftwareDevelopment Tools

(adsbygoogle = window.adsbygoogle || []).push({});

						
							
					Subscribe Here(function() {
	if (!window.mc4wp) {
		window.mc4wp = {
			listeners: [],
			forms    : {
				on: function (event, callback) {
					window.mc4wp.listeners.push({
						event   : event,
						callback: callback
					});
				}
			}
		}
	}
})();

	



	
				
					
		

											
									
								
								
									
																					© Automation Practice Site 2026											 																			
								
								
													
						
					
					

					
				
				
			
		
		

		
		[{&quot;@context&quot;:&quot;http:\/\/schema.org&quot;,&quot;@type&quot;:&quot;WebPage&quot;,&quot;mainEntityOfPage&quot;:{&quot;@type&quot;:&quot;WebPage&quot;,&quot;@id&quot;:&quot;https:\/\/practice.automationtesting.in\/checkout\/&quot;},&quot;headline&quot;:&quot;Checkout&quot;,&quot;datePublished&quot;:&quot;2017-01-06T08:17:30+00:00&quot;,&quot;dateModified&quot;:&quot;2017-01-06T08:17:30+00:00&quot;,&quot;description&quot;:&quot;&quot;,&quot;commentCount&quot;:&quot;0&quot;}]		
		

(function() {function addEventListener(element,event,handler) {
	if(element.addEventListener) {
		element.addEventListener(event,handler, false);
	} else if(element.attachEvent){
		element.attachEvent(&quot; , &quot;'&quot; , &quot;on&quot; , &quot;'&quot; , &quot;+event,handler);
	}
}function maybePrefixUrlField() {
	if(this.value.trim() !== &quot; , &quot;'&quot; , &quot;&quot; , &quot;'&quot; , &quot; &amp;&amp; this.value.indexOf(&quot; , &quot;'&quot; , &quot;http&quot; , &quot;'&quot; , &quot;) !== 0) {
		this.value = &quot;http://&quot; + this.value;
	}
}

var urlFields = document.querySelectorAll(&quot; , &quot;'&quot; , &quot;.mc4wp-form input[type=&quot;url&quot;]&quot; , &quot;'&quot; , &quot;);
if( urlFields &amp;&amp; urlFields.length > 0 ) {
	for( var j=0; j &lt; urlFields.length; j++ ) {
		addEventListener(urlFields[j],&quot; , &quot;'&quot; , &quot;blur&quot; , &quot;'&quot; , &quot;,maybePrefixUrlField);
	}
}/* test if browser supports date fields */
var testInput = document.createElement(&quot; , &quot;'&quot; , &quot;input&quot; , &quot;'&quot; , &quot;);
testInput.setAttribute(&quot; , &quot;'&quot; , &quot;type&quot; , &quot;'&quot; , &quot;, &quot; , &quot;'&quot; , &quot;date&quot; , &quot;'&quot; , &quot;);
if( testInput.type !== &quot; , &quot;'&quot; , &quot;date&quot; , &quot;'&quot; , &quot;) {

	/* add placeholder &amp; pattern to all date fields */
	var dateFields = document.querySelectorAll(&quot; , &quot;'&quot; , &quot;.mc4wp-form input[type=&quot;date&quot;]&quot; , &quot;'&quot; , &quot;);
	for(var i=0; i&lt;dateFields.length; i++) {
		if(!dateFields[i].placeholder) {
			dateFields[i].placeholder = &quot; , &quot;'&quot; , &quot;YYYY-MM-DD&quot; , &quot;'&quot; , &quot;;
		}
		if(!dateFields[i].pattern) {
			dateFields[i].pattern = &quot; , &quot;'&quot; , &quot;[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])&quot; , &quot;'&quot; , &quot;;
		}
	}
}

})();
/* &lt;![CDATA[ */
var themify_vars = {&quot;version&quot;:&quot;2.8.8&quot;,&quot;url&quot;:&quot;https:\/\/practice.automationtesting.in\/wp-content\/themes\/themify-ultra\/themify&quot;,&quot;TB&quot;:&quot;1&quot;,&quot;map_key&quot;:null};
var tbLocalScript = {&quot;isAnimationActive&quot;:&quot;1&quot;,&quot;isParallaxActive&quot;:&quot;1&quot;,&quot;animationInviewSelectors&quot;:[&quot;.module.wow&quot;,&quot;.themify_builder_content .themify_builder_row.wow&quot;,&quot;.module_row.wow&quot;,&quot;.builder-posts-wrap > .post.wow&quot;,&quot;.fly-in > .post&quot;,&quot;.fly-in .row_inner > .tb-column&quot;,&quot;.fade-in > .post&quot;,&quot;.fade-in .row_inner > .tb-column&quot;,&quot;.slide-up > .post&quot;,&quot;.slide-up .row_inner > .tb-column&quot;],&quot;createAnimationSelectors&quot;:[],&quot;backgroundSlider&quot;:{&quot;autoplay&quot;:5000,&quot;speed&quot;:2000},&quot;animationOffset&quot;:&quot;100&quot;,&quot;videoPoster&quot;:&quot;https:\/\/practice.automationtesting.in\/wp-content\/themes\/themify-ultra\/themify\/themify-builder\/img\/blank.png&quot;,&quot;backgroundVideoLoop&quot;:&quot;yes&quot;,&quot;builder_url&quot;:&quot;https:\/\/practice.automationtesting.in\/wp-content\/themes\/themify-ultra\/themify\/themify-builder&quot;,&quot;framework_url&quot;:&quot;https:\/\/practice.automationtesting.in\/wp-content\/themes\/themify-ultra\/themify&quot;,&quot;version&quot;:&quot;2.8.8&quot;,&quot;fullwidth_support&quot;:&quot;&quot;,&quot;fullwidth_container&quot;:&quot;body&quot;,&quot;loadScrollHighlight&quot;:&quot;1&quot;};
var themifyScript = {&quot;lightbox&quot;:{&quot;lightboxSelector&quot;:&quot;.themify_lightbox&quot;,&quot;lightboxOn&quot;:true,&quot;lightboxContentImages&quot;:false,&quot;lightboxContentImagesSelector&quot;:&quot;.post-content a[href$=jpg],.page-content a[href$=jpg],.post-content a[href$=gif],.page-content a[href$=gif],.post-content a[href$=png],.page-content a[href$=png],.post-content a[href$=JPG],.page-content a[href$=JPG],.post-content a[href$=GIF],.page-content a[href$=GIF],.post-content a[href$=PNG],.page-content a[href$=PNG],.post-content a[href$=jpeg],.page-content a[href$=jpeg],.post-content a[href$=JPEG],.page-content a[href$=JPEG]&quot;,&quot;theme&quot;:&quot;pp_default&quot;,&quot;social_tools&quot;:false,&quot;allow_resize&quot;:true,&quot;show_title&quot;:false,&quot;overlay_gallery&quot;:false,&quot;screenWidthNoLightbox&quot;:600,&quot;deeplinking&quot;:false,&quot;contentImagesAreas&quot;:&quot;.post, .type-page, .type-highlight, .type-slider&quot;,&quot;gallerySelector&quot;:&quot;.gallery-icon > a[href$=jpg],.gallery-icon > a[href$=gif],.gallery-icon > a[href$=png],.gallery-icon > a[href$=JPG],.gallery-icon > a[href$=GIF],.gallery-icon > a[href$=PNG],.gallery-icon > a[href$=jpeg],.gallery-icon > a[href$=JPEG]&quot;,&quot;lightboxGalleryOn&quot;:true},&quot;lightboxContext&quot;:&quot;body&quot;};
var tbScrollHighlight = {&quot;fixedHeaderSelector&quot;:&quot;#headerwrap.fixed-header&quot;,&quot;speed&quot;:&quot;900&quot;,&quot;navigation&quot;:&quot;#main-nav&quot;,&quot;scrollOffset&quot;:&quot;-5&quot;};
/* ]]&gt; */




/* &lt;![CDATA[ */
var _wpcf7 = {&quot;recaptcha&quot;:{&quot;messages&quot;:{&quot;empty&quot;:&quot;Please verify that you are not a robot.&quot;}}};
/* ]]&gt; */



/* &lt;![CDATA[ */
var sb_instagram_js_options = {&quot;sb_instagram_at&quot;:&quot;&quot;};
/* ]]&gt; */



/* &lt;![CDATA[ */
var wc_add_to_cart_params = {&quot;ajax_url&quot;:&quot;\/wp-admin\/admin-ajax.php&quot;,&quot;wc_ajax_url&quot;:&quot;\/checkout\/?wc-ajax=%%endpoint%%&quot;,&quot;i18n_view_cart&quot;:&quot;View Basket&quot;,&quot;cart_url&quot;:&quot;https:\/\/practice.automationtesting.in\/basket\/&quot;,&quot;is_cart&quot;:&quot;&quot;,&quot;cart_redirect_after_add&quot;:&quot;no&quot;};
/* ]]&gt; */









wp.i18n.setLocaleData( { &quot; , &quot;'&quot; , &quot;text direction\u0004ltr&quot; , &quot;'&quot; , &quot;: [ &quot; , &quot;'&quot; , &quot;ltr&quot; , &quot;'&quot; , &quot; ] } );


/* &lt;![CDATA[ */
var pwsL10n = {&quot;unknown&quot;:&quot;Password strength unknown&quot;,&quot;short&quot;:&quot;Very weak&quot;,&quot;bad&quot;:&quot;Weak&quot;,&quot;good&quot;:&quot;Medium&quot;,&quot;strong&quot;:&quot;Strong&quot;,&quot;mismatch&quot;:&quot;Mismatch&quot;};
/* ]]&gt; */


( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[&quot;&quot;].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( &quot;default&quot;, {&quot;translation-revision-date&quot;:&quot;2023-04-19 10:51:23+0000&quot;,&quot;generator&quot;:&quot;GlotPress\/4.0.0-alpha.4&quot;,&quot;domain&quot;:&quot;messages&quot;,&quot;locale_data&quot;:{&quot;messages&quot;:{&quot;&quot;:{&quot;domain&quot;:&quot;messages&quot;,&quot;plural-forms&quot;:&quot;nplurals=2; plural=n != 1;&quot;,&quot;lang&quot;:&quot;en_GB&quot;},&quot;%1$s is deprecated since version %2$s! Use %3$s instead. Please consider writing more inclusive code.&quot;:[&quot;%1$s is deprecated since version %2$s! Use %3$s instead. Please consider writing more inclusive code.&quot;]}},&quot;comment&quot;:{&quot;reference&quot;:&quot;wp-admin\/js\/password-strength-meter.js&quot;}} );



/* &lt;![CDATA[ */
var wc_password_strength_meter_params = {&quot;min_password_strength&quot;:&quot;3&quot;,&quot;i18n_password_error&quot;:&quot;Please enter a stronger password.&quot;,&quot;i18n_password_hint&quot;:&quot;The password should be at least seven characters long. To make it stronger, use upper and lower case letters, numbers and symbols like ! \&quot; ? $ % ^ &amp; ).&quot;};
/* ]]&gt; */




/* &lt;![CDATA[ */
var woocommerce_params = {&quot;ajax_url&quot;:&quot;\/wp-admin\/admin-ajax.php&quot;,&quot;wc_ajax_url&quot;:&quot;\/checkout\/?wc-ajax=%%endpoint%%&quot;};
/* ]]&gt; */



/* &lt;![CDATA[ */
var wc_country_select_params = {&quot;countries&quot;:&quot;{\&quot;AF\&quot;:[],\&quot;AT\&quot;:[],\&quot;AX\&quot;:[],\&quot;BE\&quot;:[],\&quot;BI\&quot;:[],\&quot;CZ\&quot;:[],\&quot;DE\&quot;:[],\&quot;DK\&quot;:[],\&quot;EE\&quot;:[],\&quot;FI\&quot;:[],\&quot;FR\&quot;:[],\&quot;IS\&quot;:[],\&quot;IL\&quot;:[],\&quot;KR\&quot;:[],\&quot;NL\&quot;:[],\&quot;NO\&quot;:[],\&quot;PL\&quot;:[],\&quot;PT\&quot;:[],\&quot;SG\&quot;:[],\&quot;SK\&quot;:[],\&quot;SI\&quot;:[],\&quot;LK\&quot;:[],\&quot;SE\&quot;:[],\&quot;VN\&quot;:[],\&quot;AR\&quot;:{\&quot;C\&quot;:\&quot;Ciudad Aut\u00f3noma de Buenos Aires\&quot;,\&quot;B\&quot;:\&quot;Buenos Aires\&quot;,\&quot;K\&quot;:\&quot;Catamarca\&quot;,\&quot;H\&quot;:\&quot;Chaco\&quot;,\&quot;U\&quot;:\&quot;Chubut\&quot;,\&quot;X\&quot;:\&quot;C\u00f3rdoba\&quot;,\&quot;W\&quot;:\&quot;Corrientes\&quot;,\&quot;E\&quot;:\&quot;Entre R\u00edos\&quot;,\&quot;P\&quot;:\&quot;Formosa\&quot;,\&quot;Y\&quot;:\&quot;Jujuy\&quot;,\&quot;L\&quot;:\&quot;La Pampa\&quot;,\&quot;F\&quot;:\&quot;La Rioja\&quot;,\&quot;M\&quot;:\&quot;Mendoza\&quot;,\&quot;N\&quot;:\&quot;Misiones\&quot;,\&quot;Q\&quot;:\&quot;Neuqu\u00e9n\&quot;,\&quot;R\&quot;:\&quot;R\u00edo Negro\&quot;,\&quot;A\&quot;:\&quot;Salta\&quot;,\&quot;J\&quot;:\&quot;San Juan\&quot;,\&quot;D\&quot;:\&quot;San Luis\&quot;,\&quot;Z\&quot;:\&quot;Santa Cruz\&quot;,\&quot;S\&quot;:\&quot;Santa Fe\&quot;,\&quot;G\&quot;:\&quot;Santiago del Estero\&quot;,\&quot;V\&quot;:\&quot;Tierra del Fuego\&quot;,\&quot;T\&quot;:\&quot;Tucum\u00e1n\&quot;},\&quot;AU\&quot;:{\&quot;ACT\&quot;:\&quot;Australian Capital Territory\&quot;,\&quot;NSW\&quot;:\&quot;New South Wales\&quot;,\&quot;NT\&quot;:\&quot;Northern Territory\&quot;,\&quot;QLD\&quot;:\&quot;Queensland\&quot;,\&quot;SA\&quot;:\&quot;South Australia\&quot;,\&quot;TAS\&quot;:\&quot;Tasmania\&quot;,\&quot;VIC\&quot;:\&quot;Victoria\&quot;,\&quot;WA\&quot;:\&quot;Western Australia\&quot;},\&quot;BD\&quot;:{\&quot;BAG\&quot;:\&quot;Bagerhat\&quot;,\&quot;BAN\&quot;:\&quot;Bandarban\&quot;,\&quot;BAR\&quot;:\&quot;Barguna\&quot;,\&quot;BARI\&quot;:\&quot;Barisal\&quot;,\&quot;BHO\&quot;:\&quot;Bhola\&quot;,\&quot;BOG\&quot;:\&quot;Bogra\&quot;,\&quot;BRA\&quot;:\&quot;Brahmanbaria\&quot;,\&quot;CHA\&quot;:\&quot;Chandpur\&quot;,\&quot;CHI\&quot;:\&quot;Chittagong\&quot;,\&quot;CHU\&quot;:\&quot;Chuadanga\&quot;,\&quot;COM\&quot;:\&quot;Comilla\&quot;,\&quot;COX\&quot;:\&quot;Cox&quot; , &quot;'&quot; , &quot;s Bazar\&quot;,\&quot;DHA\&quot;:\&quot;Dhaka\&quot;,\&quot;DIN\&quot;:\&quot;Dinajpur\&quot;,\&quot;FAR\&quot;:\&quot;Faridpur \&quot;,\&quot;FEN\&quot;:\&quot;Feni\&quot;,\&quot;GAI\&quot;:\&quot;Gaibandha\&quot;,\&quot;GAZI\&quot;:\&quot;Gazipur\&quot;,\&quot;GOP\&quot;:\&quot;Gopalganj\&quot;,\&quot;HAB\&quot;:\&quot;Habiganj\&quot;,\&quot;JAM\&quot;:\&quot;Jamalpur\&quot;,\&quot;JES\&quot;:\&quot;Jessore\&quot;,\&quot;JHA\&quot;:\&quot;Jhalokati\&quot;,\&quot;JHE\&quot;:\&quot;Jhenaidah\&quot;,\&quot;JOY\&quot;:\&quot;Joypurhat\&quot;,\&quot;KHA\&quot;:\&quot;Khagrachhari\&quot;,\&quot;KHU\&quot;:\&quot;Khulna\&quot;,\&quot;KIS\&quot;:\&quot;Kishoreganj\&quot;,\&quot;KUR\&quot;:\&quot;Kurigram\&quot;,\&quot;KUS\&quot;:\&quot;Kushtia\&quot;,\&quot;LAK\&quot;:\&quot;Lakshmipur\&quot;,\&quot;LAL\&quot;:\&quot;Lalmonirhat\&quot;,\&quot;MAD\&quot;:\&quot;Madaripur\&quot;,\&quot;MAG\&quot;:\&quot;Magura\&quot;,\&quot;MAN\&quot;:\&quot;Manikganj \&quot;,\&quot;MEH\&quot;:\&quot;Meherpur\&quot;,\&quot;MOU\&quot;:\&quot;Moulvibazar\&quot;,\&quot;MUN\&quot;:\&quot;Munshiganj\&quot;,\&quot;MYM\&quot;:\&quot;Mymensingh\&quot;,\&quot;NAO\&quot;:\&quot;Naogaon\&quot;,\&quot;NAR\&quot;:\&quot;Narail\&quot;,\&quot;NARG\&quot;:\&quot;Narayanganj\&quot;,\&quot;NARD\&quot;:\&quot;Narsingdi\&quot;,\&quot;NAT\&quot;:\&quot;Natore\&quot;,\&quot;NAW\&quot;:\&quot;Nawabganj\&quot;,\&quot;NET\&quot;:\&quot;Netrakona\&quot;,\&quot;NIL\&quot;:\&quot;Nilphamari\&quot;,\&quot;NOA\&quot;:\&quot;Noakhali\&quot;,\&quot;PAB\&quot;:\&quot;Pabna\&quot;,\&quot;PAN\&quot;:\&quot;Panchagarh\&quot;,\&quot;PAT\&quot;:\&quot;Patuakhali\&quot;,\&quot;PIR\&quot;:\&quot;Pirojpur\&quot;,\&quot;RAJB\&quot;:\&quot;Rajbari\&quot;,\&quot;RAJ\&quot;:\&quot;Rajshahi\&quot;,\&quot;RAN\&quot;:\&quot;Rangamati\&quot;,\&quot;RANP\&quot;:\&quot;Rangpur\&quot;,\&quot;SAT\&quot;:\&quot;Satkhira\&quot;,\&quot;SHA\&quot;:\&quot;Shariatpur\&quot;,\&quot;SHE\&quot;:\&quot;Sherpur\&quot;,\&quot;SIR\&quot;:\&quot;Sirajganj\&quot;,\&quot;SUN\&quot;:\&quot;Sunamganj\&quot;,\&quot;SYL\&quot;:\&quot;Sylhet\&quot;,\&quot;TAN\&quot;:\&quot;Tangail\&quot;,\&quot;THA\&quot;:\&quot;Thakurgaon\&quot;},\&quot;BR\&quot;:{\&quot;AC\&quot;:\&quot;Acre\&quot;,\&quot;AL\&quot;:\&quot;Alagoas\&quot;,\&quot;AP\&quot;:\&quot;Amap\u00e1\&quot;,\&quot;AM\&quot;:\&quot;Amazonas\&quot;,\&quot;BA\&quot;:\&quot;Bahia\&quot;,\&quot;CE\&quot;:\&quot;Cear\u00e1\&quot;,\&quot;DF\&quot;:\&quot;Distrito Federal\&quot;,\&quot;ES\&quot;:\&quot;Esp\u00edrito Santo\&quot;,\&quot;GO\&quot;:\&quot;Goi\u00e1s\&quot;,\&quot;MA\&quot;:\&quot;Maranh\u00e3o\&quot;,\&quot;MT\&quot;:\&quot;Mato Grosso\&quot;,\&quot;MS\&quot;:\&quot;Mato Grosso do Sul\&quot;,\&quot;MG\&quot;:\&quot;Minas Gerais\&quot;,\&quot;PA\&quot;:\&quot;Par\u00e1\&quot;,\&quot;PB\&quot;:\&quot;Para\u00edba\&quot;,\&quot;PR\&quot;:\&quot;Paran\u00e1\&quot;,\&quot;PE\&quot;:\&quot;Pernambuco\&quot;,\&quot;PI\&quot;:\&quot;Piau\u00ed\&quot;,\&quot;RJ\&quot;:\&quot;Rio de Janeiro\&quot;,\&quot;RN\&quot;:\&quot;Rio Grande do Norte\&quot;,\&quot;RS\&quot;:\&quot;Rio Grande do Sul\&quot;,\&quot;RO\&quot;:\&quot;Rond\u00f4nia\&quot;,\&quot;RR\&quot;:\&quot;Roraima\&quot;,\&quot;SC\&quot;:\&quot;Santa Catarina\&quot;,\&quot;SP\&quot;:\&quot;S\u00e3o Paulo\&quot;,\&quot;SE\&quot;:\&quot;Sergipe\&quot;,\&quot;TO\&quot;:\&quot;Tocantins\&quot;},\&quot;BG\&quot;:{\&quot;BG-01\&quot;:\&quot;Blagoevgrad\&quot;,\&quot;BG-02\&quot;:\&quot;Burgas\&quot;,\&quot;BG-08\&quot;:\&quot;Dobrich\&quot;,\&quot;BG-07\&quot;:\&quot;Gabrovo\&quot;,\&quot;BG-26\&quot;:\&quot;Haskovo\&quot;,\&quot;BG-09\&quot;:\&quot;Kardzhali\&quot;,\&quot;BG-10\&quot;:\&quot;Kyustendil\&quot;,\&quot;BG-11\&quot;:\&quot;Lovech\&quot;,\&quot;BG-12\&quot;:\&quot;Montana\&quot;,\&quot;BG-13\&quot;:\&quot;Pazardzhik\&quot;,\&quot;BG-14\&quot;:\&quot;Pernik\&quot;,\&quot;BG-15\&quot;:\&quot;Pleven\&quot;,\&quot;BG-16\&quot;:\&quot;Plovdiv\&quot;,\&quot;BG-17\&quot;:\&quot;Razgrad\&quot;,\&quot;BG-18\&quot;:\&quot;Ruse\&quot;,\&quot;BG-27\&quot;:\&quot;Shumen\&quot;,\&quot;BG-19\&quot;:\&quot;Silistra\&quot;,\&quot;BG-20\&quot;:\&quot;Sliven\&quot;,\&quot;BG-21\&quot;:\&quot;Smolyan\&quot;,\&quot;BG-23\&quot;:\&quot;Sofia\&quot;,\&quot;BG-22\&quot;:\&quot;Sofia-Grad\&quot;,\&quot;BG-24\&quot;:\&quot;Stara Zagora\&quot;,\&quot;BG-25\&quot;:\&quot;Targovishte\&quot;,\&quot;BG-03\&quot;:\&quot;Varna\&quot;,\&quot;BG-04\&quot;:\&quot;Veliko Tarnovo\&quot;,\&quot;BG-05\&quot;:\&quot;Vidin\&quot;,\&quot;BG-06\&quot;:\&quot;Vratsa\&quot;,\&quot;BG-28\&quot;:\&quot;Yambol\&quot;},\&quot;CA\&quot;:{\&quot;AB\&quot;:\&quot;Alberta\&quot;,\&quot;BC\&quot;:\&quot;British Columbia\&quot;,\&quot;MB\&quot;:\&quot;Manitoba\&quot;,\&quot;NB\&quot;:\&quot;New Brunswick\&quot;,\&quot;NL\&quot;:\&quot;Newfoundland and Labrador\&quot;,\&quot;NT\&quot;:\&quot;Northwest Territories\&quot;,\&quot;NS\&quot;:\&quot;Nova Scotia\&quot;,\&quot;NU\&quot;:\&quot;Nunavut\&quot;,\&quot;ON\&quot;:\&quot;Ontario\&quot;,\&quot;PE\&quot;:\&quot;Prince Edward Island\&quot;,\&quot;QC\&quot;:\&quot;Quebec\&quot;,\&quot;SK\&quot;:\&quot;Saskatchewan\&quot;,\&quot;YT\&quot;:\&quot;Yukon Territory\&quot;},\&quot;CN\&quot;:{\&quot;CN1\&quot;:\&quot;Yunnan \\\/ \u4e91\u5357\&quot;,\&quot;CN2\&quot;:\&quot;Beijing \\\/ \u5317\u4eac\&quot;,\&quot;CN3\&quot;:\&quot;Tianjin \\\/ \u5929\u6d25\&quot;,\&quot;CN4\&quot;:\&quot;Hebei \\\/ \u6cb3\u5317\&quot;,\&quot;CN5\&quot;:\&quot;Shanxi \\\/ \u5c71\u897f\&quot;,\&quot;CN6\&quot;:\&quot;Inner Mongolia \\\/ \u5167\u8499\u53e4\&quot;,\&quot;CN7\&quot;:\&quot;Liaoning \\\/ \u8fbd\u5b81\&quot;,\&quot;CN8\&quot;:\&quot;Jilin \\\/ \u5409\u6797\&quot;,\&quot;CN9\&quot;:\&quot;Heilongjiang \\\/ \u9ed1\u9f99\u6c5f\&quot;,\&quot;CN10\&quot;:\&quot;Shanghai \\\/ \u4e0a\u6d77\&quot;,\&quot;CN11\&quot;:\&quot;Jiangsu \\\/ \u6c5f\u82cf\&quot;,\&quot;CN12\&quot;:\&quot;Zhejiang \\\/ \u6d59\u6c5f\&quot;,\&quot;CN13\&quot;:\&quot;Anhui \\\/ \u5b89\u5fbd\&quot;,\&quot;CN14\&quot;:\&quot;Fujian \\\/ \u798f\u5efa\&quot;,\&quot;CN15\&quot;:\&quot;Jiangxi \\\/ \u6c5f\u897f\&quot;,\&quot;CN16\&quot;:\&quot;Shandong \\\/ \u5c71\u4e1c\&quot;,\&quot;CN17\&quot;:\&quot;Henan \\\/ \u6cb3\u5357\&quot;,\&quot;CN18\&quot;:\&quot;Hubei \\\/ \u6e56\u5317\&quot;,\&quot;CN19\&quot;:\&quot;Hunan \\\/ \u6e56\u5357\&quot;,\&quot;CN20\&quot;:\&quot;Guangdong \\\/ \u5e7f\u4e1c\&quot;,\&quot;CN21\&quot;:\&quot;Guangxi Zhuang \\\/ \u5e7f\u897f\u58ee\u65cf\&quot;,\&quot;CN22\&quot;:\&quot;Hainan \\\/ \u6d77\u5357\&quot;,\&quot;CN23\&quot;:\&quot;Chongqing \\\/ \u91cd\u5e86\&quot;,\&quot;CN24\&quot;:\&quot;Sichuan \\\/ \u56db\u5ddd\&quot;,\&quot;CN25\&quot;:\&quot;Guizhou \\\/ \u8d35\u5dde\&quot;,\&quot;CN26\&quot;:\&quot;Shaanxi \\\/ \u9655\u897f\&quot;,\&quot;CN27\&quot;:\&quot;Gansu \\\/ \u7518\u8083\&quot;,\&quot;CN28\&quot;:\&quot;Qinghai \\\/ \u9752\u6d77\&quot;,\&quot;CN29\&quot;:\&quot;Ningxia Hui \\\/ \u5b81\u590f\&quot;,\&quot;CN30\&quot;:\&quot;Macau \\\/ \u6fb3\u95e8\&quot;,\&quot;CN31\&quot;:\&quot;Tibet \\\/ \u897f\u85cf\&quot;,\&quot;CN32\&quot;:\&quot;Xinjiang \\\/ \u65b0\u7586\&quot;},\&quot;GR\&quot;:{\&quot;I\&quot;:\&quot;\\u0391\\u03c4\\u03c4\\u03b9\\u03ba\\u03ae\&quot;,\&quot;A\&quot;:\&quot;\\u0391\\u03bd\\u03b1\\u03c4\\u03bf\\u03bb\\u03b9\\u03ba\\u03ae \\u039c\\u03b1\\u03ba\\u03b5\\u03b4\\u03bf\\u03bd\\u03af\\u03b1 \\u03ba\\u03b1\\u03b9 \\u0398\\u03c1\\u03ac\\u03ba\\u03b7\&quot;,\&quot;B\&quot;:\&quot;\\u039a\\u03b5\\u03bd\\u03c4\\u03c1\\u03b9\\u03ba\\u03ae \\u039c\\u03b1\\u03ba\\u03b5\\u03b4\\u03bf\\u03bd\\u03af\\u03b1\&quot;,\&quot;C\&quot;:\&quot;\\u0394\\u03c5\\u03c4\\u03b9\\u03ba\\u03ae \\u039c\\u03b1\\u03ba\\u03b5\\u03b4\\u03bf\\u03bd\\u03af\\u03b1\&quot;,\&quot;D\&quot;:\&quot;\\u0389\\u03c0\\u03b5\\u03b9\\u03c1\\u03bf\\u03c2\&quot;,\&quot;E\&quot;:\&quot;\\u0398\\u03b5\\u03c3\\u03c3\\u03b1\\u03bb\\u03af\\u03b1\&quot;,\&quot;F\&quot;:\&quot;\\u0399\\u03cc\\u03bd\\u03b9\\u03bf\\u03b9 \\u039d\\u03ae\\u03c3\\u03bf\\u03b9\&quot;,\&quot;G\&quot;:\&quot;\\u0394\\u03c5\\u03c4\\u03b9\\u03ba\\u03ae \\u0395\\u03bb\\u03bb\\u03ac\\u03b4\\u03b1\&quot;,\&quot;H\&quot;:\&quot;\\u03a3\\u03c4\\u03b5\\u03c1\\u03b5\\u03ac \\u0395\\u03bb\\u03bb\\u03ac\\u03b4\\u03b1\&quot;,\&quot;J\&quot;:\&quot;\\u03a0\\u03b5\\u03bb\\u03bf\\u03c0\\u03cc\\u03bd\\u03bd\\u03b7\\u03c3\\u03bf\\u03c2\&quot;,\&quot;K\&quot;:\&quot;\\u0392\\u03cc\\u03c1\\u03b5\\u03b9\\u03bf \\u0391\\u03b9\\u03b3\\u03b1\\u03af\\u03bf\&quot;,\&quot;L\&quot;:\&quot;\\u039d\\u03cc\\u03c4\\u03b9\\u03bf \\u0391\\u03b9\\u03b3\\u03b1\\u03af\\u03bf\&quot;,\&quot;M\&quot;:\&quot;\\u039a\\u03c1\\u03ae\\u03c4\\u03b7\&quot;},\&quot;HK\&quot;:{\&quot;HONG KONG\&quot;:\&quot;Hong Kong Island\&quot;,\&quot;KOWLOON\&quot;:\&quot;Kowloon\&quot;,\&quot;NEW TERRITORIES\&quot;:\&quot;New Territories\&quot;},\&quot;HU\&quot;:{\&quot;BK\&quot;:\&quot;B\\u00e1cs-Kiskun\&quot;,\&quot;BE\&quot;:\&quot;B\\u00e9k\\u00e9s\&quot;,\&quot;BA\&quot;:\&quot;Baranya\&quot;,\&quot;BZ\&quot;:\&quot;Borsod-Aba\\u00faj-Zempl\\u00e9n\&quot;,\&quot;BU\&quot;:\&quot;Budapest\&quot;,\&quot;CS\&quot;:\&quot;Csongr\\u00e1d\&quot;,\&quot;FE\&quot;:\&quot;Fej\\u00e9r\&quot;,\&quot;GS\&quot;:\&quot;Gy\\u0151r-Moson-Sopron\&quot;,\&quot;HB\&quot;:\&quot;Hajd\\u00fa-Bihar\&quot;,\&quot;HE\&quot;:\&quot;Heves\&quot;,\&quot;JN\&quot;:\&quot;J\\u00e1sz-Nagykun-Szolnok\&quot;,\&quot;KE\&quot;:\&quot;Kom\\u00e1rom-Esztergom\&quot;,\&quot;NO\&quot;:\&quot;N\\u00f3gr\\u00e1d\&quot;,\&quot;PE\&quot;:\&quot;Pest\&quot;,\&quot;SO\&quot;:\&quot;Somogy\&quot;,\&quot;SZ\&quot;:\&quot;Szabolcs-Szatm\\u00e1r-Bereg\&quot;,\&quot;TO\&quot;:\&quot;Tolna\&quot;,\&quot;VA\&quot;:\&quot;Vas\&quot;,\&quot;VE\&quot;:\&quot;Veszpr\\u00e9m\&quot;,\&quot;ZA\&quot;:\&quot;Zala\&quot;},\&quot;IN\&quot;:{\&quot;AP\&quot;:\&quot;Andhra Pradesh\&quot;,\&quot;AR\&quot;:\&quot;Arunachal Pradesh\&quot;,\&quot;AS\&quot;:\&quot;Assam\&quot;,\&quot;BR\&quot;:\&quot;Bihar\&quot;,\&quot;CT\&quot;:\&quot;Chhattisgarh\&quot;,\&quot;GA\&quot;:\&quot;Goa\&quot;,\&quot;GJ\&quot;:\&quot;Gujarat\&quot;,\&quot;HR\&quot;:\&quot;Haryana\&quot;,\&quot;HP\&quot;:\&quot;Himachal Pradesh\&quot;,\&quot;JK\&quot;:\&quot;Jammu and Kashmir\&quot;,\&quot;JH\&quot;:\&quot;Jharkhand\&quot;,\&quot;KA\&quot;:\&quot;Karnataka\&quot;,\&quot;KL\&quot;:\&quot;Kerala\&quot;,\&quot;MP\&quot;:\&quot;Madhya Pradesh\&quot;,\&quot;MH\&quot;:\&quot;Maharashtra\&quot;,\&quot;MN\&quot;:\&quot;Manipur\&quot;,\&quot;ML\&quot;:\&quot;Meghalaya\&quot;,\&quot;MZ\&quot;:\&quot;Mizoram\&quot;,\&quot;NL\&quot;:\&quot;Nagaland\&quot;,\&quot;OR\&quot;:\&quot;Orissa\&quot;,\&quot;PB\&quot;:\&quot;Punjab\&quot;,\&quot;RJ\&quot;:\&quot;Rajasthan\&quot;,\&quot;SK\&quot;:\&quot;Sikkim\&quot;,\&quot;TN\&quot;:\&quot;Tamil Nadu\&quot;,\&quot;TS\&quot;:\&quot;Telangana\&quot;,\&quot;TR\&quot;:\&quot;Tripura\&quot;,\&quot;UK\&quot;:\&quot;Uttarakhand\&quot;,\&quot;UP\&quot;:\&quot;Uttar Pradesh\&quot;,\&quot;WB\&quot;:\&quot;West Bengal\&quot;,\&quot;AN\&quot;:\&quot;Andaman and Nicobar Islands\&quot;,\&quot;CH\&quot;:\&quot;Chandigarh\&quot;,\&quot;DN\&quot;:\&quot;Dadar and Nagar Haveli\&quot;,\&quot;DD\&quot;:\&quot;Daman and Diu\&quot;,\&quot;DL\&quot;:\&quot;Delhi\&quot;,\&quot;LD\&quot;:\&quot;Lakshadeep\&quot;,\&quot;PY\&quot;:\&quot;Pondicherry (Puducherry)\&quot;},\&quot;ID\&quot;:{\&quot;AC\&quot;:\&quot;Daerah Istimewa Aceh\&quot;,\&quot;SU\&quot;:\&quot;Sumatera Utara\&quot;,\&quot;SB\&quot;:\&quot;Sumatera Barat\&quot;,\&quot;RI\&quot;:\&quot;Riau\&quot;,\&quot;KR\&quot;:\&quot;Kepulauan Riau\&quot;,\&quot;JA\&quot;:\&quot;Jambi\&quot;,\&quot;SS\&quot;:\&quot;Sumatera Selatan\&quot;,\&quot;BB\&quot;:\&quot;Bangka Belitung\&quot;,\&quot;BE\&quot;:\&quot;Bengkulu\&quot;,\&quot;LA\&quot;:\&quot;Lampung\&quot;,\&quot;JK\&quot;:\&quot;DKI Jakarta\&quot;,\&quot;JB\&quot;:\&quot;Jawa Barat\&quot;,\&quot;BT\&quot;:\&quot;Banten\&quot;,\&quot;JT\&quot;:\&quot;Jawa Tengah\&quot;,\&quot;JI\&quot;:\&quot;Jawa Timur\&quot;,\&quot;YO\&quot;:\&quot;Daerah Istimewa Yogyakarta\&quot;,\&quot;BA\&quot;:\&quot;Bali\&quot;,\&quot;NB\&quot;:\&quot;Nusa Tenggara Barat\&quot;,\&quot;NT\&quot;:\&quot;Nusa Tenggara Timur\&quot;,\&quot;KB\&quot;:\&quot;Kalimantan Barat\&quot;,\&quot;KT\&quot;:\&quot;Kalimantan Tengah\&quot;,\&quot;KI\&quot;:\&quot;Kalimantan Timur\&quot;,\&quot;KS\&quot;:\&quot;Kalimantan Selatan\&quot;,\&quot;KU\&quot;:\&quot;Kalimantan Utara\&quot;,\&quot;SA\&quot;:\&quot;Sulawesi Utara\&quot;,\&quot;ST\&quot;:\&quot;Sulawesi Tengah\&quot;,\&quot;SG\&quot;:\&quot;Sulawesi Tenggara\&quot;,\&quot;SR\&quot;:\&quot;Sulawesi Barat\&quot;,\&quot;SN\&quot;:\&quot;Sulawesi Selatan\&quot;,\&quot;GO\&quot;:\&quot;Gorontalo\&quot;,\&quot;MA\&quot;:\&quot;Maluku\&quot;,\&quot;MU\&quot;:\&quot;Maluku Utara\&quot;,\&quot;PA\&quot;:\&quot;Papua\&quot;,\&quot;PB\&quot;:\&quot;Papua Barat\&quot;},\&quot;IR\&quot;:{\&quot;KHZ\&quot;:\&quot;Khuzestan  (\\u062e\\u0648\\u0632\\u0633\\u062a\\u0627\\u0646)\&quot;,\&quot;THR\&quot;:\&quot;Tehran  (\\u062a\\u0647\\u0631\\u0627\\u0646)\&quot;,\&quot;ILM\&quot;:\&quot;Ilaam (\\u0627\\u06cc\\u0644\\u0627\\u0645)\&quot;,\&quot;BHR\&quot;:\&quot;Bushehr (\\u0628\\u0648\\u0634\\u0647\\u0631)\&quot;,\&quot;ADL\&quot;:\&quot;Ardabil (\\u0627\\u0631\\u062f\\u0628\\u06cc\\u0644)\&quot;,\&quot;ESF\&quot;:\&quot;Isfahan (\\u0627\\u0635\\u0641\\u0647\\u0627\\u0646)\&quot;,\&quot;YZD\&quot;:\&quot;Yazd (\\u06cc\\u0632\\u062f)\&quot;,\&quot;KRH\&quot;:\&quot;Kermanshah (\\u06a9\\u0631\\u0645\\u0627\\u0646\\u0634\\u0627\\u0647)\&quot;,\&quot;KRN\&quot;:\&quot;Kerman (\\u06a9\\u0631\\u0645\\u0627\\u0646)\&quot;,\&quot;HDN\&quot;:\&quot;Hamadan (\\u0647\\u0645\\u062f\\u0627\\u0646)\&quot;,\&quot;GZN\&quot;:\&quot;Qazvin (\\u0642\\u0632\\u0648\\u06cc\\u0646)\&quot;,\&quot;ZJN\&quot;:\&quot;Zanjan (\\u0632\\u0646\\u062c\\u0627\\u0646)\&quot;,\&quot;LRS\&quot;:\&quot;Luristan (\\u0644\\u0631\\u0633\\u062a\\u0627\\u0646)\&quot;,\&quot;ABZ\&quot;:\&quot;Alborz (\\u0627\\u0644\\u0628\\u0631\\u0632)\&quot;,\&quot;EAZ\&quot;:\&quot;East Azarbaijan (\\u0622\\u0630\\u0631\\u0628\\u0627\\u06cc\\u062c\\u0627\\u0646 \\u0634\\u0631\\u0642\\u06cc)\&quot;,\&quot;WAZ\&quot;:\&quot;West Azarbaijan (\\u0622\\u0630\\u0631\\u0628\\u0627\\u06cc\\u062c\\u0627\\u0646 \\u063a\\u0631\\u0628\\u06cc)\&quot;,\&quot;CHB\&quot;:\&quot;Chaharmahal and Bakhtiari (\\u0686\\u0647\\u0627\\u0631\\u0645\\u062d\\u0627\\u0644 \\u0648 \\u0628\\u062e\\u062a\\u06cc\\u0627\\u0631\\u06cc)\&quot;,\&quot;SKH\&quot;:\&quot;South Khorasan (\\u062e\\u0631\\u0627\\u0633\\u0627\\u0646 \\u062c\\u0646\\u0648\\u0628\\u06cc)\&quot;,\&quot;RKH\&quot;:\&quot;Razavi Khorasan (\\u062e\\u0631\\u0627\\u0633\\u0627\\u0646 \\u0631\\u0636\\u0648\\u06cc)\&quot;,\&quot;NKH\&quot;:\&quot;North Khorasan (\\u062e\\u0631\\u0627\\u0633\\u0627\\u0646 \\u062c\\u0646\\u0648\\u0628\\u06cc)\&quot;,\&quot;SMN\&quot;:\&quot;Semnan (\\u0633\\u0645\\u0646\\u0627\\u0646)\&quot;,\&quot;FRS\&quot;:\&quot;Fars (\\u0641\\u0627\\u0631\\u0633)\&quot;,\&quot;QHM\&quot;:\&quot;Qom (\\u0642\\u0645)\&quot;,\&quot;KRD\&quot;:\&quot;Kurdistan (\\u06a9\\u0631\\u062f\\u0633\\u062a\\u0627\\u0646)\&quot;,\&quot;KBD\&quot;:\&quot;Kohgiluyeh and BoyerAhmad (\\u06a9\\u0647\\u06af\\u06cc\\u0644\\u0648\\u06cc\\u06cc\\u0647 \\u0648 \\u0628\\u0648\\u06cc\\u0631\\u0627\\u062d\\u0645\\u062f)\&quot;,\&quot;GLS\&quot;:\&quot;Golestan (\\u06af\\u0644\\u0633\\u062a\\u0627\\u0646)\&quot;,\&quot;GIL\&quot;:\&quot;Gilan (\\u06af\\u06cc\\u0644\\u0627\\u0646)\&quot;,\&quot;MZN\&quot;:\&quot;Mazandaran (\\u0645\\u0627\\u0632\\u0646\\u062f\\u0631\\u0627\\u0646)\&quot;,\&quot;MKZ\&quot;:\&quot;Markazi (\\u0645\\u0631\\u06a9\\u0632\\u06cc)\&quot;,\&quot;HRZ\&quot;:\&quot;Hormozgan (\\u0647\\u0631\\u0645\\u0632\\u06af\\u0627\\u0646)\&quot;,\&quot;SBN\&quot;:\&quot;Sistan and Baluchestan (\\u0633\\u06cc\\u0633\\u062a\\u0627\\u0646 \\u0648 \\u0628\\u0644\\u0648\\u0686\\u0633\\u062a\\u0627\\u0646)\&quot;},\&quot;IT\&quot;:{\&quot;AG\&quot;:\&quot;Agrigento\&quot;,\&quot;AL\&quot;:\&quot;Alessandria\&quot;,\&quot;AN\&quot;:\&quot;Ancona\&quot;,\&quot;AO\&quot;:\&quot;Aosta\&quot;,\&quot;AR\&quot;:\&quot;Arezzo\&quot;,\&quot;AP\&quot;:\&quot;Ascoli Piceno\&quot;,\&quot;AT\&quot;:\&quot;Asti\&quot;,\&quot;AV\&quot;:\&quot;Avellino\&quot;,\&quot;BA\&quot;:\&quot;Bari\&quot;,\&quot;BT\&quot;:\&quot;Barletta-Andria-Trani\&quot;,\&quot;BL\&quot;:\&quot;Belluno\&quot;,\&quot;BN\&quot;:\&quot;Benevento\&quot;,\&quot;BG\&quot;:\&quot;Bergamo\&quot;,\&quot;BI\&quot;:\&quot;Biella\&quot;,\&quot;BO\&quot;:\&quot;Bologna\&quot;,\&quot;BZ\&quot;:\&quot;Bolzano\&quot;,\&quot;BS\&quot;:\&quot;Brescia\&quot;,\&quot;BR\&quot;:\&quot;Brindisi\&quot;,\&quot;CA\&quot;:\&quot;Cagliari\&quot;,\&quot;CL\&quot;:\&quot;Caltanissetta\&quot;,\&quot;CB\&quot;:\&quot;Campobasso\&quot;,\&quot;CI\&quot;:\&quot;Carbonia-Iglesias\&quot;,\&quot;CE\&quot;:\&quot;Caserta\&quot;,\&quot;CT\&quot;:\&quot;Catania\&quot;,\&quot;CZ\&quot;:\&quot;Catanzaro\&quot;,\&quot;CH\&quot;:\&quot;Chieti\&quot;,\&quot;CO\&quot;:\&quot;Como\&quot;,\&quot;CS\&quot;:\&quot;Cosenza\&quot;,\&quot;CR\&quot;:\&quot;Cremona\&quot;,\&quot;KR\&quot;:\&quot;Crotone\&quot;,\&quot;CN\&quot;:\&quot;Cuneo\&quot;,\&quot;EN\&quot;:\&quot;Enna\&quot;,\&quot;FM\&quot;:\&quot;Fermo\&quot;,\&quot;FE\&quot;:\&quot;Ferrara\&quot;,\&quot;FI\&quot;:\&quot;Firenze\&quot;,\&quot;FG\&quot;:\&quot;Foggia\&quot;,\&quot;FC\&quot;:\&quot;Forl\\u00ec-Cesena\&quot;,\&quot;FR\&quot;:\&quot;Frosinone\&quot;,\&quot;GE\&quot;:\&quot;Genova\&quot;,\&quot;GO\&quot;:\&quot;Gorizia\&quot;,\&quot;GR\&quot;:\&quot;Grosseto\&quot;,\&quot;IM\&quot;:\&quot;Imperia\&quot;,\&quot;IS\&quot;:\&quot;Isernia\&quot;,\&quot;SP\&quot;:\&quot;La Spezia\&quot;,\&quot;AQ\&quot;:\&quot;L&amp;apos;Aquila\&quot;,\&quot;LT\&quot;:\&quot;Latina\&quot;,\&quot;LE\&quot;:\&quot;Lecce\&quot;,\&quot;LC\&quot;:\&quot;Lecco\&quot;,\&quot;LI\&quot;:\&quot;Livorno\&quot;,\&quot;LO\&quot;:\&quot;Lodi\&quot;,\&quot;LU\&quot;:\&quot;Lucca\&quot;,\&quot;MC\&quot;:\&quot;Macerata\&quot;,\&quot;MN\&quot;:\&quot;Mantova\&quot;,\&quot;MS\&quot;:\&quot;Massa-Carrara\&quot;,\&quot;MT\&quot;:\&quot;Matera\&quot;,\&quot;ME\&quot;:\&quot;Messina\&quot;,\&quot;MI\&quot;:\&quot;Milano\&quot;,\&quot;MO\&quot;:\&quot;Modena\&quot;,\&quot;MB\&quot;:\&quot;Monza e della Brianza\&quot;,\&quot;NA\&quot;:\&quot;Napoli\&quot;,\&quot;NO\&quot;:\&quot;Novara\&quot;,\&quot;NU\&quot;:\&quot;Nuoro\&quot;,\&quot;OT\&quot;:\&quot;Olbia-Tempio\&quot;,\&quot;OR\&quot;:\&quot;Oristano\&quot;,\&quot;PD\&quot;:\&quot;Padova\&quot;,\&quot;PA\&quot;:\&quot;Palermo\&quot;,\&quot;PR\&quot;:\&quot;Parma\&quot;,\&quot;PV\&quot;:\&quot;Pavia\&quot;,\&quot;PG\&quot;:\&quot;Perugia\&quot;,\&quot;PU\&quot;:\&quot;Pesaro e Urbino\&quot;,\&quot;PE\&quot;:\&quot;Pescara\&quot;,\&quot;PC\&quot;:\&quot;Piacenza\&quot;,\&quot;PI\&quot;:\&quot;Pisa\&quot;,\&quot;PT\&quot;:\&quot;Pistoia\&quot;,\&quot;PN\&quot;:\&quot;Pordenone\&quot;,\&quot;PZ\&quot;:\&quot;Potenza\&quot;,\&quot;PO\&quot;:\&quot;Prato\&quot;,\&quot;RG\&quot;:\&quot;Ragusa\&quot;,\&quot;RA\&quot;:\&quot;Ravenna\&quot;,\&quot;RC\&quot;:\&quot;Reggio Calabria\&quot;,\&quot;RE\&quot;:\&quot;Reggio Emilia\&quot;,\&quot;RI\&quot;:\&quot;Rieti\&quot;,\&quot;RN\&quot;:\&quot;Rimini\&quot;,\&quot;RM\&quot;:\&quot;Roma\&quot;,\&quot;RO\&quot;:\&quot;Rovigo\&quot;,\&quot;SA\&quot;:\&quot;Salerno\&quot;,\&quot;VS\&quot;:\&quot;Medio Campidano\&quot;,\&quot;SS\&quot;:\&quot;Sassari\&quot;,\&quot;SV\&quot;:\&quot;Savona\&quot;,\&quot;SI\&quot;:\&quot;Siena\&quot;,\&quot;SR\&quot;:\&quot;Siracusa\&quot;,\&quot;SO\&quot;:\&quot;Sondrio\&quot;,\&quot;TA\&quot;:\&quot;Taranto\&quot;,\&quot;TE\&quot;:\&quot;Teramo\&quot;,\&quot;TR\&quot;:\&quot;Terni\&quot;,\&quot;TO\&quot;:\&quot;Torino\&quot;,\&quot;OG\&quot;:\&quot;Ogliastra\&quot;,\&quot;TP\&quot;:\&quot;Trapani\&quot;,\&quot;TN\&quot;:\&quot;Trento\&quot;,\&quot;TV\&quot;:\&quot;Treviso\&quot;,\&quot;TS\&quot;:\&quot;Trieste\&quot;,\&quot;UD\&quot;:\&quot;Udine\&quot;,\&quot;VA\&quot;:\&quot;Varese\&quot;,\&quot;VE\&quot;:\&quot;Venezia\&quot;,\&quot;VB\&quot;:\&quot;Verbano-Cusio-Ossola\&quot;,\&quot;VC\&quot;:\&quot;Vercelli\&quot;,\&quot;VR\&quot;:\&quot;Verona\&quot;,\&quot;VV\&quot;:\&quot;Vibo Valentia\&quot;,\&quot;VI\&quot;:\&quot;Vicenza\&quot;,\&quot;VT\&quot;:\&quot;Viterbo\&quot;},\&quot;JP\&quot;:{\&quot;JP01\&quot;:\&quot;Hokkaido\&quot;,\&quot;JP02\&quot;:\&quot;Aomori\&quot;,\&quot;JP03\&quot;:\&quot;Iwate\&quot;,\&quot;JP04\&quot;:\&quot;Miyagi\&quot;,\&quot;JP05\&quot;:\&quot;Akita\&quot;,\&quot;JP06\&quot;:\&quot;Yamagata\&quot;,\&quot;JP07\&quot;:\&quot;Fukushima\&quot;,\&quot;JP08\&quot;:\&quot;Ibaraki\&quot;,\&quot;JP09\&quot;:\&quot;Tochigi\&quot;,\&quot;JP10\&quot;:\&quot;Gunma\&quot;,\&quot;JP11\&quot;:\&quot;Saitama\&quot;,\&quot;JP12\&quot;:\&quot;Chiba\&quot;,\&quot;JP13\&quot;:\&quot;Tokyo\&quot;,\&quot;JP14\&quot;:\&quot;Kanagawa\&quot;,\&quot;JP15\&quot;:\&quot;Niigata\&quot;,\&quot;JP16\&quot;:\&quot;Toyama\&quot;,\&quot;JP17\&quot;:\&quot;Ishikawa\&quot;,\&quot;JP18\&quot;:\&quot;Fukui\&quot;,\&quot;JP19\&quot;:\&quot;Yamanashi\&quot;,\&quot;JP20\&quot;:\&quot;Nagano\&quot;,\&quot;JP21\&quot;:\&quot;Gifu\&quot;,\&quot;JP22\&quot;:\&quot;Shizuoka\&quot;,\&quot;JP23\&quot;:\&quot;Aichi\&quot;,\&quot;JP24\&quot;:\&quot;Mie\&quot;,\&quot;JP25\&quot;:\&quot;Shiga\&quot;,\&quot;JP26\&quot;:\&quot;Kyoto\&quot;,\&quot;JP27\&quot;:\&quot;Osaka\&quot;,\&quot;JP28\&quot;:\&quot;Hyogo\&quot;,\&quot;JP29\&quot;:\&quot;Nara\&quot;,\&quot;JP30\&quot;:\&quot;Wakayama\&quot;,\&quot;JP31\&quot;:\&quot;Tottori\&quot;,\&quot;JP32\&quot;:\&quot;Shimane\&quot;,\&quot;JP33\&quot;:\&quot;Okayama\&quot;,\&quot;JP34\&quot;:\&quot;Hiroshima\&quot;,\&quot;JP35\&quot;:\&quot;Yamaguchi\&quot;,\&quot;JP36\&quot;:\&quot;Tokushima\&quot;,\&quot;JP37\&quot;:\&quot;Kagawa\&quot;,\&quot;JP38\&quot;:\&quot;Ehime\&quot;,\&quot;JP39\&quot;:\&quot;Kochi\&quot;,\&quot;JP40\&quot;:\&quot;Fukuoka\&quot;,\&quot;JP41\&quot;:\&quot;Saga\&quot;,\&quot;JP42\&quot;:\&quot;Nagasaki\&quot;,\&quot;JP43\&quot;:\&quot;Kumamoto\&quot;,\&quot;JP44\&quot;:\&quot;Oita\&quot;,\&quot;JP45\&quot;:\&quot;Miyazaki\&quot;,\&quot;JP46\&quot;:\&quot;Kagoshima\&quot;,\&quot;JP47\&quot;:\&quot;Okinawa\&quot;},\&quot;MY\&quot;:{\&quot;JHR\&quot;:\&quot;Johor\&quot;,\&quot;KDH\&quot;:\&quot;Kedah\&quot;,\&quot;KTN\&quot;:\&quot;Kelantan\&quot;,\&quot;LBN\&quot;:\&quot;Labuan\&quot;,\&quot;MLK\&quot;:\&quot;Malacca (Melaka)\&quot;,\&quot;NSN\&quot;:\&quot;Negeri Sembilan\&quot;,\&quot;PHG\&quot;:\&quot;Pahang\&quot;,\&quot;PNG\&quot;:\&quot;Penang (Pulau Pinang)\&quot;,\&quot;PRK\&quot;:\&quot;Perak\&quot;,\&quot;PLS\&quot;:\&quot;Perlis\&quot;,\&quot;SBH\&quot;:\&quot;Sabah\&quot;,\&quot;SWK\&quot;:\&quot;Sarawak\&quot;,\&quot;SGR\&quot;:\&quot;Selangor\&quot;,\&quot;TRG\&quot;:\&quot;Terengganu\&quot;,\&quot;PJY\&quot;:\&quot;Putrajaya\&quot;,\&quot;KUL\&quot;:\&quot;Kuala Lumpur\&quot;},\&quot;MX\&quot;:{\&quot;Distrito Federal\&quot;:\&quot;Distrito Federal\&quot;,\&quot;Jalisco\&quot;:\&quot;Jalisco\&quot;,\&quot;Nuevo Leon\&quot;:\&quot;Nuevo Le\\u00f3n\&quot;,\&quot;Aguascalientes\&quot;:\&quot;Aguascalientes\&quot;,\&quot;Baja California\&quot;:\&quot;Baja California\&quot;,\&quot;Baja California Sur\&quot;:\&quot;Baja California Sur\&quot;,\&quot;Campeche\&quot;:\&quot;Campeche\&quot;,\&quot;Chiapas\&quot;:\&quot;Chiapas\&quot;,\&quot;Chihuahua\&quot;:\&quot;Chihuahua\&quot;,\&quot;Coahuila\&quot;:\&quot;Coahuila\&quot;,\&quot;Colima\&quot;:\&quot;Colima\&quot;,\&quot;Durango\&quot;:\&quot;Durango\&quot;,\&quot;Guanajuato\&quot;:\&quot;Guanajuato\&quot;,\&quot;Guerrero\&quot;:\&quot;Guerrero\&quot;,\&quot;Hidalgo\&quot;:\&quot;Hidalgo\&quot;,\&quot;Estado de Mexico\&quot;:\&quot;Edo. de M\\u00e9xico\&quot;,\&quot;Michoacan\&quot;:\&quot;Michoac\\u00e1n\&quot;,\&quot;Morelos\&quot;:\&quot;Morelos\&quot;,\&quot;Nayarit\&quot;:\&quot;Nayarit\&quot;,\&quot;Oaxaca\&quot;:\&quot;Oaxaca\&quot;,\&quot;Puebla\&quot;:\&quot;Puebla\&quot;,\&quot;Queretaro\&quot;:\&quot;Quer\\u00e9taro\&quot;,\&quot;Quintana Roo\&quot;:\&quot;Quintana Roo\&quot;,\&quot;San Luis Potosi\&quot;:\&quot;San Luis Potos\\u00ed\&quot;,\&quot;Sinaloa\&quot;:\&quot;Sinaloa\&quot;,\&quot;Sonora\&quot;:\&quot;Sonora\&quot;,\&quot;Tabasco\&quot;:\&quot;Tabasco\&quot;,\&quot;Tamaulipas\&quot;:\&quot;Tamaulipas\&quot;,\&quot;Tlaxcala\&quot;:\&quot;Tlaxcala\&quot;,\&quot;Veracruz\&quot;:\&quot;Veracruz\&quot;,\&quot;Yucatan\&quot;:\&quot;Yucat\\u00e1n\&quot;,\&quot;Zacatecas\&quot;:\&quot;Zacatecas\&quot;},\&quot;NP\&quot;:{\&quot;BAG\&quot;:\&quot;Bagmati\&quot;,\&quot;BHE\&quot;:\&quot;Bheri\&quot;,\&quot;DHA\&quot;:\&quot;Dhawalagiri\&quot;,\&quot;GAN\&quot;:\&quot;Gandaki\&quot;,\&quot;JAN\&quot;:\&quot;Janakpur\&quot;,\&quot;KAR\&quot;:\&quot;Karnali\&quot;,\&quot;KOS\&quot;:\&quot;Koshi\&quot;,\&quot;LUM\&quot;:\&quot;Lumbini\&quot;,\&quot;MAH\&quot;:\&quot;Mahakali\&quot;,\&quot;MEC\&quot;:\&quot;Mechi\&quot;,\&quot;NAR\&quot;:\&quot;Narayani\&quot;,\&quot;RAP\&quot;:\&quot;Rapti\&quot;,\&quot;SAG\&quot;:\&quot;Sagarmatha\&quot;,\&quot;SET\&quot;:\&quot;Seti\&quot;},\&quot;NZ\&quot;:{\&quot;NL\&quot;:\&quot;Northland\&quot;,\&quot;AK\&quot;:\&quot;Auckland\&quot;,\&quot;WA\&quot;:\&quot;Waikato\&quot;,\&quot;BP\&quot;:\&quot;Bay of Plenty\&quot;,\&quot;TK\&quot;:\&quot;Taranaki\&quot;,\&quot;GI\&quot;:\&quot;Gisborne\&quot;,\&quot;HB\&quot;:\&quot;Hawke\u2019s Bay\&quot;,\&quot;MW\&quot;:\&quot;Manawatu-Wanganui\&quot;,\&quot;WE\&quot;:\&quot;Wellington\&quot;,\&quot;NS\&quot;:\&quot;Nelson\&quot;,\&quot;MB\&quot;:\&quot;Marlborough\&quot;,\&quot;TM\&quot;:\&quot;Tasman\&quot;,\&quot;WC\&quot;:\&quot;West Coast\&quot;,\&quot;CT\&quot;:\&quot;Canterbury\&quot;,\&quot;OT\&quot;:\&quot;Otago\&quot;,\&quot;SL\&quot;:\&quot;Southland\&quot;},\&quot;PE\&quot;:{\&quot;CAL\&quot;:\&quot;El Callao\&quot;,\&quot;LMA\&quot;:\&quot;Municipalidad Metropolitana de Lima\&quot;,\&quot;AMA\&quot;:\&quot;Amazonas\&quot;,\&quot;ANC\&quot;:\&quot;Ancash\&quot;,\&quot;APU\&quot;:\&quot;Apur\u00edmac\&quot;,\&quot;ARE\&quot;:\&quot;Arequipa\&quot;,\&quot;AYA\&quot;:\&quot;Ayacucho\&quot;,\&quot;CAJ\&quot;:\&quot;Cajamarca\&quot;,\&quot;CUS\&quot;:\&quot;Cusco\&quot;,\&quot;HUV\&quot;:\&quot;Huancavelica\&quot;,\&quot;HUC\&quot;:\&quot;Hu\u00e1nuco\&quot;,\&quot;ICA\&quot;:\&quot;Ica\&quot;,\&quot;JUN\&quot;:\&quot;Jun\u00edn\&quot;,\&quot;LAL\&quot;:\&quot;La Libertad\&quot;,\&quot;LAM\&quot;:\&quot;Lambayeque\&quot;,\&quot;LIM\&quot;:\&quot;Lima\&quot;,\&quot;LOR\&quot;:\&quot;Loreto\&quot;,\&quot;MDD\&quot;:\&quot;Madre de Dios\&quot;,\&quot;MOQ\&quot;:\&quot;Moquegua\&quot;,\&quot;PAS\&quot;:\&quot;Pasco\&quot;,\&quot;PIU\&quot;:\&quot;Piura\&quot;,\&quot;PUN\&quot;:\&quot;Puno\&quot;,\&quot;SAM\&quot;:\&quot;San Mart\u00edn\&quot;,\&quot;TAC\&quot;:\&quot;Tacna\&quot;,\&quot;TUM\&quot;:\&quot;Tumbes\&quot;,\&quot;UCA\&quot;:\&quot;Ucayali\&quot;},\&quot;PH\&quot;:{\&quot;ABR\&quot;:\&quot;Abra\&quot;,\&quot;AGN\&quot;:\&quot;Agusan del Norte\&quot;,\&quot;AGS\&quot;:\&quot;Agusan del Sur\&quot;,\&quot;AKL\&quot;:\&quot;Aklan\&quot;,\&quot;ALB\&quot;:\&quot;Albay\&quot;,\&quot;ANT\&quot;:\&quot;Antique\&quot;,\&quot;APA\&quot;:\&quot;Apayao\&quot;,\&quot;AUR\&quot;:\&quot;Aurora\&quot;,\&quot;BAS\&quot;:\&quot;Basilan\&quot;,\&quot;BAN\&quot;:\&quot;Bataan\&quot;,\&quot;BTN\&quot;:\&quot;Batanes\&quot;,\&quot;BTG\&quot;:\&quot;Batangas\&quot;,\&quot;BEN\&quot;:\&quot;Benguet\&quot;,\&quot;BIL\&quot;:\&quot;Biliran\&quot;,\&quot;BOH\&quot;:\&quot;Bohol\&quot;,\&quot;BUK\&quot;:\&quot;Bukidnon\&quot;,\&quot;BUL\&quot;:\&quot;Bulacan\&quot;,\&quot;CAG\&quot;:\&quot;Cagayan\&quot;,\&quot;CAN\&quot;:\&quot;Camarines Norte\&quot;,\&quot;CAS\&quot;:\&quot;Camarines Sur\&quot;,\&quot;CAM\&quot;:\&quot;Camiguin\&quot;,\&quot;CAP\&quot;:\&quot;Capiz\&quot;,\&quot;CAT\&quot;:\&quot;Catanduanes\&quot;,\&quot;CAV\&quot;:\&quot;Cavite\&quot;,\&quot;CEB\&quot;:\&quot;Cebu\&quot;,\&quot;COM\&quot;:\&quot;Compostela Valley\&quot;,\&quot;NCO\&quot;:\&quot;Cotabato\&quot;,\&quot;DAV\&quot;:\&quot;Davao del Norte\&quot;,\&quot;DAS\&quot;:\&quot;Davao del Sur\&quot;,\&quot;DAC\&quot;:\&quot;Davao Occidental\&quot;,\&quot;DAO\&quot;:\&quot;Davao Oriental\&quot;,\&quot;DIN\&quot;:\&quot;Dinagat Islands\&quot;,\&quot;EAS\&quot;:\&quot;Eastern Samar\&quot;,\&quot;GUI\&quot;:\&quot;Guimaras\&quot;,\&quot;IFU\&quot;:\&quot;Ifugao\&quot;,\&quot;ILN\&quot;:\&quot;Ilocos Norte\&quot;,\&quot;ILS\&quot;:\&quot;Ilocos Sur\&quot;,\&quot;ILI\&quot;:\&quot;Iloilo\&quot;,\&quot;ISA\&quot;:\&quot;Isabela\&quot;,\&quot;KAL\&quot;:\&quot;Kalinga\&quot;,\&quot;LUN\&quot;:\&quot;La Union\&quot;,\&quot;LAG\&quot;:\&quot;Laguna\&quot;,\&quot;LAN\&quot;:\&quot;Lanao del Norte\&quot;,\&quot;LAS\&quot;:\&quot;Lanao del Sur\&quot;,\&quot;LEY\&quot;:\&quot;Leyte\&quot;,\&quot;MAG\&quot;:\&quot;Maguindanao\&quot;,\&quot;MAD\&quot;:\&quot;Marinduque\&quot;,\&quot;MAS\&quot;:\&quot;Masbate\&quot;,\&quot;MSC\&quot;:\&quot;Misamis Occidental\&quot;,\&quot;MSR\&quot;:\&quot;Misamis Oriental\&quot;,\&quot;MOU\&quot;:\&quot;Mountain Province\&quot;,\&quot;NEC\&quot;:\&quot;Negros Occidental\&quot;,\&quot;NER\&quot;:\&quot;Negros Oriental\&quot;,\&quot;NSA\&quot;:\&quot;Northern Samar\&quot;,\&quot;NUE\&quot;:\&quot;Nueva Ecija\&quot;,\&quot;NUV\&quot;:\&quot;Nueva Vizcaya\&quot;,\&quot;MDC\&quot;:\&quot;Occidental Mindoro\&quot;,\&quot;MDR\&quot;:\&quot;Oriental Mindoro\&quot;,\&quot;PLW\&quot;:\&quot;Palawan\&quot;,\&quot;PAM\&quot;:\&quot;Pampanga\&quot;,\&quot;PAN\&quot;:\&quot;Pangasinan\&quot;,\&quot;QUE\&quot;:\&quot;Quezon\&quot;,\&quot;QUI\&quot;:\&quot;Quirino\&quot;,\&quot;RIZ\&quot;:\&quot;Rizal\&quot;,\&quot;ROM\&quot;:\&quot;Romblon\&quot;,\&quot;WSA\&quot;:\&quot;Samar\&quot;,\&quot;SAR\&quot;:\&quot;Sarangani\&quot;,\&quot;SIQ\&quot;:\&quot;Siquijor\&quot;,\&quot;SOR\&quot;:\&quot;Sorsogon\&quot;,\&quot;SCO\&quot;:\&quot;South Cotabato\&quot;,\&quot;SLE\&quot;:\&quot;Southern Leyte\&quot;,\&quot;SUK\&quot;:\&quot;Sultan Kudarat\&quot;,\&quot;SLU\&quot;:\&quot;Sulu\&quot;,\&quot;SUN\&quot;:\&quot;Surigao del Norte\&quot;,\&quot;SUR\&quot;:\&quot;Surigao del Sur\&quot;,\&quot;TAR\&quot;:\&quot;Tarlac\&quot;,\&quot;TAW\&quot;:\&quot;Tawi-Tawi\&quot;,\&quot;ZMB\&quot;:\&quot;Zambales\&quot;,\&quot;ZAN\&quot;:\&quot;Zamboanga del Norte\&quot;,\&quot;ZAS\&quot;:\&quot;Zamboanga del Sur\&quot;,\&quot;ZSI\&quot;:\&quot;Zamboanga Sibugay\&quot;,\&quot;00\&quot;:\&quot;Metro Manila\&quot;},\&quot;ZA\&quot;:{\&quot;EC\&quot;:\&quot;Eastern Cape\&quot;,\&quot;FS\&quot;:\&quot;Free State\&quot;,\&quot;GP\&quot;:\&quot;Gauteng\&quot;,\&quot;KZN\&quot;:\&quot;KwaZulu-Natal\&quot;,\&quot;LP\&quot;:\&quot;Limpopo\&quot;,\&quot;MP\&quot;:\&quot;Mpumalanga\&quot;,\&quot;NC\&quot;:\&quot;Northern Cape\&quot;,\&quot;NW\&quot;:\&quot;North West\&quot;,\&quot;WC\&quot;:\&quot;Western Cape\&quot;},\&quot;ES\&quot;:{\&quot;C\&quot;:\&quot;A Coru\u00f1a\&quot;,\&quot;VI\&quot;:\&quot;Araba\\\/\u00c1lava\&quot;,\&quot;AB\&quot;:\&quot;Albacete\&quot;,\&quot;A\&quot;:\&quot;Alicante\&quot;,\&quot;AL\&quot;:\&quot;Almer\u00eda\&quot;,\&quot;O\&quot;:\&quot;Asturias\&quot;,\&quot;AV\&quot;:\&quot;\u00c1vila\&quot;,\&quot;BA\&quot;:\&quot;Badajoz\&quot;,\&quot;PM\&quot;:\&quot;Baleares\&quot;,\&quot;B\&quot;:\&quot;Barcelona\&quot;,\&quot;BU\&quot;:\&quot;Burgos\&quot;,\&quot;CC\&quot;:\&quot;C\u00e1ceres\&quot;,\&quot;CA\&quot;:\&quot;C\u00e1diz\&quot;,\&quot;S\&quot;:\&quot;Cantabria\&quot;,\&quot;CS\&quot;:\&quot;Castell\u00f3n\&quot;,\&quot;CE\&quot;:\&quot;Ceuta\&quot;,\&quot;CR\&quot;:\&quot;Ciudad Real\&quot;,\&quot;CO\&quot;:\&quot;C\u00f3rdoba\&quot;,\&quot;CU\&quot;:\&quot;Cuenca\&quot;,\&quot;GI\&quot;:\&quot;Girona\&quot;,\&quot;GR\&quot;:\&quot;Granada\&quot;,\&quot;GU\&quot;:\&quot;Guadalajara\&quot;,\&quot;SS\&quot;:\&quot;Gipuzkoa\&quot;,\&quot;H\&quot;:\&quot;Huelva\&quot;,\&quot;HU\&quot;:\&quot;Huesca\&quot;,\&quot;J\&quot;:\&quot;Ja\u00e9n\&quot;,\&quot;LO\&quot;:\&quot;La Rioja\&quot;,\&quot;GC\&quot;:\&quot;Las Palmas\&quot;,\&quot;LE\&quot;:\&quot;Le\u00f3n\&quot;,\&quot;L\&quot;:\&quot;Lleida\&quot;,\&quot;LU\&quot;:\&quot;Lugo\&quot;,\&quot;M\&quot;:\&quot;Madrid\&quot;,\&quot;MA\&quot;:\&quot;M\u00e1laga\&quot;,\&quot;ML\&quot;:\&quot;Melilla\&quot;,\&quot;MU\&quot;:\&quot;Murcia\&quot;,\&quot;NA\&quot;:\&quot;Navarra\&quot;,\&quot;OR\&quot;:\&quot;Ourense\&quot;,\&quot;P\&quot;:\&quot;Palencia\&quot;,\&quot;PO\&quot;:\&quot;Pontevedra\&quot;,\&quot;SA\&quot;:\&quot;Salamanca\&quot;,\&quot;TF\&quot;:\&quot;Santa Cruz de Tenerife\&quot;,\&quot;SG\&quot;:\&quot;Segovia\&quot;,\&quot;SE\&quot;:\&quot;Sevilla\&quot;,\&quot;SO\&quot;:\&quot;Soria\&quot;,\&quot;T\&quot;:\&quot;Tarragona\&quot;,\&quot;TE\&quot;:\&quot;Teruel\&quot;,\&quot;TO\&quot;:\&quot;Toledo\&quot;,\&quot;V\&quot;:\&quot;Valencia\&quot;,\&quot;VA\&quot;:\&quot;Valladolid\&quot;,\&quot;BI\&quot;:\&quot;Bizkaia\&quot;,\&quot;ZA\&quot;:\&quot;Zamora\&quot;,\&quot;Z\&quot;:\&quot;Zaragoza\&quot;},\&quot;TH\&quot;:{\&quot;TH-37\&quot;:\&quot;Amnat Charoen (\u0e2d\u0e33\u0e19\u0e32\u0e08\u0e40\u0e08\u0e23\u0e34\u0e0d)\&quot;,\&quot;TH-15\&quot;:\&quot;Ang Thong (\u0e2d\u0e48\u0e32\u0e07\u0e17\u0e2d\u0e07)\&quot;,\&quot;TH-14\&quot;:\&quot;Ayutthaya (\u0e1e\u0e23\u0e30\u0e19\u0e04\u0e23\u0e28\u0e23\u0e35\u0e2d\u0e22\u0e38\u0e18\u0e22\u0e32)\&quot;,\&quot;TH-10\&quot;:\&quot;Bangkok (\u0e01\u0e23\u0e38\u0e07\u0e40\u0e17\u0e1e\u0e21\u0e2b\u0e32\u0e19\u0e04\u0e23)\&quot;,\&quot;TH-38\&quot;:\&quot;Bueng Kan (\u0e1a\u0e36\u0e07\u0e01\u0e32\u0e2c)\&quot;,\&quot;TH-31\&quot;:\&quot;Buri Ram (\u0e1a\u0e38\u0e23\u0e35\u0e23\u0e31\u0e21\u0e22\u0e4c)\&quot;,\&quot;TH-24\&quot;:\&quot;Chachoengsao (\u0e09\u0e30\u0e40\u0e0a\u0e34\u0e07\u0e40\u0e17\u0e23\u0e32)\&quot;,\&quot;TH-18\&quot;:\&quot;Chai Nat (\u0e0a\u0e31\u0e22\u0e19\u0e32\u0e17)\&quot;,\&quot;TH-36\&quot;:\&quot;Chaiyaphum (\u0e0a\u0e31\u0e22\u0e20\u0e39\u0e21\u0e34)\&quot;,\&quot;TH-22\&quot;:\&quot;Chanthaburi (\u0e08\u0e31\u0e19\u0e17\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-50\&quot;:\&quot;Chiang Mai (\u0e40\u0e0a\u0e35\u0e22\u0e07\u0e43\u0e2b\u0e21\u0e48)\&quot;,\&quot;TH-57\&quot;:\&quot;Chiang Rai (\u0e40\u0e0a\u0e35\u0e22\u0e07\u0e23\u0e32\u0e22)\&quot;,\&quot;TH-20\&quot;:\&quot;Chonburi (\u0e0a\u0e25\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-86\&quot;:\&quot;Chumphon (\u0e0a\u0e38\u0e21\u0e1e\u0e23)\&quot;,\&quot;TH-46\&quot;:\&quot;Kalasin (\u0e01\u0e32\u0e2c\u0e2a\u0e34\u0e19\u0e18\u0e38\u0e4c)\&quot;,\&quot;TH-62\&quot;:\&quot;Kamphaeng Phet (\u0e01\u0e33\u0e41\u0e1e\u0e07\u0e40\u0e1e\u0e0a\u0e23)\&quot;,\&quot;TH-71\&quot;:\&quot;Kanchanaburi (\u0e01\u0e32\u0e0d\u0e08\u0e19\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-40\&quot;:\&quot;Khon Kaen (\u0e02\u0e2d\u0e19\u0e41\u0e01\u0e48\u0e19)\&quot;,\&quot;TH-81\&quot;:\&quot;Krabi (\u0e01\u0e23\u0e30\u0e1a\u0e35\u0e48)\&quot;,\&quot;TH-52\&quot;:\&quot;Lampang (\u0e25\u0e33\u0e1b\u0e32\u0e07)\&quot;,\&quot;TH-51\&quot;:\&quot;Lamphun (\u0e25\u0e33\u0e1e\u0e39\u0e19)\&quot;,\&quot;TH-42\&quot;:\&quot;Loei (\u0e40\u0e25\u0e22)\&quot;,\&quot;TH-16\&quot;:\&quot;Lopburi (\u0e25\u0e1e\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-58\&quot;:\&quot;Mae Hong Son (\u0e41\u0e21\u0e48\u0e2e\u0e48\u0e2d\u0e07\u0e2a\u0e2d\u0e19)\&quot;,\&quot;TH-44\&quot;:\&quot;Maha Sarakham (\u0e21\u0e2b\u0e32\u0e2a\u0e32\u0e23\u0e04\u0e32\u0e21)\&quot;,\&quot;TH-49\&quot;:\&quot;Mukdahan (\u0e21\u0e38\u0e01\u0e14\u0e32\u0e2b\u0e32\u0e23)\&quot;,\&quot;TH-26\&quot;:\&quot;Nakhon Nayok (\u0e19\u0e04\u0e23\u0e19\u0e32\u0e22\u0e01)\&quot;,\&quot;TH-73\&quot;:\&quot;Nakhon Pathom (\u0e19\u0e04\u0e23\u0e1b\u0e10\u0e21)\&quot;,\&quot;TH-48\&quot;:\&quot;Nakhon Phanom (\u0e19\u0e04\u0e23\u0e1e\u0e19\u0e21)\&quot;,\&quot;TH-30\&quot;:\&quot;Nakhon Ratchasima (\u0e19\u0e04\u0e23\u0e23\u0e32\u0e0a\u0e2a\u0e35\u0e21\u0e32)\&quot;,\&quot;TH-60\&quot;:\&quot;Nakhon Sawan (\u0e19\u0e04\u0e23\u0e2a\u0e27\u0e23\u0e23\u0e04\u0e4c)\&quot;,\&quot;TH-80\&quot;:\&quot;Nakhon Si Thammarat (\u0e19\u0e04\u0e23\u0e28\u0e23\u0e35\u0e18\u0e23\u0e23\u0e21\u0e23\u0e32\u0e0a)\&quot;,\&quot;TH-55\&quot;:\&quot;Nan (\u0e19\u0e48\u0e32\u0e19)\&quot;,\&quot;TH-96\&quot;:\&quot;Narathiwat (\u0e19\u0e23\u0e32\u0e18\u0e34\u0e27\u0e32\u0e2a)\&quot;,\&quot;TH-39\&quot;:\&quot;Nong Bua Lam Phu (\u0e2b\u0e19\u0e2d\u0e07\u0e1a\u0e31\u0e27\u0e25\u0e33\u0e20\u0e39)\&quot;,\&quot;TH-43\&quot;:\&quot;Nong Khai (\u0e2b\u0e19\u0e2d\u0e07\u0e04\u0e32\u0e22)\&quot;,\&quot;TH-12\&quot;:\&quot;Nonthaburi (\u0e19\u0e19\u0e17\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-13\&quot;:\&quot;Pathum Thani (\u0e1b\u0e17\u0e38\u0e21\u0e18\u0e32\u0e19\u0e35)\&quot;,\&quot;TH-94\&quot;:\&quot;Pattani (\u0e1b\u0e31\u0e15\u0e15\u0e32\u0e19\u0e35)\&quot;,\&quot;TH-82\&quot;:\&quot;Phang Nga (\u0e1e\u0e31\u0e07\u0e07\u0e32)\&quot;,\&quot;TH-93\&quot;:\&quot;Phatthalung (\u0e1e\u0e31\u0e17\u0e25\u0e38\u0e07)\&quot;,\&quot;TH-56\&quot;:\&quot;Phayao (\u0e1e\u0e30\u0e40\u0e22\u0e32)\&quot;,\&quot;TH-67\&quot;:\&quot;Phetchabun (\u0e40\u0e1e\u0e0a\u0e23\u0e1a\u0e39\u0e23\u0e13\u0e4c)\&quot;,\&quot;TH-76\&quot;:\&quot;Phetchaburi (\u0e40\u0e1e\u0e0a\u0e23\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-66\&quot;:\&quot;Phichit (\u0e1e\u0e34\u0e08\u0e34\u0e15\u0e23)\&quot;,\&quot;TH-65\&quot;:\&quot;Phitsanulok (\u0e1e\u0e34\u0e29\u0e13\u0e38\u0e42\u0e25\u0e01)\&quot;,\&quot;TH-54\&quot;:\&quot;Phrae (\u0e41\u0e1e\u0e23\u0e48)\&quot;,\&quot;TH-83\&quot;:\&quot;Phuket (\u0e20\u0e39\u0e40\u0e01\u0e47\u0e15)\&quot;,\&quot;TH-25\&quot;:\&quot;Prachin Buri (\u0e1b\u0e23\u0e32\u0e08\u0e35\u0e19\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-77\&quot;:\&quot;Prachuap Khiri Khan (\u0e1b\u0e23\u0e30\u0e08\u0e27\u0e1a\u0e04\u0e35\u0e23\u0e35\u0e02\u0e31\u0e19\u0e18\u0e4c)\&quot;,\&quot;TH-85\&quot;:\&quot;Ranong (\u0e23\u0e30\u0e19\u0e2d\u0e07)\&quot;,\&quot;TH-70\&quot;:\&quot;Ratchaburi (\u0e23\u0e32\u0e0a\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-21\&quot;:\&quot;Rayong (\u0e23\u0e30\u0e22\u0e2d\u0e07)\&quot;,\&quot;TH-45\&quot;:\&quot;Roi Et (\u0e23\u0e49\u0e2d\u0e22\u0e40\u0e2d\u0e47\u0e14)\&quot;,\&quot;TH-27\&quot;:\&quot;Sa Kaeo (\u0e2a\u0e23\u0e30\u0e41\u0e01\u0e49\u0e27)\&quot;,\&quot;TH-47\&quot;:\&quot;Sakon Nakhon (\u0e2a\u0e01\u0e25\u0e19\u0e04\u0e23)\&quot;,\&quot;TH-11\&quot;:\&quot;Samut Prakan (\u0e2a\u0e21\u0e38\u0e17\u0e23\u0e1b\u0e23\u0e32\u0e01\u0e32\u0e23)\&quot;,\&quot;TH-74\&quot;:\&quot;Samut Sakhon (\u0e2a\u0e21\u0e38\u0e17\u0e23\u0e2a\u0e32\u0e04\u0e23)\&quot;,\&quot;TH-75\&quot;:\&quot;Samut Songkhram (\u0e2a\u0e21\u0e38\u0e17\u0e23\u0e2a\u0e07\u0e04\u0e23\u0e32\u0e21)\&quot;,\&quot;TH-19\&quot;:\&quot;Saraburi (\u0e2a\u0e23\u0e30\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-91\&quot;:\&quot;Satun (\u0e2a\u0e15\u0e39\u0e25)\&quot;,\&quot;TH-17\&quot;:\&quot;Sing Buri (\u0e2a\u0e34\u0e07\u0e2b\u0e4c\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-33\&quot;:\&quot;Sisaket (\u0e28\u0e23\u0e35\u0e2a\u0e30\u0e40\u0e01\u0e29)\&quot;,\&quot;TH-90\&quot;:\&quot;Songkhla (\u0e2a\u0e07\u0e02\u0e25\u0e32)\&quot;,\&quot;TH-64\&quot;:\&quot;Sukhothai (\u0e2a\u0e38\u0e42\u0e02\u0e17\u0e31\u0e22)\&quot;,\&quot;TH-72\&quot;:\&quot;Suphan Buri (\u0e2a\u0e38\u0e1e\u0e23\u0e23\u0e13\u0e1a\u0e38\u0e23\u0e35)\&quot;,\&quot;TH-84\&quot;:\&quot;Surat Thani (\u0e2a\u0e38\u0e23\u0e32\u0e29\u0e0e\u0e23\u0e4c\u0e18\u0e32\u0e19\u0e35)\&quot;,\&quot;TH-32\&quot;:\&quot;Surin (\u0e2a\u0e38\u0e23\u0e34\u0e19\u0e17\u0e23\u0e4c)\&quot;,\&quot;TH-63\&quot;:\&quot;Tak (\u0e15\u0e32\u0e01)\&quot;,\&quot;TH-92\&quot;:\&quot;Trang (\u0e15\u0e23\u0e31\u0e07)\&quot;,\&quot;TH-23\&quot;:\&quot;Trat (\u0e15\u0e23\u0e32\u0e14)\&quot;,\&quot;TH-34\&quot;:\&quot;Ubon Ratchathani (\u0e2d\u0e38\u0e1a\u0e25\u0e23\u0e32\u0e0a\u0e18\u0e32\u0e19\u0e35)\&quot;,\&quot;TH-41\&quot;:\&quot;Udon Thani (\u0e2d\u0e38\u0e14\u0e23\u0e18\u0e32\u0e19\u0e35)\&quot;,\&quot;TH-61\&quot;:\&quot;Uthai Thani (\u0e2d\u0e38\u0e17\u0e31\u0e22\u0e18\u0e32\u0e19\u0e35)\&quot;,\&quot;TH-53\&quot;:\&quot;Uttaradit (\u0e2d\u0e38\u0e15\u0e23\u0e14\u0e34\u0e15\u0e16\u0e4c)\&quot;,\&quot;TH-95\&quot;:\&quot;Yala (\u0e22\u0e30\u0e25\u0e32)\&quot;,\&quot;TH-35\&quot;:\&quot;Yasothon (\u0e22\u0e42\u0e2a\u0e18\u0e23)\&quot;},\&quot;TR\&quot;:{\&quot;TR01\&quot;:\&quot;Adana\&quot;,\&quot;TR02\&quot;:\&quot;Ad\u0131yaman\&quot;,\&quot;TR03\&quot;:\&quot;Afyon\&quot;,\&quot;TR04\&quot;:\&quot;A\u011fr\u0131\&quot;,\&quot;TR05\&quot;:\&quot;Amasya\&quot;,\&quot;TR06\&quot;:\&quot;Ankara\&quot;,\&quot;TR07\&quot;:\&quot;Antalya\&quot;,\&quot;TR08\&quot;:\&quot;Artvin\&quot;,\&quot;TR09\&quot;:\&quot;Ayd\u0131n\&quot;,\&quot;TR10\&quot;:\&quot;Bal\u0131kesir\&quot;,\&quot;TR11\&quot;:\&quot;Bilecik\&quot;,\&quot;TR12\&quot;:\&quot;Bing\u00f6l\&quot;,\&quot;TR13\&quot;:\&quot;Bitlis\&quot;,\&quot;TR14\&quot;:\&quot;Bolu\&quot;,\&quot;TR15\&quot;:\&quot;Burdur\&quot;,\&quot;TR16\&quot;:\&quot;Bursa\&quot;,\&quot;TR17\&quot;:\&quot;\u00c7anakkale\&quot;,\&quot;TR18\&quot;:\&quot;\u00c7ank\u0131r\u0131\&quot;,\&quot;TR19\&quot;:\&quot;\u00c7orum\&quot;,\&quot;TR20\&quot;:\&quot;Denizli\&quot;,\&quot;TR21\&quot;:\&quot;Diyarbak\u0131r\&quot;,\&quot;TR22\&quot;:\&quot;Edirne\&quot;,\&quot;TR23\&quot;:\&quot;Elaz\u0131\u011f\&quot;,\&quot;TR24\&quot;:\&quot;Erzincan\&quot;,\&quot;TR25\&quot;:\&quot;Erzurum\&quot;,\&quot;TR26\&quot;:\&quot;Eski\u015fehir\&quot;,\&quot;TR27\&quot;:\&quot;Gaziantep\&quot;,\&quot;TR28\&quot;:\&quot;Giresun\&quot;,\&quot;TR29\&quot;:\&quot;G\u00fcm\u00fc\u015fhane\&quot;,\&quot;TR30\&quot;:\&quot;Hakkari\&quot;,\&quot;TR31\&quot;:\&quot;Hatay\&quot;,\&quot;TR32\&quot;:\&quot;Isparta\&quot;,\&quot;TR33\&quot;:\&quot;\u0130\u00e7el\&quot;,\&quot;TR34\&quot;:\&quot;\u0130stanbul\&quot;,\&quot;TR35\&quot;:\&quot;\u0130zmir\&quot;,\&quot;TR36\&quot;:\&quot;Kars\&quot;,\&quot;TR37\&quot;:\&quot;Kastamonu\&quot;,\&quot;TR38\&quot;:\&quot;Kayseri\&quot;,\&quot;TR39\&quot;:\&quot;K\u0131rklareli\&quot;,\&quot;TR40\&quot;:\&quot;K\u0131r\u015fehir\&quot;,\&quot;TR41\&quot;:\&quot;Kocaeli\&quot;,\&quot;TR42\&quot;:\&quot;Konya\&quot;,\&quot;TR43\&quot;:\&quot;K\u00fctahya\&quot;,\&quot;TR44\&quot;:\&quot;Malatya\&quot;,\&quot;TR45\&quot;:\&quot;Manisa\&quot;,\&quot;TR46\&quot;:\&quot;Kahramanmara\u015f\&quot;,\&quot;TR47\&quot;:\&quot;Mardin\&quot;,\&quot;TR48\&quot;:\&quot;Mu\u011fla\&quot;,\&quot;TR49\&quot;:\&quot;Mu\u015f\&quot;,\&quot;TR50\&quot;:\&quot;Nev\u015fehir\&quot;,\&quot;TR51\&quot;:\&quot;Ni\u011fde\&quot;,\&quot;TR52\&quot;:\&quot;Ordu\&quot;,\&quot;TR53\&quot;:\&quot;Rize\&quot;,\&quot;TR54\&quot;:\&quot;Sakarya\&quot;,\&quot;TR55\&quot;:\&quot;Samsun\&quot;,\&quot;TR56\&quot;:\&quot;Siirt\&quot;,\&quot;TR57\&quot;:\&quot;Sinop\&quot;,\&quot;TR58\&quot;:\&quot;Sivas\&quot;,\&quot;TR59\&quot;:\&quot;Tekirda\u011f\&quot;,\&quot;TR60\&quot;:\&quot;Tokat\&quot;,\&quot;TR61\&quot;:\&quot;Trabzon\&quot;,\&quot;TR62\&quot;:\&quot;Tunceli\&quot;,\&quot;TR63\&quot;:\&quot;\u015eanl\u0131urfa\&quot;,\&quot;TR64\&quot;:\&quot;U\u015fak\&quot;,\&quot;TR65\&quot;:\&quot;Van\&quot;,\&quot;TR66\&quot;:\&quot;Yozgat\&quot;,\&quot;TR67\&quot;:\&quot;Zonguldak\&quot;,\&quot;TR68\&quot;:\&quot;Aksaray\&quot;,\&quot;TR69\&quot;:\&quot;Bayburt\&quot;,\&quot;TR70\&quot;:\&quot;Karaman\&quot;,\&quot;TR71\&quot;:\&quot;K\u0131r\u0131kkale\&quot;,\&quot;TR72\&quot;:\&quot;Batman\&quot;,\&quot;TR73\&quot;:\&quot;\u015e\u0131rnak\&quot;,\&quot;TR74\&quot;:\&quot;Bart\u0131n\&quot;,\&quot;TR75\&quot;:\&quot;Ardahan\&quot;,\&quot;TR76\&quot;:\&quot;I\u011fd\u0131r\&quot;,\&quot;TR77\&quot;:\&quot;Yalova\&quot;,\&quot;TR78\&quot;:\&quot;Karab\u00fck\&quot;,\&quot;TR79\&quot;:\&quot;Kilis\&quot;,\&quot;TR80\&quot;:\&quot;Osmaniye\&quot;,\&quot;TR81\&quot;:\&quot;D\u00fczce\&quot;},\&quot;US\&quot;:{\&quot;AL\&quot;:\&quot;Alabama\&quot;,\&quot;AK\&quot;:\&quot;Alaska\&quot;,\&quot;AZ\&quot;:\&quot;Arizona\&quot;,\&quot;AR\&quot;:\&quot;Arkansas\&quot;,\&quot;CA\&quot;:\&quot;California\&quot;,\&quot;CO\&quot;:\&quot;Colorado\&quot;,\&quot;CT\&quot;:\&quot;Connecticut\&quot;,\&quot;DE\&quot;:\&quot;Delaware\&quot;,\&quot;DC\&quot;:\&quot;District Of Columbia\&quot;,\&quot;FL\&quot;:\&quot;Florida\&quot;,\&quot;GA\&quot;:\&quot;Georgia\&quot;,\&quot;HI\&quot;:\&quot;Hawaii\&quot;,\&quot;ID\&quot;:\&quot;Idaho\&quot;,\&quot;IL\&quot;:\&quot;Illinois\&quot;,\&quot;IN\&quot;:\&quot;Indiana\&quot;,\&quot;IA\&quot;:\&quot;Iowa\&quot;,\&quot;KS\&quot;:\&quot;Kansas\&quot;,\&quot;KY\&quot;:\&quot;Kentucky\&quot;,\&quot;LA\&quot;:\&quot;Louisiana\&quot;,\&quot;ME\&quot;:\&quot;Maine\&quot;,\&quot;MD\&quot;:\&quot;Maryland\&quot;,\&quot;MA\&quot;:\&quot;Massachusetts\&quot;,\&quot;MI\&quot;:\&quot;Michigan\&quot;,\&quot;MN\&quot;:\&quot;Minnesota\&quot;,\&quot;MS\&quot;:\&quot;Mississippi\&quot;,\&quot;MO\&quot;:\&quot;Missouri\&quot;,\&quot;MT\&quot;:\&quot;Montana\&quot;,\&quot;NE\&quot;:\&quot;Nebraska\&quot;,\&quot;NV\&quot;:\&quot;Nevada\&quot;,\&quot;NH\&quot;:\&quot;New Hampshire\&quot;,\&quot;NJ\&quot;:\&quot;New Jersey\&quot;,\&quot;NM\&quot;:\&quot;New Mexico\&quot;,\&quot;NY\&quot;:\&quot;New York\&quot;,\&quot;NC\&quot;:\&quot;North Carolina\&quot;,\&quot;ND\&quot;:\&quot;North Dakota\&quot;,\&quot;OH\&quot;:\&quot;Ohio\&quot;,\&quot;OK\&quot;:\&quot;Oklahoma\&quot;,\&quot;OR\&quot;:\&quot;Oregon\&quot;,\&quot;PA\&quot;:\&quot;Pennsylvania\&quot;,\&quot;RI\&quot;:\&quot;Rhode Island\&quot;,\&quot;SC\&quot;:\&quot;South Carolina\&quot;,\&quot;SD\&quot;:\&quot;South Dakota\&quot;,\&quot;TN\&quot;:\&quot;Tennessee\&quot;,\&quot;TX\&quot;:\&quot;Texas\&quot;,\&quot;UT\&quot;:\&quot;Utah\&quot;,\&quot;VT\&quot;:\&quot;Vermont\&quot;,\&quot;VA\&quot;:\&quot;Virginia\&quot;,\&quot;WA\&quot;:\&quot;Washington\&quot;,\&quot;WV\&quot;:\&quot;West Virginia\&quot;,\&quot;WI\&quot;:\&quot;Wisconsin\&quot;,\&quot;WY\&quot;:\&quot;Wyoming\&quot;,\&quot;AA\&quot;:\&quot;Armed Forces (AA)\&quot;,\&quot;AE\&quot;:\&quot;Armed Forces (AE)\&quot;,\&quot;AP\&quot;:\&quot;Armed Forces (AP)\&quot;}}&quot;,&quot;i18n_select_state_text&quot;:&quot;Select an option\u2026&quot;,&quot;i18n_matches_1&quot;:&quot;One result is available, press enter to select it.&quot;,&quot;i18n_matches_n&quot;:&quot;%qty% results are available, use up and down arrow keys to navigate.&quot;,&quot;i18n_no_matches&quot;:&quot;No matches found&quot;,&quot;i18n_ajax_error&quot;:&quot;Loading failed&quot;,&quot;i18n_input_too_short_1&quot;:&quot;Please enter 1 or more characters&quot;,&quot;i18n_input_too_short_n&quot;:&quot;Please enter %qty% or more characters&quot;,&quot;i18n_input_too_long_1&quot;:&quot;Please delete 1 character&quot;,&quot;i18n_input_too_long_n&quot;:&quot;Please delete %qty% characters&quot;,&quot;i18n_selection_too_long_1&quot;:&quot;You can only select 1 item&quot;,&quot;i18n_selection_too_long_n&quot;:&quot;You can only select %qty% items&quot;,&quot;i18n_load_more&quot;:&quot;Loading more results\u2026&quot;,&quot;i18n_searching&quot;:&quot;Searching\u2026&quot;};
/* ]]&gt; */



/* &lt;![CDATA[ */
var wc_address_i18n_params = {&quot;locale&quot;:&quot;{\&quot;AE\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false,\&quot;hidden\&quot;:true}},\&quot;AF\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;AT\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;AU\&quot;:{\&quot;city\&quot;:{\&quot;label\&quot;:\&quot;Suburb\&quot;},\&quot;postcode\&quot;:{\&quot;label\&quot;:\&quot;Postcode\&quot;},\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;State\&quot;}},\&quot;AX\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;BD\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false},\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;District\&quot;}},\&quot;BE\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false,\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;BI\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;BO\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false,\&quot;hidden\&quot;:true}},\&quot;BS\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false,\&quot;hidden\&quot;:true}},\&quot;CA\&quot;:{\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;CH\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Canton\&quot;,\&quot;required\&quot;:false}},\&quot;CL\&quot;:{\&quot;city\&quot;:{\&quot;required\&quot;:true},\&quot;postcode\&quot;:{\&quot;required\&quot;:false},\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Region\&quot;}},\&quot;CN\&quot;:{\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;CO\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false}},\&quot;CZ\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;DE\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;DK\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;EE\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;FI\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;FR\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;HK\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false},\&quot;city\&quot;:{\&quot;label\&quot;:\&quot;Town \\\/ District\&quot;},\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Region\&quot;}},\&quot;HU\&quot;:{\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;County\&quot;}},\&quot;ID\&quot;:{\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;IE\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false,\&quot;label\&quot;:\&quot;Postcode\&quot;}},\&quot;IS\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;IL\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;IT\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:true,\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;JP\&quot;:{\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Prefecture\&quot;}},\&quot;KR\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;NL\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false,\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;NZ\&quot;:{\&quot;postcode\&quot;:{\&quot;label\&quot;:\&quot;Postcode\&quot;},\&quot;state\&quot;:{\&quot;required\&quot;:false,\&quot;label\&quot;:\&quot;Region\&quot;}},\&quot;NO\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;NP\&quot;:{\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;State \\\/ Zone\&quot;},\&quot;postcode\&quot;:{\&quot;required\&quot;:false}},\&quot;PL\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;PT\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;RO\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;SG\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;SK\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;SI\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;ES\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;LI\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Municipality\&quot;,\&quot;required\&quot;:false}},\&quot;LK\&quot;:{\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;SE\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false}},\&quot;TR\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;US\&quot;:{\&quot;postcode\&quot;:{\&quot;label\&quot;:\&quot;ZIP\&quot;},\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;State\&quot;}},\&quot;GB\&quot;:{\&quot;postcode\&quot;:{\&quot;label\&quot;:\&quot;Postcode\&quot;},\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;County\&quot;,\&quot;required\&quot;:false}},\&quot;VN\&quot;:{\&quot;postcode_before_city\&quot;:true,\&quot;state\&quot;:{\&quot;required\&quot;:false},\&quot;postcode\&quot;:{\&quot;required\&quot;:false,\&quot;hidden\&quot;:false},\&quot;address_2\&quot;:{\&quot;required\&quot;:false,\&quot;hidden\&quot;:true}},\&quot;WS\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false,\&quot;hidden\&quot;:true}},\&quot;ZA\&quot;:{\&quot;state\&quot;:{\&quot;label\&quot;:\&quot;Province\&quot;}},\&quot;ZW\&quot;:{\&quot;postcode\&quot;:{\&quot;required\&quot;:false,\&quot;hidden\&quot;:true}},\&quot;default\&quot;:{\&quot;first_name\&quot;:{\&quot;label\&quot;:\&quot;First Name\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-first\&quot;],\&quot;autocomplete\&quot;:\&quot;given-name\&quot;},\&quot;last_name\&quot;:{\&quot;label\&quot;:\&quot;Last Name\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-last\&quot;],\&quot;clear\&quot;:true,\&quot;autocomplete\&quot;:\&quot;family-name\&quot;},\&quot;company\&quot;:{\&quot;label\&quot;:\&quot;Company Name\&quot;,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;],\&quot;autocomplete\&quot;:\&quot;organization\&quot;},\&quot;country\&quot;:{\&quot;type\&quot;:\&quot;country\&quot;,\&quot;label\&quot;:\&quot;Country\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;,\&quot;update_totals_on_change\&quot;],\&quot;autocomplete\&quot;:\&quot;country\&quot;},\&quot;address_1\&quot;:{\&quot;label\&quot;:\&quot;Address\&quot;,\&quot;placeholder\&quot;:\&quot;Street address\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;],\&quot;autocomplete\&quot;:\&quot;address-line1\&quot;},\&quot;address_2\&quot;:{\&quot;placeholder\&quot;:\&quot;Apartment, suite, unit etc. (optional)\&quot;,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;],\&quot;required\&quot;:false,\&quot;autocomplete\&quot;:\&quot;address-line2\&quot;},\&quot;city\&quot;:{\&quot;label\&quot;:\&quot;Town \\\/ City\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;],\&quot;autocomplete\&quot;:\&quot;address-level2\&quot;},\&quot;state\&quot;:{\&quot;type\&quot;:\&quot;state\&quot;,\&quot;label\&quot;:\&quot;State \\\/ County\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-first\&quot;,\&quot;address-field\&quot;],\&quot;validate\&quot;:[\&quot;state\&quot;],\&quot;autocomplete\&quot;:\&quot;address-level1\&quot;},\&quot;postcode\&quot;:{\&quot;label\&quot;:\&quot;Postcode \\\/ ZIP\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-last\&quot;,\&quot;address-field\&quot;],\&quot;clear\&quot;:true,\&quot;validate\&quot;:[\&quot;postcode\&quot;],\&quot;autocomplete\&quot;:\&quot;postal-code\&quot;}},\&quot;IN\&quot;:{\&quot;first_name\&quot;:{\&quot;label\&quot;:\&quot;First Name\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-first\&quot;],\&quot;autocomplete\&quot;:\&quot;given-name\&quot;},\&quot;last_name\&quot;:{\&quot;label\&quot;:\&quot;Last Name\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-last\&quot;],\&quot;clear\&quot;:true,\&quot;autocomplete\&quot;:\&quot;family-name\&quot;},\&quot;company\&quot;:{\&quot;label\&quot;:\&quot;Company Name\&quot;,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;],\&quot;autocomplete\&quot;:\&quot;organization\&quot;},\&quot;country\&quot;:{\&quot;type\&quot;:\&quot;country\&quot;,\&quot;label\&quot;:\&quot;Country\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;,\&quot;update_totals_on_change\&quot;],\&quot;autocomplete\&quot;:\&quot;country\&quot;},\&quot;address_1\&quot;:{\&quot;label\&quot;:\&quot;Address\&quot;,\&quot;placeholder\&quot;:\&quot;Street address\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;],\&quot;autocomplete\&quot;:\&quot;address-line1\&quot;},\&quot;address_2\&quot;:{\&quot;placeholder\&quot;:\&quot;Apartment, suite, unit etc. (optional)\&quot;,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;],\&quot;required\&quot;:false,\&quot;autocomplete\&quot;:\&quot;address-line2\&quot;},\&quot;city\&quot;:{\&quot;label\&quot;:\&quot;Town \\\/ City\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-wide\&quot;,\&quot;address-field\&quot;],\&quot;autocomplete\&quot;:\&quot;address-level2\&quot;},\&quot;state\&quot;:{\&quot;type\&quot;:\&quot;state\&quot;,\&quot;label\&quot;:\&quot;State \\\/ County\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-first\&quot;,\&quot;address-field\&quot;],\&quot;validate\&quot;:[\&quot;state\&quot;],\&quot;autocomplete\&quot;:\&quot;address-level1\&quot;},\&quot;postcode\&quot;:{\&quot;label\&quot;:\&quot;Postcode \\\/ ZIP\&quot;,\&quot;required\&quot;:true,\&quot;class\&quot;:[\&quot;form-row-last\&quot;,\&quot;address-field\&quot;],\&quot;clear\&quot;:true,\&quot;validate\&quot;:[\&quot;postcode\&quot;],\&quot;autocomplete\&quot;:\&quot;postal-code\&quot;}}}&quot;,&quot;locale_fields&quot;:&quot;{\&quot;address_1\&quot;:\&quot;#billing_address_1_field, #shipping_address_1_field\&quot;,\&quot;address_2\&quot;:\&quot;#billing_address_2_field, #shipping_address_2_field\&quot;,\&quot;state\&quot;:\&quot;#billing_state_field, #shipping_state_field, #calc_shipping_state_field\&quot;,\&quot;postcode\&quot;:\&quot;#billing_postcode_field, #shipping_postcode_field, #calc_shipping_postcode_field\&quot;,\&quot;city\&quot;:\&quot;#billing_city_field, #shipping_city_field, #calc_shipping_city_field\&quot;}&quot;,&quot;i18n_required_text&quot;:&quot;required&quot;};
/* ]]&gt; */



/* &lt;![CDATA[ */
var wc_checkout_params = {&quot;ajax_url&quot;:&quot;\/wp-admin\/admin-ajax.php&quot;,&quot;wc_ajax_url&quot;:&quot;\/checkout\/?wc-ajax=%%endpoint%%&quot;,&quot;update_order_review_nonce&quot;:&quot;54fc2529e7&quot;,&quot;apply_coupon_nonce&quot;:&quot;4cab8888ca&quot;,&quot;remove_coupon_nonce&quot;:&quot;057942b4fe&quot;,&quot;option_guest_checkout&quot;:&quot;yes&quot;,&quot;checkout_url&quot;:&quot;\/checkout\/?wc-ajax=checkout&quot;,&quot;is_checkout&quot;:&quot;1&quot;,&quot;debug_mode&quot;:&quot;&quot;,&quot;i18n_checkout_error&quot;:&quot;Error processing checkout. Please try again.&quot;};
/* ]]&gt; */




/* &lt;![CDATA[ */
var wc_cart_fragments_params = {&quot;ajax_url&quot;:&quot;\/wp-admin\/admin-ajax.php&quot;,&quot;wc_ajax_url&quot;:&quot;\/checkout\/?wc-ajax=%%endpoint%%&quot;,&quot;fragment_name&quot;:&quot;wc_fragments&quot;};
/* ]]&gt; */







/* &lt;![CDATA[ */
var themifyScript = {&quot;lightbox&quot;:{&quot;lightboxSelector&quot;:&quot;.themify_lightbox&quot;,&quot;lightboxOn&quot;:true,&quot;lightboxContentImages&quot;:false,&quot;lightboxContentImagesSelector&quot;:&quot;.post-content a[href$=jpg],.page-content a[href$=jpg],.post-content a[href$=gif],.page-content a[href$=gif],.post-content a[href$=png],.page-content a[href$=png],.post-content a[href$=JPG],.page-content a[href$=JPG],.post-content a[href$=GIF],.page-content a[href$=GIF],.post-content a[href$=PNG],.page-content a[href$=PNG],.post-content a[href$=jpeg],.page-content a[href$=jpeg],.post-content a[href$=JPEG],.page-content a[href$=JPEG]&quot;,&quot;theme&quot;:&quot;pp_default&quot;,&quot;social_tools&quot;:false,&quot;allow_resize&quot;:true,&quot;show_title&quot;:false,&quot;overlay_gallery&quot;:false,&quot;screenWidthNoLightbox&quot;:600,&quot;deeplinking&quot;:false,&quot;contentImagesAreas&quot;:&quot;.post, .type-page, .type-highlight, .type-slider&quot;,&quot;gallerySelector&quot;:&quot;.gallery-icon > a[href$=jpg],.gallery-icon > a[href$=gif],.gallery-icon > a[href$=png],.gallery-icon > a[href$=JPG],.gallery-icon > a[href$=GIF],.gallery-icon > a[href$=PNG],.gallery-icon > a[href$=jpeg],.gallery-icon > a[href$=JPEG]&quot;,&quot;lightboxGalleryOn&quot;:true},&quot;lightboxContext&quot;:&quot;#pagewrap&quot;,&quot;fixedHeader&quot;:&quot;fixed-header&quot;,&quot;ajax_nonce&quot;:&quot;9edb8546c3&quot;,&quot;ajax_url&quot;:&quot;https:\/\/practice.automationtesting.in\/wp-admin\/admin-ajax.php&quot;,&quot;smallScreen&quot;:&quot;760&quot;,&quot;resizeRefresh&quot;:&quot;250&quot;,&quot;parallaxHeader&quot;:&quot;1&quot;,&quot;loadingImg&quot;:&quot;https:\/\/practice.automationtesting.in\/wp-content\/themes\/themify-ultra\/images\/loading.gif&quot;,&quot;maxPages&quot;:&quot;0&quot;,&quot;autoInfinite&quot;:&quot;auto&quot;,&quot;scrollToNewOnLoad&quot;:&quot;scroll&quot;,&quot;resetFilterOnLoad&quot;:&quot;reset&quot;,&quot;fullPageScroll&quot;:&quot;&quot;,&quot;scrollHighlight&quot;:{&quot;scroll&quot;:&quot;internal&quot;}};
/* ]]&gt; */




/* &lt;![CDATA[ */
var mc4wp_forms_config = [];
/* ]]&gt; */





jQuery(function($) { 

	jQuery( function( $ ) {
		var ppec_mark_fields      = &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_title, #woocommerce_ppec_paypal_description&quot; , &quot;'&quot; , &quot;;
		var ppec_live_fields      = &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_api_username, #woocommerce_ppec_paypal_api_password, #woocommerce_ppec_paypal_api_signature, #woocommerce_ppec_paypal_api_certificate, #woocommerce_ppec_paypal_api_subject&quot; , &quot;'&quot; , &quot;;
		var ppec_sandbox_fields   = &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_sandbox_api_username, #woocommerce_ppec_paypal_sandbox_api_password, #woocommerce_ppec_paypal_sandbox_api_signature, #woocommerce_ppec_paypal_sandbox_api_certificate, #woocommerce_ppec_paypal_sandbox_api_subject&quot; , &quot;'&quot; , &quot;;

		var enable_toggle         = $( &quot; , &quot;'&quot; , &quot;a.ppec-toggle-settings&quot; , &quot;'&quot; , &quot; ).length > 0;
		var enable_sandbox_toggle = $( &quot; , &quot;'&quot; , &quot;a.ppec-toggle-sandbox-settings&quot; , &quot;'&quot; , &quot; ).length > 0;

		$( &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_environment&quot; , &quot;'&quot; , &quot; ).change(function(){
			$( ppec_sandbox_fields + &quot; , &quot;'&quot; , &quot;,&quot; , &quot;'&quot; , &quot; + ppec_live_fields ).closest( &quot; , &quot;'&quot; , &quot;tr&quot; , &quot;'&quot; , &quot; ).hide();

			if ( &quot; , &quot;'&quot; , &quot;live&quot; , &quot;'&quot; , &quot; === $( this ).val() ) {
				$( &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_api_credentials, #woocommerce_ppec_paypal_api_credentials + p&quot; , &quot;'&quot; , &quot; ).show();
				$( &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_sandbox_api_credentials, #woocommerce_ppec_paypal_sandbox_api_credentials + p&quot; , &quot;'&quot; , &quot; ).hide();

				if ( ! enable_toggle ) {
					$( ppec_live_fields ).closest( &quot; , &quot;'&quot; , &quot;tr&quot; , &quot;'&quot; , &quot; ).show();
				}
			} else {
				$( &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_api_credentials, #woocommerce_ppec_paypal_api_credentials + p&quot; , &quot;'&quot; , &quot; ).hide();
				$( &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_sandbox_api_credentials, #woocommerce_ppec_paypal_sandbox_api_credentials + p&quot; , &quot;'&quot; , &quot; ).show();

				if ( ! enable_sandbox_toggle ) {
					$( ppec_sandbox_fields ).closest( &quot; , &quot;'&quot; , &quot;tr&quot; , &quot;'&quot; , &quot; ).show();
				}
			}
		}).change();

		$( &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_mark_enabled&quot; , &quot;'&quot; , &quot; ).change(function(){
			if ( $( this ).is( &quot; , &quot;'&quot; , &quot;:checked&quot; , &quot;'&quot; , &quot; ) ) {
				$( ppec_mark_fields ).closest( &quot; , &quot;'&quot; , &quot;tr&quot; , &quot;'&quot; , &quot; ).show();
			} else {
				$( ppec_mark_fields ).closest( &quot; , &quot;'&quot; , &quot;tr&quot; , &quot;'&quot; , &quot; ).hide();
			}
		}).change();

		$( &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_paymentaction&quot; , &quot;'&quot; , &quot; ).change(function(){
			if ( &quot; , &quot;'&quot; , &quot;sale&quot; , &quot;'&quot; , &quot; === $( this ).val() ) {
				$( &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_instant_payments&quot; , &quot;'&quot; , &quot; ).closest( &quot; , &quot;'&quot; , &quot;tr&quot; , &quot;'&quot; , &quot; ).show();
			} else {
				$( &quot; , &quot;'&quot; , &quot;#woocommerce_ppec_paypal_instant_payments&quot; , &quot;'&quot; , &quot; ).closest( &quot; , &quot;'&quot; , &quot;tr&quot; , &quot;'&quot; , &quot; ).hide();
			}
		}).change();

		if ( enable_toggle ) {
			$( document ).on( &quot; , &quot;'&quot; , &quot;click&quot; , &quot;'&quot; , &quot;, &quot; , &quot;'&quot; , &quot;.ppec-toggle-settings&quot; , &quot;'&quot; , &quot;, function() {
				$( ppec_live_fields ).closest( &quot; , &quot;'&quot; , &quot;tr&quot; , &quot;'&quot; , &quot; ).toggle();
			} );
		}
		if ( enable_sandbox_toggle ) {
			$( document ).on( &quot; , &quot;'&quot; , &quot;click&quot; , &quot;'&quot; , &quot;, &quot; , &quot;'&quot; , &quot;.ppec-toggle-sandbox-settings&quot; , &quot;'&quot; , &quot;, function() {
				$( ppec_sandbox_fields ).closest( &quot; , &quot;'&quot; , &quot;tr&quot; , &quot;'&quot; , &quot; ).toggle();
			} );
		}
	});

 });

		
			if (&quot; , &quot;'&quot; , &quot;object&quot; , &quot;'&quot; , &quot; === typeof tbLocalScript) {
				tbLocalScript.transitionSelectors = &quot;.js.csstransitions .module.wow, .js.csstransitions .themify_builder_content .themify_builder_row.wow, .js.csstransitions .module_row.wow, .js.csstransitions .builder-posts-wrap > .post.wow, .js.csstransitions .fly-in > .post, .js.csstransitions .fly-in .row_inner > .tb-column, .js.csstransitions .fade-in > .post, .js.csstransitions .fade-in .row_inner > .tb-column, .js.csstransitions .slide-up > .post, .js.csstransitions .slide-up .row_inner > .tb-column&quot;;
			}
		
			
id(&quot;billing_last_name&quot;)Software&quot;))]</value>
      <webElementGuid>13f29ba1-9a31-4713-b3a0-4508ced682df</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
