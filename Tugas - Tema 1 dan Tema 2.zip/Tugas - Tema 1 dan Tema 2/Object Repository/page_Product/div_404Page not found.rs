<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_404Page not found</name>
   <tag></tag>
   <elementGuidId>65c7ea44-ffdf-4ee7-bbab-5201c76f1080</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#content</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='content']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>0a3a9d15-b93c-4aef-889b-a60d28ffb224</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>content</value>
      <webElementGuid>900d27b2-1806-4bd0-9188-8181abd6e554</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>clearfix</value>
      <webElementGuid>220aa4e8-ef39-43a7-97e6-1d2ed4e93ebc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    	
					404
			Page not found.
		
				
				
			</value>
      <webElementGuid>b585cdf8-075c-485d-8134-8a94ce795ec9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;content&quot;)</value>
      <webElementGuid>8e29fed3-e713-4b9d-a75b-73104bfb1fec</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='content']</value>
      <webElementGuid>1d938a5b-feb0-444a-ba06-ec3a80a79c9c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='layout']/div</value>
      <webElementGuid>c00e1253-06d1-4117-ac89-f66d5f22b2a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='₹0.00'])[1]/following::div[25]</value>
      <webElementGuid>f6a7f429-c283-4c82-8c0d-a3d96d618151</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Demo Site'])[1]/following::div[25]</value>
      <webElementGuid>f2dd9bbd-1b40-46b8-a460-2070d3b6e5bc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Refine By >'])[1]/preceding::div[1]</value>
      <webElementGuid>8cf5c360-20d5-4253-a952-c94aa411e080</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Product Categories'])[1]/preceding::div[3]</value>
      <webElementGuid>b04f06b8-73ca-4929-a5dd-17e78f97dbba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div</value>
      <webElementGuid>11f40200-7639-4b3c-a4d9-309630ba25d9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[@id = 'content' and (text() = '
    	
					404
			Page not found.
		
				
				
			' or . = '
    	
					404
			Page not found.
		
				
				
			')]</value>
      <webElementGuid>9f9a45af-c2e9-4bea-8327-46764b216575</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
