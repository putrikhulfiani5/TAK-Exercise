<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Selenium Ruby500.00The Selenium WebDriv_02399a</name>
   <tag></tag>
   <elementGuidId>85ca5fa5-47ac-4bff-b5f4-6e6f58b5d48f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.summary.entry-summary</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='product-160']/div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>8c371655-4c88-42ae-bc2b-2eaa709ea886</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>summary entry-summary</value>
      <webElementGuid>4f02df1e-b15a-4ad2-9550-ada9bcfdea68</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

		Selenium Ruby

	₹500.00

	
	
	



	The Selenium WebDriver Recipes book is a quick problem-solving guide to automated testing web applications with Selenium WebDriver.




	
	
	 	
	 	
	


	 	

	 	Add to basket

			

	


	
	
	Category: selenium
	Tags: ruby, selenium
	



	</value>
      <webElementGuid>932141c3-9b4d-44e8-959f-1123bc785d3c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;product-160&quot;)/div[@class=&quot;summary entry-summary&quot;]</value>
      <webElementGuid>3874851d-4de3-4edd-9ad7-e9253e7e9291</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='product-160']/div[2]</value>
      <webElementGuid>f4959d9c-0a42-47dc-a810-1077a7f16bcb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='selenium'])[1]/following::div[3]</value>
      <webElementGuid>eeff060b-c448-4999-a641-b7b3a88c12b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home'])[1]/following::div[3]</value>
      <webElementGuid>2addb322-6454-4be8-8d2f-2b4b61410088</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div[2]</value>
      <webElementGuid>8aae1798-73bd-4e80-93be-8fb9b6358e67</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '

		Selenium Ruby

	₹500.00

	
	
	



	The Selenium WebDriver Recipes book is a quick problem-solving guide to automated testing web applications with Selenium WebDriver.




	
	
	 	
	 	
	


	 	

	 	Add to basket

			

	


	
	
	Category: selenium
	Tags: ruby, selenium
	



	' or . = '

		Selenium Ruby

	₹500.00

	
	
	



	The Selenium WebDriver Recipes book is a quick problem-solving guide to automated testing web applications with Selenium WebDriver.




	
	
	 	
	 	
	


	 	

	 	Add to basket

			

	


	
	
	Category: selenium
	Tags: ruby, selenium
	



	')]</value>
      <webElementGuid>5d4c0c6a-1ea3-4b79-9d28-4ff1f8a825ab</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
