<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Your basket is currently empty.Home Storage  Shelving</name>
   <tag></tag>
   <elementGuidId>2d2806ff-7c7e-4e08-a414-2ee59f5640bd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p.cart-empty</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-34']/div/div/p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>02fb50c6-087f-4011-9d97-c6009e4daa91</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>cart-empty</value>
      <webElementGuid>49a46359-171f-4031-a2fd-80466342a561</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	Your basket is currently empty.Home Storage &amp; Shelving</value>
      <webElementGuid>7779f08e-7893-45ec-a1e1-be0cc41f6106</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-34&quot;)/div[@class=&quot;page-content entry-content&quot;]/div[@class=&quot;woocommerce&quot;]/p[@class=&quot;cart-empty&quot;]</value>
      <webElementGuid>9b78de05-8a63-4270-b610-8d155c03afe5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-34']/div/div/p</value>
      <webElementGuid>45a496f8-1af4-4e0b-b014-ec5a9da23797</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='₹0.00'])[1]/following::p[1]</value>
      <webElementGuid>2e5f04f6-d2f8-4785-a8b7-191ac5906f19</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Demo Site'])[1]/following::p[1]</value>
      <webElementGuid>20f84318-5d05-4c5a-a5df-32a50fa7dce2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Return To Shop'])[1]/preceding::p[1]</value>
      <webElementGuid>ce4740dd-8e1c-43db-af19-7f50d5fc0e21</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Your basket is currently empty.']/parent::*</value>
      <webElementGuid>0998499e-e4ea-49ee-9c78-a4e2646d738f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p</value>
      <webElementGuid>72d3d47e-7b52-4c0d-8337-599eef2d854d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = '
	Your basket is currently empty.Home Storage &amp; Shelving' or . = '
	Your basket is currently empty.Home Storage &amp; Shelving')]</value>
      <webElementGuid>5e1d5b9f-6099-4138-974e-a051fb83ab78</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
