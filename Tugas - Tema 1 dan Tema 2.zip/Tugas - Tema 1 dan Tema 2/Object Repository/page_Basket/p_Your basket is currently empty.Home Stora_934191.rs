<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Your basket is currently empty.Home Stora_934191</name>
   <tag></tag>
   <elementGuidId>436fdb79-f82d-411e-a707-bbf1d646c429</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p.cart-empty</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-34']/div/div/p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>2dc6b474-b5bf-49bf-a551-68ff6994665f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>cart-empty</value>
      <webElementGuid>a11cba50-4a97-4da6-8415-b2c4dd6dc03a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	Your basket is currently empty.Home Storage &amp; Shelving</value>
      <webElementGuid>70610ac1-0d9a-462f-ace4-3c08ec70c8ad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-34&quot;)/div[@class=&quot;page-content entry-content&quot;]/div[@class=&quot;woocommerce&quot;]/p[@class=&quot;cart-empty&quot;]</value>
      <webElementGuid>3da4873f-b69f-4398-afb2-b82632362984</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-34']/div/div/p</value>
      <webElementGuid>84e2e2d5-6378-4e67-a552-8ef01ba0fc24</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='₹0.00'])[1]/following::p[1]</value>
      <webElementGuid>338a5654-297c-4a9d-a62e-abd0930de022</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Demo Site'])[1]/following::p[1]</value>
      <webElementGuid>63520f21-b372-4bba-a7f4-a90e8ccf375f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Return To Shop'])[1]/preceding::p[1]</value>
      <webElementGuid>20f1479b-f2e0-45b5-ae36-c7a234a91736</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Your basket is currently empty.']/parent::*</value>
      <webElementGuid>dfbb1810-a781-4b61-92e8-2bfdf9b26396</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p</value>
      <webElementGuid>2c9761d8-d877-43b7-bd81-10b13109931e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = '
	Your basket is currently empty.Home Storage &amp; Shelving' or . = '
	Your basket is currently empty.Home Storage &amp; Shelving')]</value>
      <webElementGuid>444115fa-5c2f-4f0a-bd26-20aecb2091a7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
