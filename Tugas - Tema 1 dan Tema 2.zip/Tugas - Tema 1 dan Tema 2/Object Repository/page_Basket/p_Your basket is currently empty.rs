<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Your basket is currently empty</name>
   <tag></tag>
   <elementGuidId>1cc95aa6-413d-49cf-9916-ca4e3223ac86</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-34']/div/div[2]/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p.cart-empty</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>c8bb93e4-7fce-45fe-b391-d191cd096d5e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>cart-empty</value>
      <webElementGuid>5f7750b5-b1bd-4976-9259-5da3afb3fd07</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	Your basket is currently empty.</value>
      <webElementGuid>5c0a4876-c9df-42c7-a22a-ac8d4a62903a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-34&quot;)/div[@class=&quot;page-content entry-content&quot;]/div[@class=&quot;woocommerce&quot;]/p[@class=&quot;cart-empty&quot;]</value>
      <webElementGuid>ff739121-26ab-4b56-8975-cf16fe5ba974</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-34']/div/div[2]/p</value>
      <webElementGuid>97f99b1e-4097-45ce-b8bd-68d628ff738c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Undo?'])[1]/following::p[1]</value>
      <webElementGuid>3fed8c38-a48c-4563-9f18-0f10fbe0af3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Return To Shop'])[1]/preceding::p[1]</value>
      <webElementGuid>0af5c144-b85a-4a9a-be13-297a7c91454a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Discover more'])[1]/preceding::p[2]</value>
      <webElementGuid>10ecd559-a093-40b3-89ad-0f987ce2aaab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Your basket is currently empty.']/parent::*</value>
      <webElementGuid>18c38131-1b7e-4106-b661-1c73f7a44137</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p</value>
      <webElementGuid>2790c6fa-7600-4611-a6d8-39761c1ec648</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = '
	Your basket is currently empty.' or . = '
	Your basket is currently empty.')]</value>
      <webElementGuid>1a4b263d-c528-42ec-83a9-9bcb9045091b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
