<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Error An account is already registered with your email address. Please login</name>
   <tag></tag>
   <elementGuidId>4a5c3603-6695-473a-98ca-fc6157606f32</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.woocommerce-error > li</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-36']/div/div/ul/li</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>1a416269-d011-401d-a208-f521eeefbd93</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Error: An account is already registered with your email address. Please login.</value>
      <webElementGuid>ab7c3b00-6b15-42e2-b171-5f8b40c21994</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-36&quot;)/div[@class=&quot;page-content entry-content&quot;]/div[@class=&quot;woocommerce&quot;]/ul[@class=&quot;woocommerce-error&quot;]/li[1]</value>
      <webElementGuid>7579d5bc-97d1-4066-b79c-e6974db07d79</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-36']/div/div/ul/li</value>
      <webElementGuid>79867f79-7c2a-4810-9f85-31401779a5ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='₹0.00'])[1]/following::li[1]</value>
      <webElementGuid>f6980d9a-2bf9-42d7-b83c-59711f5b97f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Demo Site'])[1]/following::li[2]</value>
      <webElementGuid>97d2329f-3ff1-4d85-a022-38c148cd2265</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/preceding::li[1]</value>
      <webElementGuid>d1a440d1-3a39-4156-89e1-192fa2d6c74a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='An account is already registered with your email address. Please login.']/parent::*</value>
      <webElementGuid>dcfe6d9d-5adf-475a-82b2-92f3579b1e66</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li</value>
      <webElementGuid>6f408866-163c-434c-b3c4-d6a3f9dca1ee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = 'Error: An account is already registered with your email address. Please login.' or . = 'Error: An account is already registered with your email address. Please login.')]</value>
      <webElementGuid>9d241660-29f7-4aac-be82-a5cae24f045b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
