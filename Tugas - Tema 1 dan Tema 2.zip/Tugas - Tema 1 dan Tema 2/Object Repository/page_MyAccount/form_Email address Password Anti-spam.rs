<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>form_Email address Password Anti-spam</name>
   <tag></tag>
   <elementGuidId>2b0535e2-4467-412b-83b4-a0c7c5fa787a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='customer_login']/div[2]/form</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>form.register</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>form</value>
      <webElementGuid>28102ad4-bb12-4c00-be7d-286aeb42aba5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>method</name>
      <type>Main</type>
      <value>post</value>
      <webElementGuid>0cbdcb1c-f7b9-4272-af41-d8ed6637e5dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>register</value>
      <webElementGuid>e2ee94fa-d7da-4f20-8d48-69c2ca5d25b0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

			
			
			
				Email address *
				
			

			
				
					Password *
					
				

			
			
			Anti-spam

						
			
								
			

			
		</value>
      <webElementGuid>0c979089-223b-4403-9e64-8f52c4ae91da</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;customer_login&quot;)/div[@class=&quot;u-column2 col-2&quot;]/form[@class=&quot;register&quot;]</value>
      <webElementGuid>130f60dd-4c22-4671-aa09-b6a2e6373b66</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='customer_login']/div[2]/form</value>
      <webElementGuid>9cc4574e-1881-4578-92b0-b45a3fba9e0e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Register'])[1]/following::form[1]</value>
      <webElementGuid>d0367e7d-fa8d-4899-9d8f-1f75a395e484</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lost your password?'])[1]/following::form[1]</value>
      <webElementGuid>f2bc4b50-2d52-4c53-9e5e-527a1c4fde3d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div[2]/form</value>
      <webElementGuid>98c6a982-ffda-420d-a276-f936c49cffda</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//form[(text() = '

			
			
			
				Email address *
				
			

			
				
					Password *
					
				

			
			
			Anti-spam

						
			
								
			

			
		' or . = '

			
			
			
				Email address *
				
			

			
				
					Password *
					
				

			
			
			Anti-spam

						
			
								
			

			
		')]</value>
      <webElementGuid>729b24e0-06a0-4239-8d6a-04e8df3b007f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
