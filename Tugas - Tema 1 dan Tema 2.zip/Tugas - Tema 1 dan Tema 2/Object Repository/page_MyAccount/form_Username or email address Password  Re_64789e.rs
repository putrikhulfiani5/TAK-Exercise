<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>form_Username or email address Password  Re_64789e</name>
   <tag></tag>
   <elementGuidId>bd64d698-8e2e-4324-9139-985db23f4f1c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='customer_login']/div/form</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>form.login</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>form</value>
      <webElementGuid>915d4594-ea90-41b2-83a9-f0beff53969c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>method</name>
      <type>Main</type>
      <value>post</value>
      <webElementGuid>fce77827-a1d7-4cd3-a291-4c2101f11978</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>login</value>
      <webElementGuid>d1138bc2-21e1-496b-bcd0-6ce2ae36bb30</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

			
			
				Username or email address *
				
			
			
				Password *
				
			

			
			
								
				
					 Remember me				
			
			
				Lost your password?
			

			
		</value>
      <webElementGuid>dfd3c153-3ba4-4059-b8a2-76c314c8eac6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;customer_login&quot;)/div[@class=&quot;u-column1 col-1&quot;]/form[@class=&quot;login&quot;]</value>
      <webElementGuid>6d1a61ea-2bee-4795-8768-f31cc21696d2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='customer_login']/div/form</value>
      <webElementGuid>69c9ccf2-1dfc-4da9-87ab-2f6fd5227600</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/following::form[1]</value>
      <webElementGuid>96bdfdff-e07d-4917-9c13-c227d67ab7c1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='₹0.00'])[1]/following::form[1]</value>
      <webElementGuid>99e8d74f-eaeb-4202-b472-3219d313b574</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/form</value>
      <webElementGuid>31632a33-dd85-4134-b64f-298cbaec73d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//form[(text() = '

			
			
				Username or email address *
				
			
			
				Password *
				
			

			
			
								
				
					 Remember me				
			
			
				Lost your password?
			

			
		' or . = '

			
			
				Username or email address *
				
			
			
				Password *
				
			

			
			
								
				
					 Remember me				
			
			
				Lost your password?
			

			
		')]</value>
      <webElementGuid>db878bdb-ed47-4575-83fc-236f4b2bf8fd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
