<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Lost your password</name>
   <tag></tag>
   <elementGuidId>e6b56767-bacc-4ff9-911c-939e4d3cd5ca</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='customer_login']/div/form/p[4]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p.woocommerce-LostPassword.lost_password > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>96a4576a-45b1-4cc3-b2a9-4633fce1c8df</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://practice.automationtesting.in/my-account/lost-password/</value>
      <webElementGuid>0cf0b6db-c31e-47aa-9d33-85e517872776</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Lost your password?</value>
      <webElementGuid>597d4758-9280-4709-be48-0c968bfd29a7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;customer_login&quot;)/div[@class=&quot;u-column1 col-1&quot;]/form[@class=&quot;login&quot;]/p[@class=&quot;woocommerce-LostPassword lost_password&quot;]/a[1]</value>
      <webElementGuid>23235c35-ba40-4022-90ce-b6ee17c3fbdc</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='customer_login']/div/form/p[4]/a</value>
      <webElementGuid>0b9c9d33-c269-41f5-83a6-84972acba693</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Lost your password?')]</value>
      <webElementGuid>9881e34c-6861-4931-a024-7f9663e62382</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*'])[2]/following::a[1]</value>
      <webElementGuid>3d142015-1354-420f-b0de-3687ce2eb6d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Register'])[1]/preceding::a[1]</value>
      <webElementGuid>826ec121-1150-4645-93d9-904cd2047fd5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Lost your password?']/parent::*</value>
      <webElementGuid>df3f976b-72fc-4b80-83c0-d1778cb5a166</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://practice.automationtesting.in/my-account/lost-password/')]</value>
      <webElementGuid>2a6bb1da-c8a7-4a0b-9129-b7c0331cf7c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[4]/a</value>
      <webElementGuid>2e291a96-f472-441d-836e-9c996e8cfb60</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://practice.automationtesting.in/my-account/lost-password/' and (text() = 'Lost your password?' or . = 'Lost your password?')]</value>
      <webElementGuid>40f7540a-d450-4a60-b0b9-29eca8594600</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
