<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Error A user could not be found with this email address</name>
   <tag></tag>
   <elementGuidId>c582f68e-be4e-44c9-82da-73bb997859bd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.woocommerce-error > li</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-36']/div/div/ul/li</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>7756a946-3304-430e-b187-83e34e2ccf37</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Error: A user could not be found with this email address.</value>
      <webElementGuid>a3efe02e-9013-4fc4-9031-b0981d578c18</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-36&quot;)/div[@class=&quot;page-content entry-content&quot;]/div[@class=&quot;woocommerce&quot;]/ul[@class=&quot;woocommerce-error&quot;]/li[1]</value>
      <webElementGuid>7141e0f4-66a6-4100-9d5d-ef92a5f95972</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-36']/div/div/ul/li</value>
      <webElementGuid>52293de4-0e07-4e36-bd82-0755ba7531ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='₹0.00'])[1]/following::li[1]</value>
      <webElementGuid>c235a550-f254-4afc-a4a3-c81489827743</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Demo Site'])[1]/following::li[2]</value>
      <webElementGuid>e5092556-a339-4b16-8624-a0e11f81937f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/preceding::li[1]</value>
      <webElementGuid>c61f10f3-db2c-4c75-9b4b-01d57859ea98</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='A user could not be found with this email address.']/parent::*</value>
      <webElementGuid>50a96eb0-79a2-492f-a2e3-b1f7b9e96497</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li</value>
      <webElementGuid>16244175-7502-4aba-8612-b22870a9d150</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = 'Error: A user could not be found with this email address.' or . = 'Error: A user could not be found with this email address.')]</value>
      <webElementGuid>8adeb8ce-83f2-4cb2-94db-d094173b0b1a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
